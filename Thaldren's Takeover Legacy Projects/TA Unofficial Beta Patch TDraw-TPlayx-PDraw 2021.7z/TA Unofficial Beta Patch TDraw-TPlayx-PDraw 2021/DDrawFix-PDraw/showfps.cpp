#include "header.h"

DWORD m_dwFrameRate = 0;
DWORD m_dwFrameCountStartTime = 0;
IDirectDrawSurface* m_lpDDSBitmapFont = NULL;
IDirectDrawSurface* m_lpDDSFPSBox = NULL;

void RenderFPS()
{
	if( ( m_lpDDSBitmapFont != NULL ) && ( m_lpDDSFPSBox != NULL ) )
	{
		DWORD temp = m_dwFrameRate;
		RECT rcDst = { 33, 0, 44, 16 };
		RECT rcSrc = { 0, 0, 0, 16 };
		for( int i = 0; i < 4; i++ )
		{
			DWORD digit = temp % 10;
			temp = temp / 10;
			rcSrc.left = digit * 11;
			rcSrc.right = rcSrc.left + 11;
			m_lpDDSFPSBox->Blt( &rcDst, m_lpDDSBitmapFont, &rcSrc, DDBLT_WAIT, NULL ); 
			rcDst.left -= 11;
			rcDst.right -= 11;
		}
	}
}

void TrackFPS( BOOL bIncrementCount )
{
	static DWORD dwFrameCount = 0;
	DWORD dwTickCount = GetTickCount();
	if( ( m_dwFrameCountStartTime + 1000 ) < dwTickCount )
	{
		m_dwFrameRate = dwFrameCount;
		m_dwFrameCountStartTime = dwTickCount;
		dwFrameCount = 0;
		if( m_dwFrameRate >= 10000 ) m_dwFrameRate = 9999; 
		//RenderFPS();
	}
	if( bIncrementCount != FALSE ) dwFrameCount++;
}

void ShowFPS( IDirectDrawSurface* lpDDSDest, int x, int y )
{
	if( ( lpDDSDest != NULL ) && ( m_lpDDSFPSBox != NULL ) )
	{
		RECT rcSrc = { 0, 0, 48, 16 };
		RECT rcDst;
		rcDst.left = x;
		rcDst.top = y;
		rcDst.right = x + 48;
		rcDst.bottom = y + 16;
		lpDDSDest->Blt( &rcDst, m_lpDDSFPSBox, &rcSrc, DDBLT_WAIT, NULL ); 
	}
} 


void InitFont( IDirectDraw* pdd, LPDDSURFACEDESC lpDDSurfaceDesc )
{ 
	// bitmap font
	// truetype 14x11 monochromatic characters "0123456789"
	const BYTE m_pxdata[] = {
		0x1E, 0x01, 0x80, 0x78, 0x0F, 0x00, 0x70, 0x7E, 0x01, 0xE3, 0xFC, 0x1E, 0x03, 0xC0,
		0x3F, 0x0F, 0x80, 0xFC, 0x3F, 0x80, 0x70, 0x7E, 0x07, 0xE3, 0xFC, 0x3F, 0x07, 0xE0,
		0x33, 0x0F, 0x81, 0xCE, 0x30, 0xC0, 0xF0, 0x60, 0x0E, 0x03, 0x0C, 0x61, 0x8E, 0x60,
		0x61, 0x81, 0x81, 0x86, 0x00, 0xC1, 0xB0, 0x60, 0x0C, 0x00, 0x1C, 0x61, 0x8C, 0x30,
		0x61, 0x81, 0x80, 0x06, 0x01, 0xC1, 0xB0, 0x7C, 0x1B, 0x80, 0x18, 0x61, 0x8C, 0x30,
		0x61, 0x81, 0x80, 0x0C, 0x0F, 0x83, 0x30, 0x7E, 0x1F, 0xC0, 0x18, 0x3F, 0x0E, 0x70,
		0x61, 0x81, 0x80, 0x18, 0x0F, 0x86, 0x30, 0x67, 0x1C, 0xE0, 0x38, 0x3F, 0x07, 0xF0,
		0x61, 0x81, 0x80, 0x30, 0x01, 0xC7, 0xF8, 0x03, 0x18, 0x60, 0x30, 0x61, 0x83, 0xB0,
		0x61, 0x81, 0x80, 0x60, 0x00, 0xC7, 0xF8, 0x03, 0x18, 0x60, 0x30, 0x61, 0x80, 0x60,
		0x33, 0x01, 0x80, 0xC0, 0x60, 0xC0, 0x30, 0xC7, 0x0C, 0xE0, 0x70, 0x61, 0x80, 0xE0,
		0x3F, 0x0F, 0xF1, 0xFE, 0x7F, 0x80, 0xF8, 0xFE, 0x0F, 0xC0, 0x60, 0x3F, 0x0F, 0xC0,
		0x1E, 0x0F, 0xF1, 0xFE, 0x3F, 0x00, 0xF8, 0x7C, 0x07, 0x80, 0x60, 0x1E, 0x0F, 0x00
	};
	const BITMAP m_bmp = { 0, 112, 12, 14, 1, 1, (LPVOID)m_pxdata };
   
	if( m_lpDDSBitmapFont != NULL )
	{
		m_lpDDSBitmapFont->Release();
		m_lpDDSBitmapFont = NULL;
	}
	if( m_lpDDSFPSBox != NULL )
	{
		m_lpDDSFPSBox->Release();
		m_lpDDSFPSBox = NULL;
	}

	HRESULT bSuccess = FALSE;
    DDSURFACEDESC2 ddsd;

	memcpy( &ddsd, lpDDSurfaceDesc, lpDDSurfaceDesc->dwSize );
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
    ddsd.dwWidth = 128;
    ddsd.dwHeight = 16;
    if( SUCCEEDED( pdd->CreateSurface( (LPDDSURFACEDESC)&ddsd, &m_lpDDSBitmapFont, NULL ) ) )
	{
		if( SUCCEEDED( pdd->CreateSurface( (LPDDSURFACEDESC)&ddsd, &m_lpDDSFPSBox, NULL ) ) )
		{
			if( SUCCEEDED( DDFloodFill( m_lpDDSBitmapFont, NULL, 0 ) ) )
			{
				HDC hdcSurface;
				if( SUCCEEDED( m_lpDDSBitmapFont->GetDC( &hdcSurface ) ) )
				{
					HBITMAP hBmp = CreateBitmapIndirect( &m_bmp );
					if( hBmp != NULL )
					{
						HDC hdcImage = CreateCompatibleDC( hdcSurface );
						if( hdcImage != NULL )
						{
							SelectObject( hdcImage, hBmp );
							if( BitBlt( hdcSurface, 1, 0, 112, 14, hdcImage, 0, 0, SRCCOPY ) )
							{
								bSuccess = TRUE;
							}
							DeleteDC( hdcImage );
						}
						DeleteObject( hBmp );
					}		
					m_lpDDSBitmapFont->ReleaseDC( hdcSurface );
				}
			}			
		}
	}

	if( bSuccess == FALSE )
	{
		if( m_lpDDSBitmapFont != NULL )
		{
			m_lpDDSBitmapFont->Release();
			m_lpDDSBitmapFont = NULL;
		}
		if( m_lpDDSFPSBox != NULL )
		{
			m_lpDDSFPSBox->Release();
			m_lpDDSFPSBox = NULL;
		}
	}
	else RenderFPS();
}