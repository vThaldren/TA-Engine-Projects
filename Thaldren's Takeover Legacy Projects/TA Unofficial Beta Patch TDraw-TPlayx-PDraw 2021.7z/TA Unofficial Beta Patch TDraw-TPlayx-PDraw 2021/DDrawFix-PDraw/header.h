#pragma once

#pragma comment(linker, "/NODEFAULTLIB") 
#pragma comment( lib, "kernel32" )
#pragma comment( lib, "gdi32" )  
#pragma comment(linker, "/ENTRY:\"DllEntryPoint\"") // define entry point cause no C Lib

#define WIN32_LEAN_AND_MEAN
#define INITGUID
#include <windows.h>
#include <Mmsystem.h>
#include <guiddef.h>
#include <ddraw.h>
#include <d3d.h>
#include <dvp.h>
#include "ddrawi.h"
#include "my_no_crt.h"

#define MAX_PRIMARYBUFFERS 3 // for Config.NoVidMem

#define DEBUG 0
// DEBUG 1 == enable logging; log GUIDs
// DEBUG 2 == +log dds calls

struct WRAP
{
    void* vtable;
	long  magic;
	union
	{
		IUnknown*     iunknown;
		IClassFactory* classfactory;
		IDirect3D*    d3d1;
		IDirect3D2*   d3d2;
		IDirect3D3*   d3d3;
		IDirect3D7*   d3d7;
		IDirectDraw*  dd1;
		IDirectDraw2* dd2;
		IDirectDraw4* dd4;
		IDirectDraw7* dd7;
		IDirectDrawSurface*  dds1;
		IDirectDrawSurface2* dds2;
		IDirectDrawSurface3* dds3;
		IDirectDrawSurface4* dds4;
		IDirectDrawSurface7* dds7;
		IDirectDrawClipper*  clipper;
	};
	GUID  iid; 
	volatile long ref;
	WRAP* next;
	WRAP* prev;
};

struct EnumStruct
{
	LPVOID lpOriginalCallback;
	LPVOID lpOriginalContext;
};


// cfg.cpp
struct CONFIG
{
	DWORD Affinity;
	DWORD BltMirror;
	DWORD BltNoTearing;
	DWORD ColorFix;
	DWORD DpiAware;
	DWORD FakeVsync;
	DWORD FakeVsyncInterval;
	DWORD ForceBltNoTearing;
	DWORD ForceHEL;
	DWORD NoVidMem;
	DWORD ShowFPS;
	DWORD Wine_Diablo;
	VOID Init();
	CHAR szDDrawPath[MAX_PATH];
};
BOOL TestVsync( WRAP* dd );
DWORD TestBltMirror( WRAP* dd, DWORD dwDescSize );
DWORD TestFlip( WRAP* dd, DWORD dwDescSize );
extern CONFIG Config;

// showfps.cpp
void TrackFPS( BOOL bIncrementCount );
void ShowFPS( IDirectDrawSurface* lpDDSDest, int x, int y );
void InitFont( IDirectDraw* pdd, LPDDSURFACEDESC lpDDSurfaceDesc );

// helpers.cpp
HRESULT DDFloodFill( IDirectDrawSurface* pdds, PRECT prc, COLORREF cr );
HRESULT FakeVsync( HANDLE hEvent );
HRESULT GetDDInterface_Internal( WRAP* wrap, LPVOID* lplpDD );
HRESULT CreateSurfaceProc( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc, LPDIRECTDRAWSURFACE *lplpDDSurface, IUnknown *pUnkOuter) ;
bool RopUsesPattern( DWORD dwRop );
extern HANDLE g_hThread;
extern BOOL g_ShowDisplay;
extern DWORD g_dwTimerId;
extern IDirectDrawSurface* g_lpDDSRealPrimary;
extern IDirectDrawSurface* g_lpDDSFakePrimary[ MAX_PRIMARYBUFFERS ];



//clipper.cpp
struct IDirectDrawClipper_vtable;
extern IDirectDrawClipper_vtable clip_vtable;

// dd.cpp
struct IDirectDraw1_vtable;
struct IDirectDraw2_vtable;
struct IDirectDraw4_vtable;
struct IDirectDraw7_vtable;
extern IDirectDraw1_vtable dd1_vtable;
extern IDirectDraw2_vtable dd2_vtable;
extern IDirectDraw4_vtable dd4_vtable;
extern IDirectDraw7_vtable dd7_vtable;

// dds.cpp
struct IDirectDrawSurface_vtable;
extern IDirectDrawSurface_vtable dds_vtable;

// d3d.cpp
struct IDirect3D1_vtable;
struct IDirect3D2_vtable;
struct IDirect3D3_vtable;
struct IDirect3D7_vtable;
extern IDirect3D1_vtable d3d1_vtable;
extern IDirect3D2_vtable d3d2_vtable;
extern IDirect3D3_vtable d3d3_vtable;
extern IDirect3D7_vtable d3d7_vtable;


// unknwn.cpp
namespace unknwn
{
	HRESULT __stdcall QueryInterface( WRAP* wrap, const IID& riid, void** ppvObject );
	ULONG __stdcall AddRef( WRAP* wrap );
	ULONG __stdcall Release( WRAP* wrap );
}
struct IUnknown_vtable;
struct IClassFactory_vtable;
extern IUnknown_vtable unkn_vtable;
extern IClassFactory_vtable cf_vtable;

// dllmain.cpp
extern HMODULE g_hDll;

// wrapper.cpp
extern CRITICAL_SECTION WrapCriticalSection;
void DeleteWrap( WRAP* wrapper );
ULONG AddRefWrap( WRAP* wrapper );
ULONG ReleaseWrap( WRAP* wrapper );
bool GetWrap( void** ppv, const GUID& riid );
IUnknown*            GetInterfacePtr( IUnknown*            wrapper );
IDirectDraw*         GetInterfacePtr( IDirectDraw*         wrapper );
IDirectDraw2*        GetInterfacePtr( IDirectDraw2*        wrapper );
IDirectDraw4*        GetInterfacePtr( IDirectDraw4*        wrapper );
IDirectDraw7*        GetInterfacePtr( IDirectDraw7*        wrapper );
IDirectDrawSurface*  GetInterfacePtr( IDirectDrawSurface*  wrapper );
IDirectDrawSurface2* GetInterfacePtr( IDirectDrawSurface2* wrapper );
IDirectDrawSurface3* GetInterfacePtr( IDirectDrawSurface3* wrapper );
IDirectDrawSurface4* GetInterfacePtr( IDirectDrawSurface4* wrapper );
IDirectDrawSurface7* GetInterfacePtr( IDirectDrawSurface7* wrapper );
IDirectDrawClipper*  GetInterfacePtr( IDirectDrawClipper*  wrapper );

HRESULT __stdcall EnumSurfaces1Callback( LPDIRECTDRAWSURFACE  lpDDSurface, LPDDSURFACEDESC  lpDDSurfaceDesc, LPVOID lpContext );
HRESULT __stdcall EnumSurfaces4Callback( LPDIRECTDRAWSURFACE4 lpDDSurface, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPVOID lpContext );
HRESULT __stdcall EnumSurfaces7Callback( LPDIRECTDRAWSURFACE7 lpDDSurface, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPVOID lpContext );

// log.cpp
#if DEBUG
	void __cdecl Log( char* fmt, ... );
	void LogGUID( const GUID& riid );
	void LogDDSD( LPDDSURFACEDESC lpDDSurfaceDesc );
	extern "C" void * _ReturnAddress(void);
	HRESULT LogHRESULT( HRESULT hResult, char* FuncName, void* RetAddress );
	#define LOG Log
	#define LOGGUID LogGUID
	#define LOGDDSD LogDDSD
	#pragma intrinsic(_ReturnAddress)
	#define RETADDR _ReturnAddress()
	#define RETURN(x) return LogHRESULT( x, __FUNCTION__, RETADDR )
#else
	#define LOG(...)
	#define LOGGUID(x)
	#define LOGDDSD(x)
	#define RETURN(x) return (x)
	#define RETADDR
#endif
