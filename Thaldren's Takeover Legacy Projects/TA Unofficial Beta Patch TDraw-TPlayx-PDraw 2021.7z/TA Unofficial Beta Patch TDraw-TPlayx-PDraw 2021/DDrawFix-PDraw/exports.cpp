#include "header.h"


HMODULE GetDDrawDll()
{
	static HMODULE hRealDDraw = NULL; 

	if( hRealDDraw == NULL )
	{
		if( Config.szDDrawPath[0] != '\0' )
		{
			hRealDDraw = LoadLibrary( Config.szDDrawPath );
			if( hRealDDraw == NULL ) MessageBox( 0, "bad ddraw path in cfg", "aqrit's ddraw helper", MB_OK );
			if( hRealDDraw == g_hDll ) // if we think this dll is the real dll...
			{
				FreeLibrary( hRealDDraw );
				hRealDDraw = NULL;
				MessageBox( 0, "path in cfg points to the wrong dll", "aqrit's ddraw helper", MB_OK );
			}
		}

		if( hRealDDraw == NULL )
		{
			char szPath[MAX_PATH];
			szPath[0] = '\0';
			if( GetModuleFileName( g_hDll, szPath, MAX_PATH ) )
			{
				if( strstri( szPath,"\\ddraw.dll") ) // if proxy dll is called ddraw
				{
					if( GetSystemDirectory( szPath, MAX_PATH - 10 )) // then load the ddraw from system32 dir
					{
						strcat( szPath, "\\ddraw.dll" );
					} else {
						szPath[0] = '\0'; // error 
					}
				} else {
					strcpy( szPath, "ddraw.dll" ); // else regular load search path
				}
			}

			hRealDDraw = LoadLibrary( szPath );
			if( hRealDDraw == g_hDll ) // if we think this dll is the real dll...
			{
				FreeLibrary( hRealDDraw );
				hRealDDraw = NULL;
			}
			if( hRealDDraw == NULL )
			{
				MessageBox( 0, "unable to load the real ddraw dll", "aqrit's ddraw helper", MB_OK );
				hRealDDraw = (HMODULE)-1;
			}
		}
	}

	if( hRealDDraw == (HMODULE)-1 ) return NULL; // -1 means failed to load ddraw
	return hRealDDraw;
}

typedef HRESULT (__stdcall* DirectDrawCreate_t)( GUID*, LPDIRECTDRAW*, IUnknown* );
HRESULT __stdcall DirectDrawCreate( GUID* lpGUID, LPDIRECTDRAW* lplpDD, IUnknown* pUnkOuter )
{
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawCreate_t DDCreate = (DirectDrawCreate_t) GetProcAddress( hDDrawDll, "DirectDrawCreate" );
		if( DDCreate == NULL ) return E_NOTIMPL;
		
		if( Config.ForceHEL ) lpGUID = (GUID*)DDCREATE_EMULATIONONLY; 
		
		HRESULT hResult = DDCreate( lpGUID, lplpDD, pUnkOuter );
		if( SUCCEEDED( hResult) )
		{
			
			if( Config.ColorFix ) (*((DDRAWI_DIRECTDRAW_INT**)lplpDD))->lpLcl->dwAppHackFlags |= 0x800;

			if( GetWrap( (void**)lplpDD, IID_IDirectDraw ) )
			{
				if( Config.FakeVsync == 2 ) Config.FakeVsync = ( TestVsync(*((WRAP**)lplpDD)) ) ? FALSE : TRUE;
			}
		}
		return hResult;
	}
	return E_FAIL;
}

typedef HRESULT (__stdcall* DirectDrawCreateEx_t)( GUID*, LPVOID*, REFIID, IUnknown* );
HRESULT __stdcall DirectDrawCreateEx( GUID* lpGUID, LPVOID* lplpDD, REFIID iid, IUnknown* pUnkOuter )
{
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawCreateEx_t DDCreateEx = (DirectDrawCreateEx_t) GetProcAddress( hDDrawDll, "DirectDrawCreateEx" );
		if( DDCreateEx == NULL ) return E_NOTIMPL;

		if( Config.ForceHEL ) lpGUID = (GUID*)DDCREATE_EMULATIONONLY; 
		
		HRESULT hResult = DDCreateEx( lpGUID, lplpDD, iid, pUnkOuter );
		if( SUCCEEDED( hResult) )
		{
			if( Config.ColorFix ) (*((DDRAWI_DIRECTDRAW_INT**)lplpDD))->lpLcl->dwAppHackFlags |= 0x800;

			if( GetWrap( (void**)lplpDD, iid ) )
			{
				if( Config.FakeVsync == 2 ) Config.FakeVsync = TestVsync(*((WRAP**)lplpDD)) ? FALSE : TRUE;
			}
		}
		return hResult;
	}
	return E_FAIL;
}

typedef HRESULT (__stdcall* DirectDrawCreateClipper_t)( DWORD dwFlags, LPDIRECTDRAWCLIPPER FAR *lplpDDClipper,  IUnknown FAR *pUnkOuter );
HRESULT __stdcall DirectDrawCreateClipper( DWORD dwFlags, LPDIRECTDRAWCLIPPER FAR *lplpDDClipper,  IUnknown FAR *pUnkOuter )
{	
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawCreateClipper_t pfn = (DirectDrawCreateClipper_t) GetProcAddress( hDDrawDll, "DirectDrawCreateClipper" );
		if( pfn == NULL ) return E_NOTIMPL;

		HRESULT hResult = pfn( dwFlags, lplpDDClipper, pUnkOuter );
		if( SUCCEEDED( hResult) )
		{
			GetWrap( (void**)lplpDDClipper, IID_IDirectDrawClipper );
		}
		return hResult;
	}
	return E_FAIL;	
}


// CoCreateInstance passes IID_IClassFactory
typedef HRESULT (__stdcall* DllGetClassObject_t)( REFCLSID, REFIID, LPVOID* );
HRESULT __stdcall DllGetClassObject( REFCLSID rclsid, REFIID riid, LPVOID* ppvObject )
{
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DllGetClassObject_t GetClassObj = (DllGetClassObject_t) GetProcAddress( hDDrawDll, "DllGetClassObject" );
		if( GetClassObj == NULL ) return E_NOTIMPL;

		HRESULT hResult = GetClassObj( rclsid, riid, ppvObject );
		if( SUCCEEDED( hResult) )
		{ 
			GetWrap( ppvObject, riid );
		}
		return hResult;
	}
	return E_FAIL;
}



////////////////////////////////////////////
//
// Every thing below here is just pass-thru
//
////////////////////////////////////////////

typedef VOID (__stdcall* AcquireDDThreadLock_t)();
VOID __stdcall AcquireDDThreadLock()
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		AcquireDDThreadLock_t pfn = (AcquireDDThreadLock_t) GetProcAddress( hDDrawDll, "AcquireDDThreadLock" );
		if( pfn != NULL ) return pfn();
	}
}

typedef VOID (__stdcall* ReleaseDDThreadLock_t)();
VOID __stdcall ReleaseDDThreadLock()
{
	// LeaveCriticalSection( _lpDDCS ); 
	
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		ReleaseDDThreadLock_t pfn = (ReleaseDDThreadLock_t) GetProcAddress( hDDrawDll, "ReleaseDDThreadLock" );
		if( pfn != NULL ) pfn();
	}
}


typedef HRESULT (__stdcall* DirectDrawEnumerateA_t)( LPDDENUMCALLBACK lpCallback, LPVOID lpContext );
HRESULT __stdcall DirectDrawEnumerateA( LPDDENUMCALLBACK lpCallback, LPVOID lpContext )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawEnumerateA_t pfn = (DirectDrawEnumerateA_t) GetProcAddress( hDDrawDll, "DirectDrawEnumerateA" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( lpCallback, lpContext );
	}
	return E_FAIL;
}


typedef HRESULT (__stdcall* DirectDrawEnumerateExA_t)( LPDDENUMCALLBACK lpCallback, LPVOID lpContext, DWORD dwFlags );
HRESULT __stdcall DirectDrawEnumerateExA( LPDDENUMCALLBACK lpCallback, LPVOID lpContext, DWORD dwFlags )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawEnumerateExA_t pfn = (DirectDrawEnumerateExA_t) GetProcAddress( hDDrawDll, "DirectDrawEnumerateExA" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( lpCallback, lpContext, dwFlags );
	}
	return E_FAIL;
}


typedef HRESULT (__stdcall* DirectDrawEnumerateExW_t)( LPDDENUMCALLBACK lpCallback, LPVOID lpContext, DWORD dwFlags );
HRESULT __stdcall DirectDrawEnumerateExW( LPDDENUMCALLBACK lpCallback, LPVOID lpContext, DWORD dwFlags )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawEnumerateExW_t pfn = (DirectDrawEnumerateExW_t) GetProcAddress( hDDrawDll, "DirectDrawEnumerateExW" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( lpCallback, lpContext, dwFlags );
	}
	return E_FAIL;
}


typedef HRESULT (__stdcall* DirectDrawEnumerateW_t)( LPDDENUMCALLBACK lpCallback, LPVOID lpContext );
HRESULT __stdcall DirectDrawEnumerateW( LPDDENUMCALLBACK lpCallback, LPVOID lpContext )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DirectDrawEnumerateW_t pfn = (DirectDrawEnumerateW_t) GetProcAddress( hDDrawDll, "DirectDrawEnumerateW" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( lpCallback, lpContext );
	}
	return E_FAIL;
}


typedef HRESULT (__stdcall* D3DParseUnknownCommand_t)( LPVOID lpCmd, LPVOID *lpRetCmd );
HRESULT __stdcall D3DParseUnknownCommand( LPVOID lpCmd, LPVOID *lpRetCmd )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		D3DParseUnknownCommand_t pfn = (D3DParseUnknownCommand_t) GetProcAddress( hDDrawDll, "D3DParseUnknownCommand" );
		if( pfn != NULL ) 
			return pfn( lpCmd, lpRetCmd );
	}
	return 0x88760BB8; // D3DERR_COMMAND_UNPARSED
}


typedef HRESULT (__stdcall* DllCanUnloadNow_t)();
HRESULT __stdcall DllCanUnloadNow()
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DllCanUnloadNow_t pfn = (DllCanUnloadNow_t) GetProcAddress( hDDrawDll, "DllCanUnloadNow" );
		if( pfn != NULL ) 
			return pfn();
	}
	return S_FALSE; // do not unload
}


typedef DWORD (__stdcall* GetOLEThunkData_t)( DWORD index );
DWORD __stdcall GetOLEThunkData( DWORD index )
{ 
	//	switch( index ) 
	//	{
	//		case 1: return _dwLastFrameRate;
	//		case 2: return _lpDriverObjectList;
	//		case 3: return _lpAttachedProcesses;
	//		case 4: return 0; // does nothing
	//		case 5: return _CheckExclusiveMode;
	//		case 6: return 0; // ReleaseExclusiveModeMutex
	//	}

	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		GetOLEThunkData_t pfn = (GetOLEThunkData_t) GetProcAddress( hDDrawDll, "GetOLEThunkData" );
		if( pfn != NULL ) 
			return pfn( index );
	}
	return 0;
}


typedef DWORD (__stdcall* SetAppCompatData_t)( DWORD index, DWORD data );
DWORD __stdcall SetAppCompatData( DWORD index, DWORD data )
{
	//	switch( index ) 
	//	{
	//		case 1: _g_bDWMOffForPrimaryLock	= 0;	return 0;
	//		case 2: _g_bDWMOffForPrimaryBlt		= 0;	return 0;
	//		case 3: _g_bForceFullscreenSprite	= 1;	return 0;
	//		case 4: _g_bForceBltToPrimary		= 1;	return 0;
	//		case 5: _g_crShadowBuf				= data;	return 0;
	//		case 6: _g_bDWMOffForFullscreen		= 0;	return 0;
	//	}

	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		SetAppCompatData_t pfn = (SetAppCompatData_t) GetProcAddress( hDDrawDll, "SetAppCompatData" );
		if( pfn != NULL ) 
			return pfn( index, data );
	}
	return -1;
}


//////////////////////
// todo below
//////////////////////
typedef DWORD (__stdcall* CompleteCreateSysmemSurface_t)( DWORD );
DWORD __stdcall CompleteCreateSysmemSurface( DWORD arg1 )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		CompleteCreateSysmemSurface_t pfn = (CompleteCreateSysmemSurface_t) GetProcAddress( hDDrawDll, "CompleteCreateSysmemSurface" );
		if( pfn != NULL ) return pfn( arg1 );
	}
	return 0; // ?
}


typedef HRESULT (__stdcall* DDGetAttachedSurfaceLcl_t)( DWORD, DWORD, DWORD );
HRESULT __stdcall DDGetAttachedSurfaceLcl( DWORD arg1, DWORD arg2, DWORD arg3 )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DDGetAttachedSurfaceLcl_t pfn = (DDGetAttachedSurfaceLcl_t) GetProcAddress( hDDrawDll, "DDGetAttachedSurfaceLcl" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( arg1, arg2, arg3 );
	}
	return E_FAIL; 
}


typedef DWORD (__stdcall* DDInternalLock_t)( DWORD, DWORD );
DWORD __stdcall DDInternalLock( DWORD arg1, DWORD arg2 )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DDInternalLock_t pfn = (DDInternalLock_t) GetProcAddress( hDDrawDll, "DDInternalLock" );
		if( pfn != NULL ) return pfn( arg1, arg2 );
	}
	return -1; // ?
}


typedef DWORD (__stdcall* DDInternalUnlock_t)( DWORD );
DWORD __stdcall DDInternalUnlock( DWORD arg1 )
{
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DDInternalUnlock_t pfn = (DDInternalUnlock_t) GetProcAddress( hDDrawDll, "DDInternalUnlock" );
		if( pfn != NULL ) return pfn( arg1 );
	}
	return -1; // ?
} 

/*
If SetCooperativeLevel is called once in a process, a binding is established between the process and the window. 
If it is called again in the same process with a different non-null window handle, it returns the DDERR_HWNDALREADYSET 
error value. Some applications may receive this error value when DirectSound� specifies a different window handle than
DirectDraw�they should specify the same, top-level application window handle.
*/
typedef HRESULT (__stdcall* DSoundHelp_t)( DWORD, DWORD, DWORD );
HRESULT __stdcall DSoundHelp( DWORD arg1, DWORD arg2, DWORD arg3 )
{ 
	// _internalSetAppHWnd( 0, arg1, 0, 0, arg2, arg3 );

	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		DSoundHelp_t pfn = (DSoundHelp_t) GetProcAddress( hDDrawDll, "DSoundHelp" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( arg1, arg2, arg3 );
	}
	return E_FAIL; // DDERR_NOHWND, DDERR_HWNDALREADYSET, E_INVALIDARG, E_OUTOFMEMORY, DD_OK
} 


// assume HRESULT...
typedef HRESULT (__stdcall* GetDDSurfaceLocal_t)( DWORD, DWORD, DWORD );
HRESULT __stdcall GetDDSurfaceLocal(  DWORD arg1, DWORD arg2, DWORD arg3 )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		GetDDSurfaceLocal_t pfn = (GetDDSurfaceLocal_t) GetProcAddress( hDDrawDll, "GetDDSurfaceLocal" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( arg1, arg2, arg3 );
	}
	return E_FAIL;
}


// assume HRESULT...
typedef HRESULT (__stdcall* GetSurfaceFromDC_export_t)( DWORD, DWORD, DWORD );
HRESULT __stdcall GetSurfaceFromDC_export(  DWORD arg1, DWORD arg2, DWORD arg3 )
{ 
	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		GetSurfaceFromDC_export_t pfn = (GetSurfaceFromDC_export_t) GetProcAddress( hDDrawDll, "GetSurfaceFromDC" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( arg1, arg2, arg3 );
	}
	return E_FAIL;
} 


typedef HRESULT (__stdcall* RegisterSpecialCase_t)( DWORD, DWORD, DWORD, DWORD );
HRESULT __stdcall RegisterSpecialCase( DWORD arg1, DWORD arg2, DWORD arg3, DWORD arg4 )
{ 
	// setup for HEL BLT ??

	HMODULE hDDrawDll = GetDDrawDll();
    if( hDDrawDll != NULL )
	{
		RegisterSpecialCase_t pfn = (RegisterSpecialCase_t) GetProcAddress( hDDrawDll, "RegisterSpecialCase" );
		if( pfn == NULL ) return E_NOTIMPL;
		return pfn( arg1, arg2, arg3, arg4 );
	}
	return E_FAIL; // E_OUTOFMEMORY; 
}