#include "header.h"

IDirectDrawSurface* g_lpDDSRealPrimary = NULL; // There can be only one.
IDirectDrawSurface* g_lpDDSFakePrimary[ MAX_PRIMARYBUFFERS ] = { 0 };

HANDLE g_hThread;
BOOL g_ShowDisplay;
DWORD g_dwTimerId;

// Config.NoVidMem todo:
//		add checks in dd->EnumSurfaces and dds->EnumAttachedSurfaces
//		clipper/windowed mode?
//		SetSurfaceDescription() / GetSurfaceDescription()?
// !!!! AttachSurface doesn't work in DDraw7 ??????!!!!!
   
// correct? with rops and/or ddrops
bool RopUsesPattern( DWORD dwRop )
{ 
	return ( (((dwRop & 0x00F00000) >> 4) != (dwRop & 0x000F0000)) || (((dwRop & 0xF0000000) >> 4) != (dwRop & 0x0F000000)) ); 
}

// ColorFix / Stolen Palette fix sets flag 0x800 on a internal ddraw struct member called dwAppHackFlags
//  ( see DirectDrawCreate[Ex] or dd(1...7)->Initialize() )
// if ( flag & 0x10 ) do not disable the screen saver for exclusive mode ??
// else disable by calling SystemParametersInfo( SPI_SCREENSAVERRUNNING, 1 ...) 
// note: SystemParametersInfo( SPI_SCREENSAVERRUNNING, ...) disables alt+tab and ctrl+alt+del on win9x

/*
todo:
"Applications manifested for Windows 7 are prevented from performing Blt's to the primary Desktop video buffer without a clipping window."
	- who cares; don't manifested your directdraw app for win7... however the DWM Composition stays on if you do
	- BltFast doesn't work with a clipper, so redirect it thru Blt
	- grab the hWnd from SetCooperativeLevel
*/


// interesting discussion on timers: http://forum.sysinternals.com/bug-in-waitable-timers_topic16229.html

// HEL doesn't support (or fake) vsync 
// this is a problem because some animation is frame based and can run too fast
// we can get the real verticle blank from D3DKMT but the screen still tears in HEL though I don't know why???
// todo: what is GetVerticalBlankStatus returning in HEL?
// todo: DDOVER_AUTOFLIP ??
HRESULT FakeVsync( HANDLE hEvent )
{
	static DWORD dwPrevFrameTickCount = 0;
	DWORD dwTickCount = GetTickCount();
	LONG lDiff = Config.FakeVsyncInterval - (dwTickCount - dwPrevFrameTickCount);
	if( lDiff > 0 )
	{
		Sleep( lDiff );
		dwTickCount += lDiff;
	}
	dwPrevFrameTickCount = dwTickCount;
	if( hEvent ) SetEvent( hEvent );
	return DD_OK;
} 



// Fills an area of a surface with the color specified
// Note: pass null as prc to fill everywhere
// Note: there was a bug with nVidia cards and DDBLT_COLORFILL if a RECT is not NULL
// see https://github.com/jlanger/nvidia_ddraw_fix/
// (the bug can be avoided by using DDraw Emulation of course)
HRESULT DDFloodFill( IDirectDrawSurface* pdds, PRECT prc, COLORREF cr )
{
	DDBLTFX effects;
	memset( &effects, 0, sizeof( effects ) );
	effects.dwSize = sizeof( effects );
	effects.dwFillColor = cr;
	return pdds->Blt( prc, NULL, NULL, (DDBLT_COLORFILL | DDBLT_WAIT), &effects );
}
                                    


// copy the fake primary to the real primary every so often
//
// WaitForSingleObject( hReleasePrimaryEvent, 14 ) // always enters ring 0... so overkill?
// SetWaitableTimer()? 
//
// this seem too slow: 
//		WaitForVerticalBlankProc( g_lpDDWrap, DDWAITVB_BLOCKBEGIN, 0 );
//		Blt()
// 		Sleep(0);
DWORD __stdcall ThreadProc( VOID* param )
{
	Sleep(300); // so we don't have the surface "busy" while the game tries to init it
	while( g_ShowDisplay )
	{
		if( Config.ShowFPS )
		{
			//TrackFPS( FALSE );
			//ShowFPS( g_lpDDSFakePrimary[0], 0, 0 ); // if windowed mode then this probably gets clipped
			// plus fakevideomemory doesn't work to well with windowed mode anyways
		}

		HRESULT hResult = g_lpDDSRealPrimary->Blt( NULL, g_lpDDSFakePrimary[0], NULL, DDBLT_WAIT, NULL );
		if( hResult == DDERR_SURFACELOST ) g_lpDDSRealPrimary->Restore();
		Sleep( Config.FakeVsyncInterval );  
	}
	return 0;
}


// copy the fake primary to the real primary every so often
//
// AFAIK there should never be more than one WM_TIMER messages in the queue for a normal message loop
VOID __stdcall TimerProc( HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTickCount )
{
	if( g_ShowDisplay )
	{
		HRESULT hResult = g_lpDDSRealPrimary->Blt( NULL, g_lpDDSFakePrimary[0], NULL, DDBLT_WAIT, NULL ); 
		if( hResult == DDERR_SURFACELOST ) g_lpDDSRealPrimary->Restore();
	}
}


// works for all ddraw surface interface versions
// found DD interface isn't wrapped
HRESULT GetDDInterface_Internal( WRAP* wrap, LPVOID* lplpDD ) 
{ 
	HRESULT hResult; 
	if( wrap->iid == IID_IDirectDrawSurface )
	{
		IDirectDrawSurface2* dds2;
		if( SUCCEEDED( wrap->dds1->QueryInterface( IID_IDirectDrawSurface2, (LPVOID*) &dds2 ) ) )
		{
			hResult = dds2->GetDDInterface( lplpDD );
			dds2->Release();
		}
	}
	else
	{
		hResult = wrap->dds2->GetDDInterface( lplpDD );
	}
	return hResult; 
}


HRESULT CreateSurfaceProc( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc, LPDIRECTDRAWSURFACE* lplpDDSurface, IUnknown *pUnkOuter) 
{
	HRESULT hResult;
	
	if( Config.NoVidMem )
	{
		///////// put all surfaces in system memory  ////////////
		DWORD dwOriginalCaps = lpDDSurfaceDesc->ddsCaps.dwCaps;
		if( ( lpDDSurfaceDesc->dwFlags & DDSD_CAPS ) || ( lpDDSurfaceDesc->dwFlags == DDSD_ALL ) )
		{
			if( !( lpDDSurfaceDesc->ddsCaps.dwCaps & DDSCAPS_OVERLAY ) ) // overlays must be in video memory
			{
				
				lpDDSurfaceDesc->ddsCaps.dwCaps &= ~( DDSCAPS_OPTIMIZED | DDSCAPS_VIDEOMEMORY | DDSCAPS_LOCALVIDMEM | DDSCAPS_NONLOCALVIDMEM );
				lpDDSurfaceDesc->ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;

				// create surface
				hResult = wrap->dd1->CreateSurface( lpDDSurfaceDesc, lplpDDSurface, pUnkOuter );
				if( SUCCEEDED( hResult ) )
				{
					// if primary
					if( lpDDSurfaceDesc->ddsCaps.dwCaps & DDSCAPS_PRIMARYSURFACE )
					{
						DDSURFACEDESC2 ddsd;

						g_lpDDSRealPrimary = *lplpDDSurface;
						//InitFont( wrap->dd1, lpDDSurfaceDesc );

						ddsd.dwSize = lpDDSurfaceDesc->dwSize;
						g_lpDDSRealPrimary->GetSurfaceDesc( (LPDDSURFACEDESC)&ddsd ); // need width & height of real primary

					//////	ddsd.ddsCaps.dwCaps |= DDSCAPS_OFFSCREENPLAIN;

						// more caps not allowed (picked at random)
						ddsd.ddsCaps.dwCaps &= ~( DDSCAPS_OPTIMIZED | DDSCAPS_NONLOCALVIDMEM | DDSCAPS_LOCALVIDMEM | 
							DDSCAPS_ALLOCONLOAD | DDSCAPS_VISIBLE | DDSCAPS_VIDEOMEMORY | DDSCAPS_PRIMARYSURFACE |
							DDSCAPS_FRONTBUFFER | DDSCAPS_FLIP | DDSCAPS_COMPLEX | DDSCAPS_BACKBUFFER | DDSCAPS_OVERLAY );
						
						DWORD nBufferCount = 1;
						if( ddsd.dwFlags & DDSD_BACKBUFFERCOUNT )
						{ 
							nBufferCount += ddsd.dwBackBufferCount;
						}
						ddsd.dwFlags &= ~DDSD_BACKBUFFERCOUNT;

						if( nBufferCount <= MAX_PRIMARYBUFFERS )
						{
							// create fake primary //
							DWORD i;
							for( i = 0; i < nBufferCount; i++ ) 
							{
								if( FAILED( wrap->dd1->CreateSurface( (LPDDSURFACEDESC)&ddsd, &g_lpDDSFakePrimary[ i ], pUnkOuter ) ) ) break;
								if( i != 0 )
								{
									if( FAILED( g_lpDDSFakePrimary[ i - 1 ]->AddAttachedSurface( g_lpDDSFakePrimary[ i ] ) ) ) break;
								}
							}
							if( i < nBufferCount ) // error
							{
								// destroy
								do
								{
									if( g_lpDDSFakePrimary[i] != NULL )
									{
										g_lpDDSFakePrimary[i]->DeleteAttachedSurface( 0, NULL );
										g_lpDDSFakePrimary[i]->Release();	
										g_lpDDSFakePrimary[i] = NULL;
									}
								} while( i-- != 0 );
							}
								
							//
							if( g_lpDDSFakePrimary[0] != NULL )
							{
								g_lpDDSFakePrimary[0]->AddRef();
								*lplpDDSurface = g_lpDDSFakePrimary[0];

								if(Config.NoVidMem == 2 )
								{
									g_ShowDisplay = TRUE;
									g_dwTimerId = SetTimer( NULL, 0, Config.FakeVsyncInterval, TimerProc );	
									//todo: if( g_Timer == 0 ) error();
								}
								if( Config.NoVidMem == 1 )
								{											
									g_ShowDisplay = TRUE;
									g_hThread = CreateThread( NULL, 0, &ThreadProc, 0, 0, NULL );
									//todo: if( g_hThread == NULL ) error();
									
									SetThreadPriority( g_hThread, GetThreadPriority( GetCurrentThread() ) );
								}
								
								memcpy( lpDDSurfaceDesc, &ddsd, ddsd.dwSize );
								lpDDSurfaceDesc->ddsCaps.dwCaps = dwOriginalCaps; // restore
								if( nBufferCount > 1 )
								{
									lpDDSurfaceDesc->dwFlags |= DDSD_BACKBUFFERCOUNT;
									lpDDSurfaceDesc->dwBackBufferCount = nBufferCount - 1;
								}
								return hResult;
							}
						} // if nBufferCount is less than MAX
					} // if primary
					lpDDSurfaceDesc->ddsCaps.dwCaps = dwOriginalCaps; // restore
					return hResult;
				} // if created surface
				lpDDSurfaceDesc->ddsCaps.dwCaps = dwOriginalCaps; // restore
			} // if not overlay
		} // if caps
		else // else no caps specified
		{	
			lpDDSurfaceDesc->dwFlags |= DDSD_CAPS;
			if( lpDDSurfaceDesc->dwSize >= sizeof( DDSURFACEDESC2 ) )
			{
				((DDSCAPS2*)(&lpDDSurfaceDesc->ddsCaps))->dwCaps2 = 0;
				((DDSCAPS2*)(&lpDDSurfaceDesc->ddsCaps))->dwCaps3 = 0;
				((DDSCAPS2*)(&lpDDSurfaceDesc->ddsCaps))->dwCaps4 = 0;
			}
			lpDDSurfaceDesc->ddsCaps.dwCaps = DDSCAPS_SYSTEMMEMORY;
			hResult = wrap->dd1->CreateSurface( lpDDSurfaceDesc, lplpDDSurface, pUnkOuter );
			lpDDSurfaceDesc->ddsCaps.dwCaps = dwOriginalCaps;
			lpDDSurfaceDesc->dwFlags ^= DDSD_CAPS;
			if( SUCCEEDED( hResult ) ) return hResult;
		}
	} // if Config.NoVidMem

	///////////// call with original args "pass-thru" ///////////////////
	hResult = wrap->dd1->CreateSurface( lpDDSurfaceDesc, lplpDDSurface, pUnkOuter );
	
	if( ( hResult == DDERR_NODIRECTDRAWHW ) && ( Config.ForceHEL == 2 ) )
	{
		// Baldur's Gate (without totsc) and Planescape: Torment support the primary surface being in system memory
		// but oddly only enable the correct "flipping" routine if a DDERR_OUTOFVIDEOMEMORY is returned on failure
		// to create the primary surface in video memory.
		// when using the wrong flipping routine the cursor is not earsed correctly leaving behind artifacts
		// this issue revolves around Flip() copying insteads of swapping when the primary surface is in system memory instead of video memory
		hResult = DDERR_OUTOFVIDEOMEMORY;
	}

	
	if( SUCCEEDED( hResult ) && ( g_lpDDSRealPrimary == NULL ) )
	{
		if( ( lpDDSurfaceDesc->dwFlags & DDSD_CAPS ) || ( lpDDSurfaceDesc->dwFlags == DDSD_ALL ) )
		{
			if( lpDDSurfaceDesc->ddsCaps.dwCaps & DDSCAPS_PRIMARYSURFACE ) // if primary
			{
				// save g_lpDDSRealPrimary for ForceBltNoTearing and ShowFPS
				g_lpDDSRealPrimary = *lplpDDSurface;
				//InitFont( wrap->dd1, lpDDSurfaceDesc );
			}
		}
	}

	return hResult;
}
