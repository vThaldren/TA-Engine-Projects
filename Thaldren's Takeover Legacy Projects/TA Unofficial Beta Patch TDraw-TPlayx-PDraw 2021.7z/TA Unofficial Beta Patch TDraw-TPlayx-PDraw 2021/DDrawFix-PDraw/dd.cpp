#include "header.h"





namespace dd1
{
	HRESULT __stdcall Compact( WRAP* wrap )
	{ 
		RETURN( wrap->dd1->Compact() ); 
	}
    
	HRESULT __stdcall CreateClipper( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter)
	{ 
		HRESULT hResult = wrap->dd1->CreateClipper( dwFlags, lplpDDClipper, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDClipper, IID_IDirectDrawClipper ); 
		RETURN( hResult ); 
	}
    
	HRESULT __stdcall CreatePalette( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter) 
	{ 
		RETURN( wrap->dd1->CreatePalette( dwFlags, lpColorTable, lplpDDPalette, pUnkOuter ) ); 
	}
    
	HRESULT __stdcall CreateSurface( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc, LPDIRECTDRAWSURFACE *lplpDDSurface, IUnknown *pUnkOuter) 
	{ 
		HRESULT hResult = CreateSurfaceProc(wrap, lpDDSurfaceDesc, lplpDDSurface, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDSurface, IID_IDirectDrawSurface ); // any back buffers are wrapped at GetAttachedSurface()
		RETURN( hResult );
	}

	HRESULT __stdcall DuplicateSurface( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSurface, LPDIRECTDRAWSURFACE *lplpDupDDSurface)
	{ 
		HRESULT hResult = wrap->dd1->DuplicateSurface( GetInterfacePtr( lpDDSurface ), lplpDupDDSurface ); 
		if( SUCCEEDED( hResult ) )
		{
			if( ((WRAP*)lpDDSurface)->magic == 0x70617257 ) GetWrap( (void**)lplpDupDDSurface, ((WRAP*)lpDDSurface)->iid );
		}
		RETURN( hResult );
	}

    HRESULT __stdcall EnumDisplayModes( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext, LPDDENUMMODESCALLBACK lpEnumModesCallback) 
	{ 
		RETURN( wrap->dd1->EnumDisplayModes( dwFlags, lpDDSurfaceDesc, lpContext, lpEnumModesCallback ) ); 
	}

    HRESULT __stdcall EnumSurfaces( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpEnumSurfacesCallback) 
	{ 
		EnumStruct e;
		e.lpOriginalCallback = lpEnumSurfacesCallback;
		e.lpOriginalContext = lpContext;
		RETURN( wrap->dd1->EnumSurfaces( dwFlags, lpDDSD, &e, &EnumSurfaces1Callback ) );
	}

    HRESULT __stdcall FlipToGDISurface( WRAP* wrap ) 
	{ 
		RETURN( wrap->dd1->FlipToGDISurface() ); 
	}

    HRESULT __stdcall GetCaps( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps) 
	{ 
		HRESULT hResult;
		if( Config.ForceHEL )
		{
			DDCAPS_DX7 ddcaps;
			if( lpDDHELCaps == NULL )
			{
				lpDDHELCaps = &ddcaps;
				ddcaps.dwSize = lpDDDriverCaps->dwSize;
			}
			hResult = wrap->dd1->GetCaps( lpDDDriverCaps, lpDDHELCaps );
			if( lpDDDriverCaps != NULL )
			{
				// memcpy
				BYTE* dst = (BYTE*)lpDDDriverCaps;
				BYTE* src = (BYTE*)lpDDHELCaps;
				for( DWORD i = 0; i < lpDDHELCaps->dwSize; i++ ) dst[i] = src[i];
			}
		}
		else
		{
			hResult = wrap->dd1->GetCaps( lpDDDriverCaps, lpDDHELCaps );
		}
		RETURN( hResult ); 
	}

    HRESULT __stdcall GetDisplayMode( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc) 
	{ 
		RETURN( wrap->dd1->GetDisplayMode(lpDDSurfaceDesc) ); 
	}

    HRESULT __stdcall GetFourCCCodes( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes) 
	{ 
		RETURN( wrap->dd1->GetFourCCCodes(lpNumCodes, lpCodes) ); 
	}

    HRESULT __stdcall GetGDISurface( WRAP* wrap, LPDIRECTDRAWSURFACE *lplpGDIDDSurface)
	{ 
		HRESULT hResult = wrap->dd2->GetGDISurface( lplpGDIDDSurface ); 
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpGDIDDSurface, IID_IDirectDrawSurface );
		RETURN( hResult ); 
	}

    HRESULT __stdcall GetMonitorFrequency( WRAP* wrap, LPDWORD lpdwFrequency) 
	{ 
		if( Config.FakeVsync != 0 )
		{
			*lpdwFrequency = 1000 / Config.FakeVsyncInterval;
			RETURN( DD_OK );
		}
		RETURN( wrap->dd1->GetMonitorFrequency(lpdwFrequency) ); 
	}

    HRESULT __stdcall GetScanLine( WRAP* wrap, LPDWORD lpdwScanLine) 
	{ 
		RETURN( wrap->dd1->GetScanLine( lpdwScanLine ) ); 
	}
    
	HRESULT __stdcall GetVerticalBlankStatus( WRAP* wrap, BOOL *lpbIsInVB) 
	{ 
		RETURN( wrap->dd1->GetVerticalBlankStatus( lpbIsInVB ) ); 
	}
    
	HRESULT __stdcall Initialize( WRAP* wrap, GUID *lpGUID) 
	{ 		
		if( Config.ForceHEL )lpGUID = (GUID*)DDCREATE_EMULATIONONLY;
		HRESULT hResult = wrap->dd1->Initialize( lpGUID ); 
		if( SUCCEEDED( hResult ) )
		{
			if( Config.ColorFix ) ((DDRAWI_DIRECTDRAW_INT*)wrap->dd1)->lpLcl->dwAppHackFlags |= 0x800;
			if( Config.FakeVsync == 2 ) Config.FakeVsync = TestVsync( wrap ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall RestoreDisplayMode( WRAP* wrap )
	{ 
		RETURN( wrap->dd1->RestoreDisplayMode() );
	}

	HRESULT __stdcall SetCooperativeLevel( WRAP* wrap, HWND hWnd, DWORD dwFlags) 
	{ 		
		if( Config.Wine_Diablo == 1 )
		{
			hWnd = NULL;
			dwFlags = DDSCL_NORMAL;
		}
		if( Config.Wine_Diablo == 2 )
		{
			hWnd = GetDesktopWindow();
			SetForegroundWindow( hWnd );
		}


		HRESULT hResult = wrap->dd1->SetCooperativeLevel(hWnd, dwFlags);
		if( SUCCEEDED(hResult) )
		{
			if( Config.BltMirror == 2 ) Config.BltMirror = TestBltMirror( wrap, sizeof(DDSURFACEDESC) ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall SetDisplayMode( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP ) 
	{ 
		RETURN( wrap->dd1->SetDisplayMode( dwWidth, dwHeight, dwBPP ) ); 
	}

    HRESULT __stdcall WaitForVerticalBlank( WRAP* wrap, DWORD dwFlags, HANDLE hEvent) 
	{ 
		RETURN( ( ( Config.FakeVsync ) ? FakeVsync( hEvent ) : wrap->dd1->WaitForVerticalBlank( dwFlags, hEvent ) ) );
	}
};


namespace dd2
{
	HRESULT __stdcall Compact( WRAP* wrap )
	{ 
		RETURN( wrap->dd2->Compact() ); 
	}
    
	HRESULT __stdcall CreateClipper( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter)
	{ 
		HRESULT hResult = wrap->dd2->CreateClipper( dwFlags, lplpDDClipper, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDClipper, IID_IDirectDrawClipper ); 
		RETURN( hResult ); 
	}
    
	HRESULT __stdcall CreatePalette( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter) 
	{ 
		RETURN( wrap->dd2->CreatePalette(dwFlags, lpColorTable, lplpDDPalette, pUnkOuter) ); 
	}
    
	HRESULT __stdcall CreateSurface( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc, LPDIRECTDRAWSURFACE *lplpDDSurface, IUnknown *pUnkOuter) 
	{ 
		HRESULT hResult = CreateSurfaceProc(wrap, lpDDSurfaceDesc, lplpDDSurface, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDSurface, IID_IDirectDrawSurface ); // any back buffers are wrapped at GetAttachedSurface()
		RETURN( hResult );
	}

	HRESULT __stdcall DuplicateSurface( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSurface, LPDIRECTDRAWSURFACE *lplpDupDDSurface)
	{ 
		HRESULT hResult = wrap->dd2->DuplicateSurface( GetInterfacePtr( lpDDSurface ), lplpDupDDSurface ); 
		if( SUCCEEDED( hResult ) )
		{
			if( ((WRAP*)lpDDSurface)->magic == 0x70617257 ) GetWrap( (void**)lplpDupDDSurface, ((WRAP*)lpDDSurface)->iid );
		}
		RETURN( hResult );
	}

    HRESULT __stdcall EnumDisplayModes( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext, LPDDENUMMODESCALLBACK lpEnumModesCallback) 
	{ 
		RETURN( wrap->dd2->EnumDisplayModes(dwFlags, lpDDSurfaceDesc, lpContext, lpEnumModesCallback) ); 
	}

    HRESULT __stdcall EnumSurfaces( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpEnumSurfacesCallback) 
	{ 
		EnumStruct e;
		e.lpOriginalCallback = lpEnumSurfacesCallback;
		e.lpOriginalContext = lpContext;
		RETURN( wrap->dd2->EnumSurfaces(dwFlags, lpDDSD, &e, &EnumSurfaces1Callback) );
	}

    HRESULT __stdcall FlipToGDISurface( WRAP* wrap ) 
	{ 
		RETURN( wrap->dd2->FlipToGDISurface() ); 
	}

    HRESULT __stdcall GetCaps( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps) 
	{ 
		HRESULT hResult;
		if( Config.ForceHEL )
		{
			DDCAPS_DX7 ddcaps;
			if( lpDDHELCaps == NULL )
			{
				lpDDHELCaps = &ddcaps;
				ddcaps.dwSize = lpDDDriverCaps->dwSize;
			}
			hResult = wrap->dd2->GetCaps( lpDDDriverCaps, lpDDHELCaps );
			if( lpDDDriverCaps != NULL )
			{
				// memcpy
				BYTE* dst = (BYTE*)lpDDDriverCaps;
				BYTE* src = (BYTE*)lpDDHELCaps;
				for( DWORD i = 0; i < lpDDHELCaps->dwSize; i++ ) dst[i] = src[i];
			}
		}
		else
		{
			hResult = wrap->dd2->GetCaps( lpDDDriverCaps, lpDDHELCaps );
		}
		RETURN( hResult ); 
	}

    HRESULT __stdcall GetDisplayMode( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc) 
	{ 
		RETURN( wrap->dd2->GetDisplayMode(lpDDSurfaceDesc) ); 
	}

    HRESULT __stdcall GetFourCCCodes( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes) 
	{ 
		RETURN( wrap->dd2->GetFourCCCodes(lpNumCodes, lpCodes) ); 
	}

    HRESULT __stdcall GetGDISurface( WRAP* wrap, LPDIRECTDRAWSURFACE *lplpGDIDDSurface)
	{ 
		HRESULT hResult = wrap->dd2->GetGDISurface( lplpGDIDDSurface ); 
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpGDIDDSurface, IID_IDirectDrawSurface );
		RETURN( hResult ); 
	}

    HRESULT __stdcall GetMonitorFrequency( WRAP* wrap, LPDWORD lpdwFrequency) 
	{ 
		if( Config.FakeVsync != 0 )
		{
			*lpdwFrequency = 1000 / Config.FakeVsyncInterval;
			RETURN( DD_OK );
		}
		RETURN( wrap->dd2->GetMonitorFrequency(lpdwFrequency) ); 
	}

    HRESULT __stdcall GetScanLine( WRAP* wrap, LPDWORD lpdwScanLine) 
	{ 
		RETURN( wrap->dd2->GetScanLine(lpdwScanLine) ); 
	}
    
	HRESULT __stdcall GetVerticalBlankStatus( WRAP* wrap, BOOL *lpbIsInVB) 
	{ 
		RETURN( wrap->dd2->GetVerticalBlankStatus(lpbIsInVB) ); 
	}
    
	HRESULT __stdcall Initialize( WRAP* wrap, GUID *lpGUID) 
	{ 		
		if( Config.ForceHEL ) lpGUID = (GUID*)DDCREATE_EMULATIONONLY;

		HRESULT hResult = wrap->dd2->Initialize( lpGUID ); 
		if( SUCCEEDED( hResult ) )
		{
			if( Config.ColorFix ) ((DDRAWI_DIRECTDRAW_INT*)wrap->dd2)->lpLcl->dwAppHackFlags |= 0x800;
			if( Config.FakeVsync == 2 ) Config.FakeVsync = TestVsync( wrap ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall RestoreDisplayMode( WRAP* wrap )
	{ 
		RETURN( wrap->dd2->RestoreDisplayMode() );
	}

	HRESULT __stdcall SetCooperativeLevel( WRAP* wrap, HWND hWnd, DWORD dwFlags) 
	{ 
		HRESULT hResult = wrap->dd2->SetCooperativeLevel(hWnd, dwFlags);
		if( SUCCEEDED(hResult) )
		{
			if( Config.BltMirror == 2 ) Config.BltMirror = TestBltMirror( wrap, sizeof(DDSURFACEDESC) ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall SetDisplayMode( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags ) 
	{ 
		RETURN( wrap->dd2->SetDisplayMode(dwWidth, dwHeight, dwBPP, dwRefreshRate, dwFlags ) ); 
	}

    HRESULT __stdcall WaitForVerticalBlank( WRAP* wrap, DWORD dwFlags, HANDLE hEvent) 
	{ 
		RETURN( ( ( Config.FakeVsync ) ? FakeVsync( hEvent ) : wrap->dd2->WaitForVerticalBlank( dwFlags, hEvent ) ) );
	}

	//////////
	// v2 
	//////////

	HRESULT __stdcall GetAvailableVidMem( WRAP* wrap, LPDDSCAPS lpDDCaps, LPDWORD lpdwTotal, LPDWORD lpdwFree )
	{
		RETURN( wrap->dd2->GetAvailableVidMem( lpDDCaps, lpdwTotal, lpdwFree ) );
	}
};


namespace dd4
{
	HRESULT __stdcall Compact( WRAP* wrap )
	{ 
		RETURN( wrap->dd4->Compact() ); 
	}
    
	HRESULT __stdcall CreateClipper( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter)
	{ 
		HRESULT hResult = wrap->dd4->CreateClipper( dwFlags, lplpDDClipper, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDClipper, IID_IDirectDrawClipper ); 
		RETURN( hResult );  
	}
    
	HRESULT __stdcall CreatePalette( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter) 
	{ 
		RETURN( wrap->dd4->CreatePalette(dwFlags, lpColorTable, lplpDDPalette, pUnkOuter) ); 
	}
    
	HRESULT __stdcall CreateSurface( WRAP* wrap, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPDIRECTDRAWSURFACE4 *lplpDDSurface, IUnknown *pUnkOuter) 
	{ 
		HRESULT hResult = CreateSurfaceProc(wrap, (LPDDSURFACEDESC)lpDDSurfaceDesc, (LPDIRECTDRAWSURFACE*)lplpDDSurface, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDSurface, IID_IDirectDrawSurface4 ); // any back buffers are wrapped at GetAttachedSurface()
		RETURN( hResult );
	}

	HRESULT __stdcall DuplicateSurface( WRAP* wrap, LPDIRECTDRAWSURFACE4 lpDDSurface, LPDIRECTDRAWSURFACE4 *lplpDupDDSurface)
	{ 
		HRESULT hResult = wrap->dd4->DuplicateSurface( GetInterfacePtr( lpDDSurface ), lplpDupDDSurface ); 
		if( SUCCEEDED( hResult ) )
		{
			if( ((WRAP*)lpDDSurface)->magic == 0x70617257 ) GetWrap( (void**)lplpDupDDSurface, ((WRAP*)lpDDSurface)->iid );
		}
		RETURN( hResult );
	}

    HRESULT __stdcall EnumDisplayModes( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 LPDDSURFACEDESC2, LPVOID lpContext, LPDDENUMMODESCALLBACK2 lpEnumModesCallback) 
	{ 
		RETURN( wrap->dd4->EnumDisplayModes(dwFlags, LPDDSURFACEDESC2, lpContext, lpEnumModesCallback) ); 
	}

    HRESULT __stdcall EnumSurfaces( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK2 lpEnumSurfacesCallback) 
	{ 
		EnumStruct e;
		e.lpOriginalCallback = lpEnumSurfacesCallback;
		e.lpOriginalContext = lpContext;
		RETURN( wrap->dd4->EnumSurfaces(dwFlags, lpDDSD, &e, &EnumSurfaces4Callback) );
	}

    HRESULT __stdcall FlipToGDISurface( WRAP* wrap ) 
	{ 
		RETURN( wrap->dd4->FlipToGDISurface() ); 
	}

    HRESULT __stdcall GetCaps( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps) 
	{ 
		HRESULT hResult;
		if( Config.ForceHEL )
		{
			DDCAPS_DX7 ddcaps;
			if( lpDDHELCaps == NULL )
			{
				lpDDHELCaps = &ddcaps;
				ddcaps.dwSize = lpDDDriverCaps->dwSize;
			}
			hResult = wrap->dd4->GetCaps( lpDDDriverCaps, lpDDHELCaps );
			if( lpDDDriverCaps != NULL )
			{
				// memcpy
				BYTE* dst = (BYTE*)lpDDDriverCaps;
				BYTE* src = (BYTE*)lpDDHELCaps;
				for( DWORD i = 0; i < lpDDHELCaps->dwSize; i++ ) dst[i] = src[i];
			}
		}
		else
		{
			hResult = wrap->dd4->GetCaps( lpDDDriverCaps, lpDDHELCaps );
		}
		RETURN( hResult ); 
	}

    HRESULT __stdcall GetDisplayMode( WRAP* wrap, LPDDSURFACEDESC2 LPDDSURFACEDESC2) 
	{ 
		RETURN( wrap->dd4->GetDisplayMode(LPDDSURFACEDESC2) ); 
	}

    HRESULT __stdcall GetFourCCCodes( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes) 
	{ 
		RETURN( wrap->dd4->GetFourCCCodes(lpNumCodes, lpCodes) ); 
	}

    HRESULT __stdcall GetGDISurface( WRAP* wrap, LPDIRECTDRAWSURFACE4 *lplpGDIDDSurface)
	{ 
		HRESULT hResult = wrap->dd4->GetGDISurface( lplpGDIDDSurface ); 
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpGDIDDSurface, IID_IDirectDrawSurface4 );
		RETURN( hResult );
	}

    HRESULT __stdcall GetMonitorFrequency( WRAP* wrap, LPDWORD lpdwFrequency) 
	{ 
		if( Config.FakeVsync != 0 )
		{
			*lpdwFrequency = 1000 / Config.FakeVsyncInterval;
			RETURN( DD_OK );
		}
		RETURN( wrap->dd4->GetMonitorFrequency(lpdwFrequency) ); 
	}

    HRESULT __stdcall GetScanLine( WRAP* wrap, LPDWORD lpdwScanLine) 
	{ 
		RETURN( wrap->dd4->GetScanLine(lpdwScanLine) ); 
	}
    
	HRESULT __stdcall GetVerticalBlankStatus( WRAP* wrap, BOOL *lpbIsInVB) 
	{ 
		RETURN( wrap->dd4->GetVerticalBlankStatus(lpbIsInVB) ); 
	}
    
	HRESULT __stdcall Initialize( WRAP* wrap, GUID* lpGUID) 
	{ 		
		if( Config.ForceHEL )lpGUID = (GUID*)DDCREATE_EMULATIONONLY;
		HRESULT hResult = wrap->dd4->Initialize( lpGUID ); 
		if( SUCCEEDED( hResult ) )
		{
			if( Config.ColorFix ) ((DDRAWI_DIRECTDRAW_INT*)wrap->dd4)->lpLcl->dwAppHackFlags |= 0x800;
			if( Config.FakeVsync == 2 ) Config.FakeVsync = TestVsync( wrap ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall RestoreDisplayMode( WRAP* wrap )
	{ 
		RETURN( wrap->dd4->RestoreDisplayMode() );
	}

	HRESULT __stdcall SetCooperativeLevel( WRAP* wrap, HWND hWnd, DWORD dwFlags) 
	{
		HRESULT hResult = wrap->dd4->SetCooperativeLevel(hWnd, dwFlags);
		if( SUCCEEDED(hResult) )
		{
			if( Config.BltMirror == 2 ) Config.BltMirror = TestBltMirror( wrap, sizeof(DDSURFACEDESC2) ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall SetDisplayMode( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags ) 
	{ 
		RETURN( wrap->dd4->SetDisplayMode(dwWidth, dwHeight, dwBPP, dwRefreshRate, dwFlags ) ); 
	}

    HRESULT __stdcall WaitForVerticalBlank( WRAP* wrap, DWORD dwFlags, HANDLE hEvent) 
	{ 
		RETURN( ( ( Config.FakeVsync ) ? FakeVsync( hEvent ) : wrap->dd4->WaitForVerticalBlank( dwFlags, hEvent ) ) );
	}

	//////////
	// v2 
	//////////

	HRESULT __stdcall GetAvailableVidMem( WRAP* wrap, LPDDSCAPS2 lpDDCaps, LPDWORD lpdwTotal, LPDWORD lpdwFree )
	{
		RETURN( wrap->dd4->GetAvailableVidMem( lpDDCaps, lpdwTotal, lpdwFree ) );
	}

	//////////
	// v4 
	//////////

	HRESULT __stdcall GetSurfaceFromDC( WRAP* wrap, HDC hdc, LPDIRECTDRAWSURFACE4* lplpDDSurface )
	{
		HRESULT hResult = wrap->dd4->GetSurfaceFromDC( hdc, lplpDDSurface );
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDSurface, IID_IDirectDrawSurface4 );
		RETURN( hResult );
	}

	HRESULT __stdcall RestoreAllSurfaces( WRAP* wrap )
	{
		RETURN( wrap->dd4->RestoreAllSurfaces() );
	}

	HRESULT __stdcall TestCooperativeLevel( WRAP* wrap )
	{
		RETURN( wrap->dd4->TestCooperativeLevel() );
	}

	HRESULT __stdcall GetDeviceIdentifier( WRAP* wrap, LPDDDEVICEIDENTIFIER pDDDI, DWORD dwFlags )
	{
		RETURN( wrap->dd4->GetDeviceIdentifier( pDDDI, dwFlags ) );
	}
};


namespace dd7
{
	HRESULT __stdcall Compact( WRAP* wrap )
	{ 
		RETURN( wrap->dd7->Compact() ); 
	}
    
	HRESULT __stdcall CreateClipper( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter)
	{ 
		HRESULT hResult = wrap->dd7->CreateClipper( dwFlags, lplpDDClipper, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDClipper, IID_IDirectDrawClipper ); 
		RETURN( hResult ); 
	}
    
	HRESULT __stdcall CreatePalette( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter) 
	{ 
		RETURN( wrap->dd7->CreatePalette(dwFlags, lpColorTable, lplpDDPalette, pUnkOuter) ); 
	}
    
	HRESULT __stdcall CreateSurface( WRAP* wrap, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPDIRECTDRAWSURFACE7 *lplpDDSurface, IUnknown *pUnkOuter) 
	{ 
		HRESULT hResult = CreateSurfaceProc(wrap, (LPDDSURFACEDESC)lpDDSurfaceDesc, (LPDIRECTDRAWSURFACE*)lplpDDSurface, pUnkOuter);
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDSurface, IID_IDirectDrawSurface7 ); // any back buffers are wrapped at GetAttachedSurface()
		RETURN( hResult );
	}

	HRESULT __stdcall DuplicateSurface( WRAP* wrap, LPDIRECTDRAWSURFACE7 lpDDSurface, LPDIRECTDRAWSURFACE7 *lplpDupDDSurface)
	{ 
		HRESULT hResult = wrap->dd7->DuplicateSurface( GetInterfacePtr( lpDDSurface ), lplpDupDDSurface ); 
		if( SUCCEEDED( hResult ) )
		{
			if( ((WRAP*)lpDDSurface)->magic == 0x70617257 ) GetWrap( (void**)lplpDupDDSurface, ((WRAP*)lpDDSurface)->iid );
		}
		RETURN( hResult );
	}

    HRESULT __stdcall EnumDisplayModes( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 LPDDSURFACEDESC2, LPVOID lpContext, LPDDENUMMODESCALLBACK2 lpEnumModesCallback) 
	{ 
		RETURN( wrap->dd7->EnumDisplayModes(dwFlags, LPDDSURFACEDESC2, lpContext, lpEnumModesCallback) ); 
	}

    HRESULT __stdcall EnumSurfaces( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK7 lpEnumSurfacesCallback) 
	{ 
		EnumStruct e;
		e.lpOriginalCallback = lpEnumSurfacesCallback;
		e.lpOriginalContext = lpContext;
		RETURN( wrap->dd7->EnumSurfaces(dwFlags, lpDDSD, &e, &EnumSurfaces7Callback) );
	}

    HRESULT __stdcall FlipToGDISurface( WRAP* wrap ) 
	{ 
		RETURN( wrap->dd7->FlipToGDISurface() ); 
	}

    HRESULT __stdcall GetCaps( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps) 
	{ 
		HRESULT hResult;
		if( Config.ForceHEL )
		{
			DDCAPS_DX7 ddcaps;
			if( lpDDHELCaps == NULL )
			{
				lpDDHELCaps = &ddcaps;
				ddcaps.dwSize = lpDDDriverCaps->dwSize;
			}
			hResult = wrap->dd7->GetCaps( lpDDDriverCaps, lpDDHELCaps );
			if( lpDDDriverCaps != NULL )
			{
				// memcpy
				BYTE* dst = (BYTE*)lpDDDriverCaps;
				BYTE* src = (BYTE*)lpDDHELCaps;
				for( DWORD i = 0; i < lpDDHELCaps->dwSize; i++ ) dst[i] = src[i];
			}
		}
		else
		{
			hResult = wrap->dd7->GetCaps( lpDDDriverCaps, lpDDHELCaps );
		}
		RETURN( hResult ); 
	}

    HRESULT __stdcall GetDisplayMode( WRAP* wrap, LPDDSURFACEDESC2 LPDDSURFACEDESC2) 
	{ 
		RETURN( wrap->dd7->GetDisplayMode(LPDDSURFACEDESC2) ); 
	}

    HRESULT __stdcall GetFourCCCodes( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes) 
	{ 
		RETURN( wrap->dd7->GetFourCCCodes(lpNumCodes, lpCodes) ); 
	}

    HRESULT __stdcall GetGDISurface( WRAP* wrap, LPDIRECTDRAWSURFACE7 *lplpGDIDDSurface)
	{ 
		HRESULT hResult = wrap->dd7->GetGDISurface( lplpGDIDDSurface ); 
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpGDIDDSurface, IID_IDirectDrawSurface4 );
		RETURN( hResult );
	}

    HRESULT __stdcall GetMonitorFrequency( WRAP* wrap, LPDWORD lpdwFrequency) 
	{ 
		if( Config.FakeVsync != 0 ) 
		{
			*lpdwFrequency = 1000 / Config.FakeVsyncInterval;
			RETURN( DD_OK );
		}
		RETURN( wrap->dd7->GetMonitorFrequency(lpdwFrequency) ); 
	}

    HRESULT __stdcall GetScanLine( WRAP* wrap, LPDWORD lpdwScanLine) 
	{ 
		RETURN( wrap->dd7->GetScanLine(lpdwScanLine) ); 
	}
    
	HRESULT __stdcall GetVerticalBlankStatus( WRAP* wrap, BOOL *lpbIsInVB) 
	{ 
		RETURN( wrap->dd7->GetVerticalBlankStatus(lpbIsInVB) ); 
	}
    
	HRESULT __stdcall Initialize( WRAP* wrap, GUID *lpGUID) 
	{ 		
		if( Config.ForceHEL )lpGUID = (GUID*)DDCREATE_EMULATIONONLY;
		HRESULT hResult = wrap->dd7->Initialize( lpGUID ); 
		if( SUCCEEDED( hResult ) )
		{
			if( Config.ColorFix ) ((DDRAWI_DIRECTDRAW_INT*)wrap->dd7)->lpLcl->dwAppHackFlags |= 0x800;
			if( Config.FakeVsync == 2 ) Config.FakeVsync = TestVsync( wrap ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall RestoreDisplayMode( WRAP* wrap )
	{ 
		RETURN( wrap->dd7->RestoreDisplayMode() );
	}

	HRESULT __stdcall SetCooperativeLevel( WRAP* wrap, HWND hWnd, DWORD dwFlags) 
	{ 
		HRESULT hResult = wrap->dd7->SetCooperativeLevel(hWnd, dwFlags);
		if( SUCCEEDED(hResult) )
		{
			if( Config.BltMirror == 2 ) Config.BltMirror = TestBltMirror( wrap, sizeof(DDSURFACEDESC2) ) ? FALSE : TRUE;
		}
		RETURN( hResult );
	}

    HRESULT __stdcall SetDisplayMode( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags ) 
	{ 
		RETURN( wrap->dd7->SetDisplayMode(dwWidth, dwHeight, dwBPP, dwRefreshRate, dwFlags ) ); 
	}

    HRESULT __stdcall WaitForVerticalBlank( WRAP* wrap, DWORD dwFlags, HANDLE hEvent) 
	{ 
		RETURN( ( ( Config.FakeVsync ) ? FakeVsync( hEvent ) : wrap->dd7->WaitForVerticalBlank( dwFlags, hEvent ) ) );
	}

	//////////
	// v2 
	//////////

	HRESULT __stdcall GetAvailableVidMem( WRAP* wrap, LPDDSCAPS2 lpDDCaps, LPDWORD lpdwTotal, LPDWORD lpdwFree )
	{
		RETURN( wrap->dd7->GetAvailableVidMem( lpDDCaps, lpdwTotal, lpdwFree ) );
	}

	//////////
	// v4 
	//////////

	HRESULT __stdcall GetSurfaceFromDC( WRAP* wrap, HDC hdc, LPDIRECTDRAWSURFACE7* lplpDDSurface )
	{
		HRESULT hResult = wrap->dd7->GetSurfaceFromDC( hdc, lplpDDSurface );
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDSurface, IID_IDirectDrawSurface7 );
		RETURN( hResult );
	}

	HRESULT __stdcall RestoreAllSurfaces( WRAP* wrap )
	{
		RETURN( wrap->dd7->RestoreAllSurfaces() );
	}

	HRESULT __stdcall TestCooperativeLevel( WRAP* wrap )
	{
		RETURN( wrap->dd7->TestCooperativeLevel() );
	}

	HRESULT __stdcall GetDeviceIdentifier( WRAP* wrap, LPDDDEVICEIDENTIFIER2 pDDDI, DWORD dwFlags )
	{
		RETURN( wrap->dd7->GetDeviceIdentifier( pDDDI, dwFlags ) );
	}

	//////////
	// v7
	//////////

	HRESULT __stdcall StartModeTest( WRAP* wrap, LPSIZE pModes, DWORD dwNumModes, DWORD dwFlags)
	{
		RETURN( wrap->dd7->StartModeTest( pModes, dwNumModes, dwFlags ) );
	}

	HRESULT __stdcall EvaluateMode( WRAP* wrap, DWORD dwFlags, DWORD* pTimeout)
	{
		RETURN( wrap->dd7->EvaluateMode( dwFlags, pTimeout ) );
	}
};



struct IDirectDraw1_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
	HRESULT (__stdcall * Compact)( WRAP* wrap );
	HRESULT (__stdcall * CreateClipper)( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreatePalette)( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreateSurface)( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc, LPDIRECTDRAWSURFACE *lplpDDSurface, IUnknown *pUnkOuter ); 
	HRESULT (__stdcall * DuplicateSurface)( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSurface, LPDIRECTDRAWSURFACE *lplpDupDDSurface );
	HRESULT (__stdcall * EnumDisplayModes)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext, LPDDENUMMODESCALLBACK lpEnumModesCallback );
	HRESULT (__stdcall * EnumSurfaces)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpEnumSurfacesCallback );
	HRESULT (__stdcall * FlipToGDISurface)( WRAP* wrap );
	HRESULT (__stdcall * GetCaps)( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps );
	HRESULT (__stdcall * GetDisplayMode)( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc );
	HRESULT (__stdcall * GetFourCCCodes)( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes );
	HRESULT (__stdcall * GetGDISurface)( WRAP* wrap, LPDIRECTDRAWSURFACE *lplpGDIDDSurface );
	HRESULT (__stdcall * GetMonitorFrequency)( WRAP* wrap, LPDWORD lpdwFrequency );
	HRESULT (__stdcall * GetScanLine)( WRAP* wrap, LPDWORD lpdwScanLine );
	HRESULT (__stdcall * GetVerticalBlankStatus)( WRAP* wrap, BOOL *lpbIsInVB );
	HRESULT (__stdcall * Initialize)(WRAP* wrap,  GUID *lpGUID ); 
	HRESULT (__stdcall * RestoreDisplayMode)( WRAP* wrap );
	HRESULT (__stdcall * SetCooperativeLevel)( WRAP* wrap, HWND hWnd, DWORD dwFlags ); 
	HRESULT (__stdcall * SetDisplayMode)( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP );
	HRESULT (__stdcall * WaitForVerticalBlank)( WRAP* wrap, DWORD dwFlags, HANDLE hEvent );
};

struct IDirectDraw2_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
	HRESULT (__stdcall * Compact)( WRAP* wrap );
	HRESULT (__stdcall * CreateClipper)( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreatePalette)( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreateSurface)( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc, LPDIRECTDRAWSURFACE *lplpDDSurface, IUnknown *pUnkOuter );
	HRESULT (__stdcall * DuplicateSurface)( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSurface, LPDIRECTDRAWSURFACE *lplpDupDDSurface );
	HRESULT (__stdcall * EnumDisplayModes)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext, LPDDENUMMODESCALLBACK lpEnumModesCallback );
	HRESULT (__stdcall * EnumSurfaces)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpEnumSurfacesCallback ); 
	HRESULT (__stdcall * FlipToGDISurface)( WRAP* wrap );
	HRESULT (__stdcall * GetCaps)( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps );
	HRESULT (__stdcall * GetDisplayMode)( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc );
	HRESULT (__stdcall * GetFourCCCodes)( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes );
	HRESULT (__stdcall * GetGDISurface)( WRAP* wrap, LPDIRECTDRAWSURFACE *lplpGDIDDSurface );
	HRESULT (__stdcall * GetMonitorFrequency)( WRAP* wrap, LPDWORD lpdwFrequency );
	HRESULT (__stdcall * GetScanLine)( WRAP* wrap, LPDWORD lpdwScanLine );
	HRESULT (__stdcall * GetVerticalBlankStatus)( WRAP* wrap, BOOL *lpbIsInVB );
	HRESULT (__stdcall * Initialize)( WRAP* wrap, GUID *lpGUID ); 
	HRESULT (__stdcall * RestoreDisplayMode)( WRAP* wrap );
	HRESULT (__stdcall * SetCooperativeLevel)( WRAP* wrap, HWND hWnd, DWORD dwFlags );
	HRESULT (__stdcall * SetDisplayMode)( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags );
	HRESULT (__stdcall * WaitForVerticalBlank)( WRAP* wrap, DWORD dwFlags, HANDLE hEvent );
	HRESULT (__stdcall * GetAvailableVidMem)( WRAP* wrap, LPDDSCAPS lpDDCaps, LPDWORD lpdwTotal, LPDWORD lpdwFree );
};


struct IDirectDraw4_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
	HRESULT (__stdcall * Compact)( WRAP* wrap );
	HRESULT (__stdcall * CreateClipper)( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreatePalette)( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreateSurface)( WRAP* wrap, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPDIRECTDRAWSURFACE4 *lplpDDSurface, IUnknown *pUnkOuter );
	HRESULT (__stdcall * DuplicateSurface)( WRAP* wrap, LPDIRECTDRAWSURFACE4 lpDDSurface, LPDIRECTDRAWSURFACE4 *lplpDupDDSurface );
	HRESULT (__stdcall * EnumDisplayModes)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPVOID lpContext, LPDDENUMMODESCALLBACK2 lpEnumModesCallback );
	HRESULT (__stdcall * EnumSurfaces)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK2 lpEnumSurfacesCallback ); 
	HRESULT (__stdcall * FlipToGDISurface)( WRAP* wrap ) ;
	HRESULT (__stdcall * GetCaps)( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps );
	HRESULT (__stdcall * GetDisplayMode)( WRAP* wrap, LPDDSURFACEDESC2 lpDDSurfaceDesc );
	HRESULT (__stdcall * GetFourCCCodes)( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes );
	HRESULT (__stdcall * GetGDISurface)( WRAP* wrap, LPDIRECTDRAWSURFACE4 *lplpGDIDDSurface );
	HRESULT (__stdcall * GetMonitorFrequency)( WRAP* wrap, LPDWORD lpdwFrequency );
	HRESULT (__stdcall * GetScanLine)( WRAP* wrap, LPDWORD lpdwScanLine );
	HRESULT (__stdcall * GetVerticalBlankStatus)( WRAP* wrap, BOOL *lpbIsInVB );
	HRESULT (__stdcall * Initialize)( WRAP* wrap, GUID *lpGUID ); 
	HRESULT (__stdcall * RestoreDisplayMode)( WRAP* wrap );
	HRESULT (__stdcall * SetCooperativeLevel)( WRAP* wrap, HWND hWnd, DWORD dwFlags );
	HRESULT (__stdcall * SetDisplayMode)( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags );
	HRESULT (__stdcall * WaitForVerticalBlank)( WRAP* wrap, DWORD dwFlags, HANDLE hEvent );
	HRESULT (__stdcall * GetAvailableVidMem)( WRAP* wrap, LPDDSCAPS2 lpDDCaps, LPDWORD lpdwTotal, LPDWORD lpdwFree );
	HRESULT (__stdcall * GetSurfaceFromDC)( WRAP* wrap, HDC hdc, LPDIRECTDRAWSURFACE4* lplpDDSurface ); 
	HRESULT (__stdcall * RestoreAllSurfaces)( WRAP* wrap );
	HRESULT (__stdcall * TestCooperativeLevel)( WRAP* wrap );
	HRESULT (__stdcall * GetDeviceIdentifier)( WRAP* wrap, LPDDDEVICEIDENTIFIER pDDDI, DWORD dwFlags);
};

struct IDirectDraw7_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
	HRESULT (__stdcall * Compact)( WRAP* wrap );
	HRESULT (__stdcall * CreateClipper)( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWCLIPPER *lplpDDClipper, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreatePalette)( WRAP* wrap, DWORD dwFlags, LPPALETTEENTRY lpColorTable, LPDIRECTDRAWPALETTE *lplpDDPalette, IUnknown *pUnkOuter);
	HRESULT (__stdcall * CreateSurface)( WRAP* wrap, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPDIRECTDRAWSURFACE7 *lplpDDSurface, IUnknown *pUnkOuter);
	HRESULT (__stdcall * DuplicateSurface)( WRAP* wrap, LPDIRECTDRAWSURFACE7 lpDDSurface, LPDIRECTDRAWSURFACE7 *lplpDupDDSurface);
	HRESULT (__stdcall * EnumDisplayModes)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPVOID lpContext, LPDDENUMMODESCALLBACK2 lpEnumModesCallback);
	HRESULT (__stdcall * EnumSurfaces)( WRAP* wrap, DWORD dwFlags, LPDDSURFACEDESC2 lpDDSD, LPVOID lpContext, LPDDENUMSURFACESCALLBACK7 lpEnumSurfacesCallback);
	HRESULT (__stdcall * FlipToGDISurface)( WRAP* wrap );
	HRESULT (__stdcall * GetCaps)( WRAP* wrap, LPDDCAPS lpDDDriverCaps, LPDDCAPS lpDDHELCaps);
	HRESULT (__stdcall * GetDisplayMode)( WRAP* wrap, LPDDSURFACEDESC2 lpDDSurfaceDesc);
	HRESULT (__stdcall * GetFourCCCodes)( WRAP* wrap, LPDWORD lpNumCodes, LPDWORD lpCodes);
	HRESULT (__stdcall * GetGDISurface)( WRAP* wrap, LPDIRECTDRAWSURFACE7 *lplpGDIDDSurface);
	HRESULT (__stdcall * GetMonitorFrequency)( WRAP* wrap, LPDWORD lpdwFrequency);
	HRESULT (__stdcall * GetScanLine)( WRAP* wrap, LPDWORD lpdwScanLine);
	HRESULT (__stdcall * GetVerticalBlankStatus)( WRAP* wrap, BOOL *lpbIsInVB);
	HRESULT (__stdcall * Initialize)( WRAP* wrap, GUID *lpGUID); 
	HRESULT (__stdcall * RestoreDisplayMode)( WRAP* wrap );
	HRESULT (__stdcall * SetCooperativeLevel)( WRAP* wrap, HWND hWnd, DWORD dwFlags);
	HRESULT (__stdcall * SetDisplayMode)( WRAP* wrap, DWORD dwWidth, DWORD dwHeight, DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags);
	HRESULT (__stdcall * WaitForVerticalBlank)( WRAP* wrap, DWORD dwFlags, HANDLE hEvent);	
	HRESULT (__stdcall * GetAvailableVidMem)( WRAP* wrap, LPDDSCAPS2 lpDDCaps, LPDWORD lpdwTotal, LPDWORD lpdwFree);
	HRESULT (__stdcall * GetSurfaceFromDC)( WRAP* wrap, HDC hdc, LPDIRECTDRAWSURFACE7* lplpDDSurface);
	HRESULT (__stdcall * RestoreAllSurfaces)( WRAP* wrap );
	HRESULT (__stdcall * TestCooperativeLevel)( WRAP* wrap );
	HRESULT (__stdcall * GetDeviceIdentifier)( WRAP* wrap, LPDDDEVICEIDENTIFIER2 pDDDI, DWORD dwFlags);
	HRESULT (__stdcall * StartModeTest)( WRAP* wrap, LPSIZE pModes, DWORD dwNumModes, DWORD dwFlags);
	HRESULT (__stdcall * EvaluateMode)( WRAP* wrap, DWORD dwFlags, DWORD  *pTimeout);
};


IDirectDraw1_vtable dd1_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	dd1::Compact,
	dd1::CreateClipper,
	dd1::CreatePalette,
	dd1::CreateSurface,
	dd1::DuplicateSurface,
	dd1::EnumDisplayModes,
	dd1::EnumSurfaces,
	dd1::FlipToGDISurface,
	dd1::GetCaps,
	dd1::GetDisplayMode,
	dd1::GetFourCCCodes,
	dd1::GetGDISurface,
	dd1::GetMonitorFrequency,
	dd1::GetScanLine,
	dd1::GetVerticalBlankStatus,
	dd1::Initialize,
	dd1::RestoreDisplayMode,
	dd1::SetCooperativeLevel,
	dd1::SetDisplayMode,
	dd1::WaitForVerticalBlank
};

IDirectDraw2_vtable dd2_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	dd2::Compact,
	dd2::CreateClipper,
	dd2::CreatePalette,
	dd2::CreateSurface,
	dd2::DuplicateSurface,
	dd2::EnumDisplayModes,
	dd2::EnumSurfaces,
	dd2::FlipToGDISurface,
	dd2::GetCaps,
	dd2::GetDisplayMode,
	dd2::GetFourCCCodes,
	dd2::GetGDISurface,
	dd2::GetMonitorFrequency,
	dd2::GetScanLine,
	dd2::GetVerticalBlankStatus,
	dd2::Initialize,
	dd2::RestoreDisplayMode,
	dd2::SetCooperativeLevel,
	dd2::SetDisplayMode,
	dd2::WaitForVerticalBlank,
	dd2::GetAvailableVidMem
};

IDirectDraw4_vtable dd4_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	dd4::Compact,
	dd4::CreateClipper,
	dd4::CreatePalette,
	dd4::CreateSurface,
	dd4::DuplicateSurface,
	dd4::EnumDisplayModes,
	dd4::EnumSurfaces,
	dd4::FlipToGDISurface,
	dd4::GetCaps,
	dd4::GetDisplayMode,
	dd4::GetFourCCCodes,
	dd4::GetGDISurface,
	dd4::GetMonitorFrequency,
	dd4::GetScanLine,
	dd4::GetVerticalBlankStatus,
	dd4::Initialize,
	dd4::RestoreDisplayMode,
	dd4::SetCooperativeLevel,
	dd4::SetDisplayMode,
	dd4::WaitForVerticalBlank,
	dd4::GetAvailableVidMem,
	dd4::GetSurfaceFromDC,
	dd4::RestoreAllSurfaces,
	dd4::TestCooperativeLevel,
	dd4::GetDeviceIdentifier
};

IDirectDraw7_vtable dd7_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	dd7::Compact,
	dd7::CreateClipper,
	dd7::CreatePalette,
	dd7::CreateSurface,
	dd7::DuplicateSurface,
	dd7::EnumDisplayModes,
	dd7::EnumSurfaces,
	dd7::FlipToGDISurface,
	dd7::GetCaps,
	dd7::GetDisplayMode,
	dd7::GetFourCCCodes,
	dd7::GetGDISurface,
	dd7::GetMonitorFrequency,
	dd7::GetScanLine,
	dd7::GetVerticalBlankStatus,
	dd7::Initialize,
	dd7::RestoreDisplayMode,
	dd7::SetCooperativeLevel,
	dd7::SetDisplayMode,
	dd7::WaitForVerticalBlank,
	dd7::GetAvailableVidMem,
	dd7::GetSurfaceFromDC,
	dd7::RestoreAllSurfaces,
	dd7::TestCooperativeLevel,
	dd7::GetDeviceIdentifier,
	dd7::StartModeTest,
	dd7::EvaluateMode 
};
