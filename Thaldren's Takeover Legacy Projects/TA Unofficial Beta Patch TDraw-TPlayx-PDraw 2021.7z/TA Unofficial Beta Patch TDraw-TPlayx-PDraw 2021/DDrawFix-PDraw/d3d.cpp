#include "header.h"


namespace d3d1
{
	HRESULT __stdcall Initialize( WRAP* wrap, REFCLSID riid ) 
	{ 	
		RETURN( wrap->d3d1->Initialize( riid ) );  // Stub, D3D never implemented this method. 
	}
	HRESULT __stdcall  EnumDevices( WRAP* wrap, LPD3DENUMDEVICESCALLBACK lpEnumDevicesCallback, LPVOID lpUserArg )
	{
		RETURN( wrap->d3d1->EnumDevices( lpEnumDevicesCallback, lpUserArg ) );
	}
    HRESULT __stdcall CreateLight( WRAP* wrap, LPDIRECT3DLIGHT *lplpDirect3DLight, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d1->CreateLight( lplpDirect3DLight, pUnkOuter ) );
	}
    HRESULT __stdcall CreateMaterial( WRAP* wrap, LPDIRECT3DMATERIAL *lplpDirect3DMaterial, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d1->CreateMaterial( lplpDirect3DMaterial, pUnkOuter ) );
	}
    HRESULT __stdcall CreateViewport( WRAP* wrap, LPDIRECT3DVIEWPORT *lplpD3DViewport, IUnknown *pUnkOuter )
	{	
		RETURN( wrap->d3d1->CreateViewport(lplpD3DViewport, pUnkOuter ) );
	}
    HRESULT __stdcall FindDevice( WRAP* wrap, LPD3DFINDDEVICESEARCH lpD3DDFS, LPD3DFINDDEVICERESULT lplpD3DDevice )
	{
		RETURN( wrap->d3d1->FindDevice( lpD3DDFS, lplpD3DDevice ) );
	}
}


namespace d3d2
{
	HRESULT __stdcall  EnumDevices( WRAP* wrap, LPD3DENUMDEVICESCALLBACK lpEnumDevicesCallback, LPVOID lpUserArg )
	{
		RETURN( wrap->d3d2->EnumDevices( lpEnumDevicesCallback, lpUserArg ) );
	}
    HRESULT __stdcall CreateLight( WRAP* wrap, LPDIRECT3DLIGHT *lplpDirect3DLight, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d2->CreateLight( lplpDirect3DLight, pUnkOuter ) );
	}
    HRESULT __stdcall CreateMaterial( WRAP* wrap, LPDIRECT3DMATERIAL2 *lplpDirect3DMaterial2, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d2->CreateMaterial( lplpDirect3DMaterial2, pUnkOuter ) );
	}
    HRESULT __stdcall CreateViewport( WRAP* wrap, LPDIRECT3DVIEWPORT2 *lplpD3DViewport2, IUnknown *pUnkOuter )
	{	
		RETURN( wrap->d3d2->CreateViewport(lplpD3DViewport2, pUnkOuter ) );
	}
    HRESULT __stdcall FindDevice( WRAP* wrap, LPD3DFINDDEVICESEARCH lpD3DDFS, LPD3DFINDDEVICERESULT lplpD3DDevice )
	{
		RETURN( wrap->d3d2->FindDevice( lpD3DDFS, lplpD3DDevice ) );
	}
	HRESULT __stdcall CreateDevice( WRAP* wrap, REFCLSID rclsid, LPDIRECTDRAWSURFACE lpDDS, LPDIRECT3DDEVICE2 *lplpD3DDevice2 )
	{
		RETURN( wrap->d3d2->CreateDevice( rclsid, GetInterfacePtr( lpDDS ), lplpD3DDevice2 ) );
	}
}


namespace d3d3
{
	HRESULT __stdcall  EnumDevices( WRAP* wrap, LPD3DENUMDEVICESCALLBACK lpEnumDevicesCallback, LPVOID lpUserArg )
	{
		RETURN( wrap->d3d3->EnumDevices( lpEnumDevicesCallback, lpUserArg ) );
	}
    HRESULT __stdcall CreateLight( WRAP* wrap, LPDIRECT3DLIGHT *lplpDirect3DLight, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d3->CreateLight( lplpDirect3DLight, pUnkOuter ) );
	}
    HRESULT __stdcall CreateMaterial( WRAP* wrap, LPDIRECT3DMATERIAL3 *lplpDirect3DMaterial3, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d3->CreateMaterial( lplpDirect3DMaterial3, pUnkOuter ) );
	}
    HRESULT __stdcall CreateViewport( WRAP* wrap, LPDIRECT3DVIEWPORT3 *lplpD3DViewport3, IUnknown *pUnkOuter )
	{	
		RETURN( wrap->d3d3->CreateViewport(lplpD3DViewport3, pUnkOuter ) );
	}
    HRESULT __stdcall FindDevice( WRAP* wrap, LPD3DFINDDEVICESEARCH lpD3DDFS, LPD3DFINDDEVICERESULT lplpD3DDevice )
	{
		RETURN( wrap->d3d3->FindDevice( lpD3DDFS, lplpD3DDevice ) );
	}
	HRESULT __stdcall CreateDevice( WRAP* wrap, REFCLSID rclsid, LPDIRECTDRAWSURFACE4 lpDDS, LPDIRECT3DDEVICE3 *lplpD3DDevice3, IUnknown *pUnkOuter )
	{
		RETURN( wrap->d3d3->CreateDevice( rclsid, GetInterfacePtr( lpDDS ), lplpD3DDevice3, pUnkOuter ) );
	}
	HRESULT __stdcall CreateVertexBuffer( WRAP* wrap, LPD3DVERTEXBUFFERDESC lpD3DVertBufDesc, LPDIRECT3DVERTEXBUFFER *lplpD3DVertBuf, DWORD dwFlags, LPUNKNOWN lpUnk)
	{
		RETURN( wrap->d3d3->CreateVertexBuffer( lpD3DVertBufDesc, lplpD3DVertBuf, dwFlags, lpUnk ) );
	}
    HRESULT __stdcall EnumZBufferFormats( WRAP* wrap, REFCLSID riidDevice, LPD3DENUMPIXELFORMATSCALLBACK lpEnumCallback, LPVOID lpContext )
	{
		RETURN( wrap->d3d3->EnumZBufferFormats( riidDevice, lpEnumCallback, lpContext ) );
	}
    HRESULT __stdcall EvictManagedTextures( WRAP* wrap )
	{
		RETURN( wrap->d3d3->EvictManagedTextures() );
	}
}


namespace d3d7
{
	HRESULT __stdcall  EnumDevices( WRAP* wrap, LPD3DENUMDEVICESCALLBACK7 lpEnumDevicesCallback, LPVOID lpUserArg )
	{
		RETURN( wrap->d3d7->EnumDevices( lpEnumDevicesCallback, lpUserArg ) );
	}
	HRESULT __stdcall CreateDevice( WRAP* wrap, REFCLSID rclsid, LPDIRECTDRAWSURFACE7 lpDDS, LPDIRECT3DDEVICE7 *lplpD3DDevice )
	{
		RETURN( wrap->d3d7->CreateDevice( rclsid, GetInterfacePtr( lpDDS ), lplpD3DDevice ) );
	}
	HRESULT __stdcall CreateVertexBuffer( WRAP* wrap, LPD3DVERTEXBUFFERDESC lpD3DVertBufDesc, LPDIRECT3DVERTEXBUFFER7 *lplpD3DVertBuf, DWORD dwFlags )
	{
		RETURN( wrap->d3d7->CreateVertexBuffer( lpD3DVertBufDesc, lplpD3DVertBuf, dwFlags ) );
	}
    HRESULT __stdcall EnumZBufferFormats( WRAP* wrap, REFCLSID riidDevice, LPD3DENUMPIXELFORMATSCALLBACK lpEnumCallback, LPVOID lpContext )
	{
		RETURN( wrap->d3d7->EnumZBufferFormats( riidDevice, lpEnumCallback, lpContext ) );
	}
    HRESULT __stdcall EvictManagedTextures( WRAP* wrap )
	{
		RETURN( wrap->d3d7->EvictManagedTextures() );
	}
}


struct IDirect3D1_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
    HRESULT (__stdcall * Initialize)( WRAP* wrap, REFIID riid);
    HRESULT (__stdcall * EnumDevices)( WRAP* wrap, LPD3DENUMDEVICESCALLBACK lpEnumDevicesCallback, LPVOID lpUserArg);
    HRESULT (__stdcall * CreateLight)( WRAP* wrap, LPDIRECT3DLIGHT *lplpDirect3DLight, IUnknown *pUnkOuter);
    HRESULT (__stdcall * CreateMaterial)( WRAP* wrap, LPDIRECT3DMATERIAL *lplpDirect3DMaterial, IUnknown *pUnkOuter);
    HRESULT (__stdcall * CreateViewport)( WRAP* wrap, LPDIRECT3DVIEWPORT *lplpD3DViewport, IUnknown *pUnkOuter);
    HRESULT (__stdcall * FindDevice)( WRAP* wrap, LPD3DFINDDEVICESEARCH lpD3DDFS, LPD3DFINDDEVICERESULT lplpD3DDevice);
};

struct IDirect3D2_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
    HRESULT (__stdcall * EnumDevices)( WRAP* wrap, LPD3DENUMDEVICESCALLBACK lpEnumDevicesCallback, LPVOID lpUserArg);
    HRESULT (__stdcall * CreateLight)( WRAP* wrap, LPDIRECT3DLIGHT *lplpDirect3DLight, IUnknown *pUnkOuter);
    HRESULT (__stdcall * CreateMaterial)( WRAP* wrap, LPDIRECT3DMATERIAL2 *lplpDirect3DMaterial2, IUnknown *pUnkOuter);
    HRESULT (__stdcall * CreateViewport)( WRAP* wrap, LPDIRECT3DVIEWPORT2 *lplpD3DViewport2, IUnknown *pUnkOuter);
    HRESULT (__stdcall * FindDevice)( WRAP* wrap, LPD3DFINDDEVICESEARCH lpD3DDFS, LPD3DFINDDEVICERESULT lpD3DFDR);
    HRESULT (__stdcall * CreateDevice)( WRAP* wrap, REFCLSID rclsid, LPDIRECTDRAWSURFACE lpDDS, LPDIRECT3DDEVICE2 *lplpD3DDevice2);
};

struct IDirect3D3_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
	HRESULT (__stdcall * EnumDevices)( WRAP* wrap, LPD3DENUMDEVICESCALLBACK lpEnumDevicesCallback, LPVOID lpUserArg);
    HRESULT (__stdcall * CreateLight)( WRAP* wrap, LPDIRECT3DLIGHT *lplpDirect3DLight, IUnknown *pUnkOuter);
    HRESULT (__stdcall * CreateMaterial)( WRAP* wrap, LPDIRECT3DMATERIAL3 *lplpDirect3DMaterial3, IUnknown *pUnkOuter);
    HRESULT (__stdcall * CreateViewport)( WRAP* wrap, LPDIRECT3DVIEWPORT3 *lplpD3DViewport3, IUnknown *pUnkOuter);
    HRESULT (__stdcall * FindDevice)( WRAP* wrap, LPD3DFINDDEVICESEARCH lpD3DDFS, LPD3DFINDDEVICERESULT lpD3DFDR);
    HRESULT (__stdcall * CreateDevice)( WRAP* wrap, REFCLSID rclsid,LPDIRECTDRAWSURFACE4 lpDDS, LPDIRECT3DDEVICE3 *lplpD3DDevice3,LPUNKNOWN lpUnk);
    HRESULT (__stdcall * CreateVertexBuffer)( WRAP* wrap, LPD3DVERTEXBUFFERDESC lpD3DVertBufDesc,LPDIRECT3DVERTEXBUFFER *lplpD3DVertBuf,DWORD dwFlags,LPUNKNOWN lpUnk);
    HRESULT (__stdcall * EnumZBufferFormats)( WRAP* wrap, REFCLSID riidDevice,LPD3DENUMPIXELFORMATSCALLBACK lpEnumCallback,LPVOID lpContext);
    HRESULT (__stdcall * EvictManagedTextures)(WRAP* wrap);
};

struct IDirect3D7_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
    HRESULT (__stdcall * EnumDevices)( WRAP* wrap, LPD3DENUMDEVICESCALLBACK7 lpEnumDevicesCallback, LPVOID lpUserArg);
    HRESULT (__stdcall * CreateDevice)( WRAP* wrap, REFCLSID rclsid,LPDIRECTDRAWSURFACE7 lpDDS, LPDIRECT3DDEVICE7 *lplpD3DDevice);
    HRESULT (__stdcall * CreateVertexBuffer)( WRAP* wrap, LPD3DVERTEXBUFFERDESC lpD3DVertBufDesc,LPDIRECT3DVERTEXBUFFER7 *lplpD3DVertBuf,DWORD dwFlags);
    HRESULT (__stdcall * EnumZBufferFormats)( WRAP* wrap, REFCLSID riidDevice,LPD3DENUMPIXELFORMATSCALLBACK lpEnumCallback,LPVOID lpContext);
    HRESULT (__stdcall * EvictManagedTextures)( WRAP* wrap );
};

IDirect3D1_vtable d3d1_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	d3d1::Initialize,
	d3d1::EnumDevices,
	d3d1::CreateLight,
	d3d1::CreateMaterial,
	d3d1::CreateViewport,
	d3d1::FindDevice
};

IDirect3D2_vtable d3d2_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	d3d2::EnumDevices,
	d3d2::CreateLight,
	d3d2::CreateMaterial,
	d3d2::CreateViewport,
	d3d2::FindDevice,
	d3d2::CreateDevice
};

IDirect3D3_vtable d3d3_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	d3d3::EnumDevices,
	d3d3::CreateLight,
	d3d3::CreateMaterial,
	d3d3::CreateViewport,
	d3d3::FindDevice,
	d3d3::CreateDevice,
	d3d3::CreateVertexBuffer,
	d3d3::EnumZBufferFormats,
	d3d3::EvictManagedTextures
};

IDirect3D7_vtable d3d7_vtable = { 
	unknwn::QueryInterface, 
	unknwn::AddRef,
	unknwn::Release,
	d3d7::EnumDevices,
	d3d7::CreateDevice,
	d3d7::CreateVertexBuffer,
	d3d7::EnumZBufferFormats,
	d3d7::EvictManagedTextures
};
