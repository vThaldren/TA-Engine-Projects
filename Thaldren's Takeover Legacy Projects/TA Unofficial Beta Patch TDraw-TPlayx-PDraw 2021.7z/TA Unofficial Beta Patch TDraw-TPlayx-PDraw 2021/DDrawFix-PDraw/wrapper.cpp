#include "header.h"

WRAP* tail = 0;
CRITICAL_SECTION WrapCriticalSection;


ULONG AddRefWrap( WRAP* wrapper )
{
	return (ULONG) InterlockedIncrement( &(wrapper->ref) );
}


ULONG ReleaseWrap( WRAP* wrapper )
{
	long count = InterlockedDecrement( &(wrapper->ref) );
	if( count == 0 ) DeleteWrap( wrapper ); 
	return (ULONG) count;
}


void DeleteWrap( WRAP* wrapper )
{
	if( wrapper && (wrapper->magic == 0x70617257) )
	{
		EnterCriticalSection(&WrapCriticalSection);
		if( tail == wrapper ) tail = wrapper->prev;
		if( wrapper->prev ) wrapper->prev->next = wrapper->next;
		if( wrapper->next ) wrapper->next->prev = wrapper->prev;
		free( wrapper );
		LeaveCriticalSection(&WrapCriticalSection);
	}
}


bool GetWrap( VOID** ppv, const GUID& riid )
{
	WRAP* wrapper;

	wrapper = *((WRAP**)ppv);
	if( wrapper && (wrapper->magic == 0x70617257) ) return true; // something is wrong it is already wrapped

	EnterCriticalSection(&WrapCriticalSection);
	for( wrapper = tail; wrapper; wrapper = wrapper->prev )
	{
		if( ( *ppv == wrapper->iunknown ) && ( riid == wrapper->iid ) ) // a wrapper already exists for this interface
		{ 
			*((WRAP**)ppv) = wrapper;
			AddRefWrap( wrapper );
			LeaveCriticalSection(&WrapCriticalSection);
			return true; 
		}
	}	



	// create new wrapper
	LOGGUID( riid );
	wrapper = (WRAP*) malloc( sizeof( WRAP ) );
	if( wrapper )
	{	
		if      ( riid == IID_IUnknown            ) wrapper -> vtable = &unkn_vtable;
		else if ( riid == IID_IClassFactory       ) wrapper -> vtable = &cf_vtable;
		else if ( riid == IID_IDirectDraw         ) wrapper -> vtable = &dd1_vtable;
		else if	( riid == IID_IDirectDraw2        ) wrapper -> vtable = &dd2_vtable;
		else if	( riid == IID_IDirectDraw4        ) wrapper -> vtable = &dd4_vtable;
		else if	( riid == IID_IDirectDraw7        ) wrapper -> vtable = &dd7_vtable;
		else if ( riid == IID_IDirectDrawSurface  ) wrapper -> vtable = &dds_vtable;
		else if ( riid == IID_IDirectDrawSurface2 ) wrapper -> vtable = &dds_vtable; 
		else if ( riid == IID_IDirectDrawSurface3 ) wrapper -> vtable = &dds_vtable;
		else if ( riid == IID_IDirectDrawSurface4 ) wrapper -> vtable = &dds_vtable;
		else if ( riid == IID_IDirectDrawSurface7 ) wrapper -> vtable = &dds_vtable;
		else if ( riid == IID_IDirectDrawClipper  ) wrapper -> vtable = &clip_vtable;
		else if ( riid == IID_IDirect3D2          ) wrapper -> vtable = &d3d2_vtable; // Dark Omen
		else 
		{
			if ( (riid == IID_IDDVideoPortContainer) || (riid == IID_IDirectDrawVideoPort) || (riid == IID_IDirectDrawVideoPortNotify) )
			{
				static bool warn_once = false;
				if( !warn_once )
				{
					warn_once = true;
					MessageBox( NULL, "Error: DirectDrawVideoPort is not yet supported.","aqrit's ddraw helper", MB_OK );
				}
			}
			// unsupport GUID ( IDirect3D3, IDirectD3D7, DirectDrawVideoPort, IID_IDirectDrawKernel, etc  )
			free( wrapper );
			LeaveCriticalSection(&WrapCriticalSection);
			return false;
		}

		wrapper -> magic  = 0x70617257; // "Wrap"
		wrapper -> iid = riid;
		wrapper -> iunknown = *((IUnknown**)ppv);
		*((WRAP**)ppv) = wrapper;
		wrapper -> ref    = 0;
		AddRefWrap( wrapper );
		wrapper -> next   = 0;
		wrapper -> prev   = tail;
		tail = wrapper;
		if( wrapper -> prev ) wrapper -> prev -> next = wrapper;
		LeaveCriticalSection(&WrapCriticalSection);
		return true;
	}

	LeaveCriticalSection(&WrapCriticalSection);
	return false;
}


IUnknown* GetInterfacePtr( IUnknown* wrapper )
{
	WRAP* p = (WRAP*) wrapper;
	if( p && (p->magic == 0x70617257) ) return p->iunknown;
	return wrapper; // nullptr or not wrapped
}
IDirectDraw*         GetInterfacePtr( IDirectDraw*         wrapper ){ return (IDirectDraw*        ) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDraw2*        GetInterfacePtr( IDirectDraw2*        wrapper ){ return (IDirectDraw2*       ) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDraw4*        GetInterfacePtr( IDirectDraw4*        wrapper ){ return (IDirectDraw4*       ) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDraw7*        GetInterfacePtr( IDirectDraw7*        wrapper ){ return (IDirectDraw7*       ) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDrawSurface*  GetInterfacePtr( IDirectDrawSurface*  wrapper ){ return (IDirectDrawSurface* ) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDrawSurface2* GetInterfacePtr( IDirectDrawSurface2* wrapper ){ return (IDirectDrawSurface2*) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDrawSurface3* GetInterfacePtr( IDirectDrawSurface3* wrapper ){ return (IDirectDrawSurface3*) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDrawSurface4* GetInterfacePtr( IDirectDrawSurface4* wrapper ){ return (IDirectDrawSurface4*) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDrawSurface7* GetInterfacePtr( IDirectDrawSurface7* wrapper ){ return (IDirectDrawSurface7*) GetInterfacePtr( (IUnknown*) wrapper ); }
IDirectDrawClipper*  GetInterfacePtr( IDirectDrawClipper*  wrapper ){ return (IDirectDrawClipper*)  GetInterfacePtr( (IUnknown*) wrapper ); }


HRESULT __stdcall EnumSurfaces1Callback( LPDIRECTDRAWSURFACE lpDDSurface, LPDDSURFACEDESC lpDDSurfaceDesc, LPVOID lpContext )
{
	EnumStruct* e = (EnumStruct*)lpContext;
	GetWrap( (void**)&lpDDSurface, IID_IDirectDrawSurface ); 
	return ((LPDDENUMSURFACESCALLBACK) e->lpOriginalCallback)( lpDDSurface, lpDDSurfaceDesc, e->lpOriginalContext );
}

HRESULT __stdcall EnumSurfaces4Callback( LPDIRECTDRAWSURFACE4 lpDDSurface, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPVOID lpContext )
{
	EnumStruct* e = (EnumStruct*)lpContext;
	GetWrap( (void**)&lpDDSurface, IID_IDirectDrawSurface4 );
	return ((LPDDENUMSURFACESCALLBACK2) e->lpOriginalCallback)( lpDDSurface, lpDDSurfaceDesc, e->lpOriginalContext );
}

HRESULT __stdcall EnumSurfaces7Callback( LPDIRECTDRAWSURFACE7 lpDDSurface, LPDDSURFACEDESC2 lpDDSurfaceDesc, LPVOID lpContext )
{
	EnumStruct* e = (EnumStruct*)lpContext;
	GetWrap( (void**)&lpDDSurface, IID_IDirectDrawSurface7 );
	return ((LPDDENUMSURFACESCALLBACK7) e->lpOriginalCallback)( lpDDSurface, lpDDSurfaceDesc, e->lpOriginalContext );
}