#include "header.h"


namespace unknwn
{	
	// IUnknown methods       
	HRESULT __stdcall QueryInterface( WRAP* wrap, const IID& riid, void** ppvObject ) 
	{ 
		HRESULT hresult = wrap->iunknown->QueryInterface( riid, ppvObject );
		if( SUCCEEDED( hresult ) ) GetWrap( ppvObject, riid );
		return hresult;
	}
	ULONG __stdcall AddRef( WRAP* wrap ) 
	{ 
		AddRefWrap( wrap );
		return wrap->iunknown->AddRef(); 
	}
	ULONG __stdcall Release( WRAP* wrap ) 
	{ 	
		ULONG dwCount = wrap->iunknown->Release();
		if( dwCount == 0 ) DeleteWrap( wrap );
		else ReleaseWrap( wrap );
		return dwCount;
	}
};


namespace classfactory
{
	HRESULT __stdcall CreateInstance( WRAP* wrap,  IUnknown *pUnkOuter, REFIID riid, void **ppvObject )
	{
		HRESULT hresult = wrap->classfactory->CreateInstance( pUnkOuter, riid, ppvObject );
		if( SUCCEEDED( hresult ) ) GetWrap( ppvObject, riid );
		return hresult;
	}

	HRESULT __stdcall LockServer( WRAP* wrap, BOOL fLock )
	{
		return wrap->classfactory->LockServer( fLock ); 
	} 
};


struct IUnknown_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG (__stdcall * Release)( WRAP* wrap ); 
};


struct IClassFactory_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG (__stdcall * Release)( WRAP* wrap ); 
	HRESULT (__stdcall * CreateInstance)( WRAP* wrap,  IUnknown *pUnkOuter, REFIID riid, void **ppvObject );
	HRESULT (__stdcall * LockServer)( WRAP* wrap, BOOL fLock );
};


IUnknown_vtable unkn_vtable = 
{ 
	unknwn::QueryInterface, 
	unknwn::AddRef, 
	unknwn::Release 
};


IClassFactory_vtable cf_vtable = 
{ 
	unknwn::QueryInterface, 
	unknwn::AddRef, 
	unknwn::Release,
	classfactory::CreateInstance,
	classfactory::LockServer
};



