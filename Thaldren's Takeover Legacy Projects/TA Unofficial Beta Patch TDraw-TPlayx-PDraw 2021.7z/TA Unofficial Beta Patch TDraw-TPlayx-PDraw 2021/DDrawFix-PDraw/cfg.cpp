#include "header.h"



CONFIG Config;



// any C++ style (both inline and block) commented text is replaced with a space character 
// todo: skip comments inside double quotes
void EraseCppComments( char* str )
{
	while( str = strchr( str, '/' ) )
	{
		if( str[1] == '/'  ) for( ; ((*str != '\0') && (*str != '\n')); str++ ) *str = '\x20';
		else if( str[1] == '*'  )
		{
			for( ; ((*str != '\0') && ((str[0] != '*') || (str[1] != '/'))); str++ ) *str = '\x20';
			if( *str ){ *str++ = '\x20'; *str = '\x20'; }
		}
		if( *str ) str++;
		else break;
	}
}

// [sections] are ignored
// escape characters NOT support 
// double quotes NOT suppoted
// Name/value delimiter is an equal sign or colon 
// whitespace is removed from before and after both the name and value
// characters considered to be whitespace:
//  0x20 - space
//	0x09 - horizontal tab
//	0x0D - carriage return
typedef VOID (__stdcall* NV)( CHAR* name, CHAR* value );
VOID Parse( CHAR* str, NV NameValueCallback )
{
	EraseCppComments( str );
	for( str = strtok( str, "\n" ); str; str = strtok( 0, "\n" ) )
	{
		if( *str == ';' || *str == '#' ) continue; // skip INI style comments ( must be at start of line )
		char* rvalue = strchr( str, '=' );
		if( !rvalue ) rvalue = strchr( str, ':' );
		if( rvalue )
		{
			*rvalue++ = '\0'; // split left and right values

			rvalue = &rvalue[ strspn( rvalue, "\x20\t\r") ]; // skip beginning whitespace
			for( char* end = strchr( rvalue, '\0' ); (--end >= rvalue) && ( *end == '\x20' || *end == '\t' || *end == '\r' );) *end = '\0';  // truncate ending whitespace

			char* lvalue = &str[ strspn( str, "\x20\t\r") ]; // skip beginning whitespace
			for( char* end = strchr( lvalue, '\0' ); (--end >= lvalue) && ( *end == '\x20' || *end == '\t' || *end == '\r' );) *end = '\0';  // truncate ending whitespace

			if( *lvalue && *rvalue ) NameValueCallback( lvalue, rvalue );
		}
	}
}


CHAR* Read( CHAR* szFileName )
{
	HANDLE hFile;
	DWORD dwBytesToRead;
	DWORD dwBytesRead;

	CHAR* szCfg = NULL;
	hFile = CreateFile(szFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if(hFile != INVALID_HANDLE_VALUE)
	{
		dwBytesToRead = GetFileSize(hFile, NULL);
		if((dwBytesToRead != 0) && (dwBytesToRead != 0xFFFFFFFF))
		{
			szCfg = (CHAR*) malloc( dwBytesToRead + 1 ); // +1 so a null terminator can be added
			if( szCfg != NULL)
			{
				if( ReadFile(hFile, szCfg, dwBytesToRead, &dwBytesRead, NULL) )
				{
					if( dwBytesRead != 0 ) szCfg[ dwBytesRead ] = '\0'; // make txt file easy to deal with 
				} else {
					free( szCfg );
					szCfg = NULL;
				}
			}	
		}
		CloseHandle(hFile);
	}
	return szCfg;
}


VOID __stdcall ParseCallback( CHAR* name, CHAR* value )
{
	if( ! strcmpi_s( name, -1, "ForceDirectDrawEmulation" ) ) { Config.ForceHEL           = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "FakeVsync"                ) ) { Config.FakeVsync          = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "FakeVsyncInterval"        ) ) { Config.FakeVsyncInterval  = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "DisableHighDpiScaling"    ) ) { Config.DpiAware           = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "BltMirror"                ) ) { Config.BltMirror          = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "BltNoTearing"             ) ) { Config.BltNoTearing       = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "ForceBltNoTearing"        ) ) { Config.ForceBltNoTearing  = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "SingleProcAffinity"       ) ) { Config.Affinity           = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "ColorFix"                 ) ) { Config.ColorFix           = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "NoVideoMemory"            ) ) { Config.NoVidMem           = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "ShowFPS"                  ) ) { Config.ShowFPS            = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "Wine_Diablo"              ) ) { Config.Wine_Diablo        = atoi( value ); return; }
	if( ! strcmpi_s( name, -1, "RealDDrawPath"            ) )
	{
		if( ! strcmpi_s( value, 5, "AUTO" ) != 0 ) Config.szDDrawPath[0] = '\0';
		else{
			if( strlen( value ) <= MAX_PATH ) 
			{
				strcpy( Config.szDDrawPath, value );
			}
		}
	}
}

/*
// this test is pointless... we can't wait to see if ddraw goes fullscreen
// SetProcessDPIAware's only effect is to disable high dpi scaling anyways
// so we might as well just call SetProcessDPIAware (If it exists)
BOOL TestHighDpiScaling()
{
	int x = 96;
	int y = 96;
	HDC hdc = GetDC(NULL);
	if (hdc)
	{
		x = GetDeviceCaps(hdc, LOGPIXELSX);
		y = GetDeviceCaps(hdc, LOGPIXELSY);
		ReleaseDC(NULL, hdc);
	}

	// DPI virtualization kicks in when greater than 120
	if( x > 120 || y > 120 ) return TRUE;
	return FALSE;
}
*/
/*
DPI virtualization causes:
Text Clipping, Blurring, or Inconsistent font sizes.
"Rendering of full-screen DX applications partially off screen" - Mircosoft
...drawing(writting) to someplace that doesn't exist may cause crashes... 
if your going to Disable DPI Scaling then do it as soon as possible
*/
void DisableHighDPIScaling()
{
	// use GetProcAddress because SetProcessDPIAware exists only on win6+
	// and "High" dpi scaling only exits on win6+?
	HMODULE hUser32 = GetModuleHandle( "user32.dll" );
	typedef BOOL (__stdcall* SetProcessDPIAwareFunc)();
	if( hUser32 )
	{
		SetProcessDPIAwareFunc setDPIAware = (SetProcessDPIAwareFunc)GetProcAddress(hUser32, "SetProcessDPIAware");
		if (setDPIAware) setDPIAware();
	}
}

// call WaitForVerticalBlank and check the return value
BOOL TestVsync( WRAP* dd )
{ 
	return ( SUCCEEDED( dd->dd1->WaitForVerticalBlank( DDWAITVB_BLOCKBEGIN, 0 ) ) ); 
}

// blt( mirror ) then check the surface to see if it worked
// CooperativeLevel must be set for surface creation to succeed
DWORD TestBltMirror( WRAP* dd, DWORD dwDescSize )
{
	DWORD result = -1; // undecided
	LPDIRECTDRAWSURFACE surf_src;
	LPDIRECTDRAWSURFACE surf_dest;
	DDSURFACEDESC2 ddsd;

	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize = dwDescSize;
	ddsd.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS;
	ddsd.dwWidth = 10;
	ddsd.dwHeight = 10;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	if( SUCCEEDED( dd->dd1->CreateSurface((DDSURFACEDESC*)&ddsd, &surf_src, NULL) ) )
	{
		if( SUCCEEDED( dd->dd1->CreateSurface((DDSURFACEDESC*)&ddsd, &surf_dest, NULL) ) )
		{
			HDC hdc;
			if(SUCCEEDED( surf_src->GetDC(&hdc) ))
			{
				COLORREF cr1 = SetPixel(hdc, 0, 0, 0x00000000); // black
				COLORREF cr2 = SetPixel(hdc, ddsd.dwWidth - 1, ddsd.dwHeight - 1, 0x00FFFFFF); // white
				surf_src->ReleaseDC(hdc);
				if( (cr1 != -1) && (cr2 != -1) && (cr1 != cr2) )
				{
					DDBLTFX fx;
					memset( &fx, 0, sizeof(fx) );
					fx.dwSize = sizeof(fx);
					fx.dwDDFX = DDBLTFX_MIRRORLEFTRIGHT | DDBLTFX_MIRRORUPDOWN;
					if(SUCCEEDED( surf_dest->Blt( NULL, surf_src, NULL, DDBLT_WAIT | DDBLT_DDFX, &fx )))
					{
						if(SUCCEEDED( surf_dest->GetDC(&hdc) ))
						{
							if( (cr2 != GetPixel( hdc, 0, 0 )) || ( cr1 != GetPixel( hdc, ddsd.dwWidth - 1, ddsd.dwHeight - 1 )) ) 
							{
								result = FALSE; // mirroring is broken
							}
							if( (cr2 == GetPixel( hdc, 0, 0 )) && ( cr1 == GetPixel( hdc, ddsd.dwWidth - 1, ddsd.dwHeight - 1 )) ) 
							{
								result = TRUE; // mirroring works 
							}
							surf_dest->ReleaseDC(hdc);
						}
					}
				}
			}
			surf_dest->Release();
		}
		surf_src->Release();
	}	
	return result;
}

/*
// test needs cooplevel exclusive
// 	if( Config.FullFlip  == 2 ) Config.FullFlip  = TestFlip( wrap, sizeof(DDSURFACEDESC) ) ? FALSE : TRUE;
// todo: what about flipping overlays in windowed mode?
DWORD TestFlip( WRAP* dd, DWORD dwDescSize )
{
	DDSURFACEDESC2 ddsd;
	DDSCAPS2 ddscaps;
	LPDIRECTDRAWSURFACE front;
	LPDIRECTDRAWSURFACE back;
	DWORD result = -1; // undecided

	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize = dwDescSize;
	ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount = 1;
	if( SUCCEEDED( dd->dd1->CreateSurface((DDSURFACEDESC*)&ddsd, &front, NULL)))
	{			
		memset(&ddscaps, 0, sizeof(ddscaps));
		ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
		if( SUCCEEDED( front->GetAttachedSurface((DDSCAPS*)&ddscaps, &back) ) )
		{
			HDC hdc;
			if( SUCCEEDED( back->GetDC( &hdc ) ) )
			{
				COLORREF cr1 = SetPixel( hdc, 0, 0, 0x00FFFFFF ); // white
				back->ReleaseDC( hdc );
				if( cr1 != -1 )
				{
					if( SUCCEEDED( front->Flip( 0, DDFLIP_WAIT ) ) )
					{
						if( SUCCEEDED( back->GetDC( &hdc ) ) )
						{
							COLORREF cr2 = SetPixel( hdc, 0, 0, 0x00000000 ); // black
							back->ReleaseDC( hdc );
							if( (cr2 != -1) && (cr1 != cr2) )
							{
								if( SUCCEEDED( front->Flip( 0, DDFLIP_WAIT ) ) )
								{
									if( SUCCEEDED( back->GetDC( &hdc ) ) )
									{
										if( cr1 == GetPixel( hdc, 0, 0 ) )
										{
											result = TRUE; // flipped correctly
										}
										if( cr2 == GetPixel( hdc, 0, 0 ) )
										{
											result = FALSE; // fail to return front buffer 
										}
										back->ReleaseDC( hdc );
									}
								}
							}
						}
					}
				}
			}
			back->Release();
		}
		front->Release();
	}
	return result;
}
*/

VOID CONFIG::Init()
{
	Config.Affinity				= FALSE;
	Config.BltMirror			= FALSE;
	Config.BltNoTearing			= FALSE;
	Config.ColorFix				= FALSE;
	Config.DpiAware				= FALSE;
	Config.FakeVsync			= FALSE;
	Config.FakeVsyncInterval	= 16;
	Config.ForceBltNoTearing	= FALSE;
	Config.ForceHEL				= FALSE;
	Config.NoVidMem				= FALSE;
	Config.ShowFPS				= FALSE;
	Config.Wine_Diablo			= FALSE;
	Config.szDDrawPath[0] = '\0';

	CHAR* szCfg = Read( "aqrit.cfg" );
	if( szCfg )
	{
		Parse( szCfg, ParseCallback );
		free( szCfg );
	}

	if( Config.FakeVsyncInterval == 0 ) Config.FakeVsyncInterval = 16;
	if( Config.DpiAware ) DisableHighDPIScaling();
}