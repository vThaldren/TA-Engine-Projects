#pragma once
#pragma optimize( "g", off ) // do NOT replace my functions with CRT calls!


namespace my_no_crt{
	VOID* malloc ( size_t size );
	BOOL  free   ( VOID* lpMem );

	// string helpers
	void*   memchr  ( const void* pvBuf, int value, size_t cnt );
	int     memcmp  ( const void* pvBuf1, const void* pvBuf2, size_t cnt );
	void*   memcpy  ( void* pvDst, const void* pvSrc, size_t cnt );
	void*   memmove ( void* pvDst, const void* pvSrc, size_t cnt );
	void*   memset  ( void* pvDst, int fill, size_t cnt );
	char*   strcat  ( char* dst, const char* src );
	char*   strchr  ( const char* str, int value );
	int     strcmp  ( const char* str1, const char* str2 );
	char*   strcpy  ( char* dst, const char* src );
	size_t  strlen  ( const char* str );
	char*   strncat ( char* dst, char* src, size_t cnt );
	int     strncmp ( const char* str1, const char* str2, size_t cnt );
	char*   strncpy ( char* dst, const char* src, size_t cnt );
	char*   strrchr ( const char* str, int value);
	char*   strstr  ( const char* str, const char* sub_str );
	char*   strpbrk ( const char* str1, const char* str2 );
	size_t  strcspn ( const char* str1, const char* str2 );
	size_t  strspn  ( const char* str1, const char* str2 );
	char*   strtok  ( char *str1, const char *delimiters );
	// extensions //
	size_t  strnlen   ( const char* str, size_t cnt );
	size_t  atoi      ( char* szNum );
	int		strcmpi_s ( const char* str1, size_t cnt, const char* str2 );
	char*   strstri   ( const char* str, const char* sub_str );
}

#define malloc	my_no_crt::malloc
#define free	my_no_crt::free

#define memchr    my_no_crt::memchr
#define memcmp    my_no_crt::memcmp
#define memcpy    my_no_crt::memcpy
#define memmove   my_no_crt::memmove
#define memset    my_no_crt::memset
#define strcat    my_no_crt::strcat
#define strchr    my_no_crt::strchr
#define strcmp    my_no_crt::strcmp
#define strcpy    my_no_crt::strcpy
#define strlen    my_no_crt::strlen
#define strncat   my_no_crt::strncat
#define strncmp   my_no_crt::strncmp
#define strncpy   my_no_crt::strncpy
#define strrchr   my_no_crt::strrchr
#define strstr    my_no_crt::strstr
#define strpbrk   my_no_crt::strpbrk
#define strcspn   my_no_crt::strcspn
#define strspn    my_no_crt::strspn
#define strtok    my_no_crt::strtok

#define strnlen   my_no_crt::strnlen
#define atoi      my_no_crt::atoi
#define strcmpi_s my_no_crt::strcmpi_s
#define strstri	  my_no_crt::strstri