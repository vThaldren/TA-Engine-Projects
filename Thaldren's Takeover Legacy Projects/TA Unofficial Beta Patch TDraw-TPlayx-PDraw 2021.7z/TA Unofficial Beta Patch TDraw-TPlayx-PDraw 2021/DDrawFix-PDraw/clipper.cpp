#include "header.h"

namespace clipper1
{
	/////////////////////////////
	// IUnknown methods       
	/////////////////////////////
	HRESULT __stdcall QueryInterface( WRAP* wrap, const IID& riid, void** ppvObject) 
	{ 
		HRESULT hresult = wrap->clipper->QueryInterface( riid, ppvObject );
		if( SUCCEEDED( hresult ) ) GetWrap( ppvObject, riid );
		return hresult;
	}

	ULONG   __stdcall AddRef( WRAP* wrap ) 
	{ 
		AddRefWrap( wrap );
		return wrap->clipper->AddRef(); 
	}

	ULONG   __stdcall Release( WRAP* wrap ) 
	{ 	
		ULONG dwCount = wrap->clipper->Release();
		if( dwCount == 0 ) DeleteWrap( wrap );
		else ReleaseWrap( wrap );
		return dwCount;
	}

    /*** IDirectDrawClipper methods ***/
    HRESULT __stdcall GetClipList( WRAP* wrap, LPRECT lpRect, LPRGNDATA lpClipList, LPDWORD lpdwSize )
	{
		return wrap->clipper->GetClipList( lpRect, lpClipList, lpdwSize );
	}

    HRESULT __stdcall GetHWnd( WRAP* wrap, HWND* lphWnd )
	{
		return wrap->clipper->GetHWnd( lphWnd );
	}

    HRESULT __stdcall Initialize( WRAP* wrap, LPDIRECTDRAW lpDD, DWORD dwFlags )
	{
		return wrap->clipper->Initialize( GetInterfacePtr( lpDD ), dwFlags );
	}

    HRESULT __stdcall IsClipListChanged( WRAP* wrap, BOOL* lpbChanged )
	{
		return wrap->clipper->IsClipListChanged( lpbChanged );
	}

    HRESULT __stdcall SetClipList( WRAP* wrap, LPRGNDATA lpClipList, DWORD dwFlags )
	{
		return wrap->clipper->SetClipList( lpClipList, dwFlags );
	}

    HRESULT __stdcall SetHWnd( WRAP* wrap, DWORD dwFlags, HWND hWnd )
	{
		return wrap->clipper->SetHWnd( dwFlags, hWnd );
	}
};


struct IDirectDrawClipper_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap ); 
    HRESULT (__stdcall * GetClipList)( WRAP* wrap, LPRECT lpRect, LPRGNDATA lpClipList, LPDWORD lpdwSize );
    HRESULT (__stdcall * GetHWnd)( WRAP* wrap, HWND* lphWnd );
    HRESULT (__stdcall * Initialize)( WRAP* wrap, LPDIRECTDRAW lpDD, DWORD dwFlags );
    HRESULT (__stdcall * IsClipListChanged)( WRAP* wrap, BOOL* lpbChanged );
    HRESULT (__stdcall * SetClipList)( WRAP* wrap, LPRGNDATA lpClipList, DWORD dwFlags );
    HRESULT (__stdcall * SetHWnd)( WRAP* wrap, DWORD dwFlags, HWND hWnd );
};


IDirectDrawClipper_vtable clip_vtable = { 
	clipper1::QueryInterface,
	clipper1::AddRef,
	clipper1::Release, 
    clipper1::GetClipList,
    clipper1::GetHWnd,
    clipper1::Initialize,
    clipper1::IsClipListChanged,
    clipper1::SetClipList,
    clipper1::SetHWnd
};