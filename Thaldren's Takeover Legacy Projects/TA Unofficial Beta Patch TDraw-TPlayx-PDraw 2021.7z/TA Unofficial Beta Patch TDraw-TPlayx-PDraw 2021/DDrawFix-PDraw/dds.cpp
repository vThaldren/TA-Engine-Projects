#include "header.h"


namespace dds
{
	HRESULT __stdcall QueryInterface( WRAP* wrap, const IID& riid, void** ppvObject ) 
	{ 
		HRESULT hresult = wrap->dds1->QueryInterface( riid, ppvObject );
		if( SUCCEEDED( hresult ) ) GetWrap( ppvObject, riid );
		RETURN( hresult );
	}
	ULONG __stdcall AddRef( WRAP* wrap ) 
	{ 
		AddRefWrap( wrap );
		RETURN( wrap->dds1->AddRef() ); 
	}
	ULONG __stdcall Release( WRAP* wrap )
	{
		ULONG dwRefCount;

		if( g_lpDDSRealPrimary == wrap->dds1 )
		{
			dwRefCount = wrap->dds1->Release();
			if( dwRefCount == 0 ) g_lpDDSRealPrimary = NULL;
			// fall thru to delete or release wrap
		}
		else
		{
			if( g_lpDDSFakePrimary[0] == wrap->dds1 ) 
			{
				dwRefCount = wrap->dds1->Release();
				if( dwRefCount == 1 )
				{
					g_ShowDisplay = FALSE; // tell threadproc/timerproc to chill
					if( Config.NoVidMem == 1 )
					{
						WaitForSingleObject( g_hThread, Config.FakeVsyncInterval * 4 );  // wait for thread to exit
					}
					if( Config.NoVidMem == 2 )
					{
						KillTimer( 0, g_dwTimerId );
						Sleep( Config.FakeVsyncInterval * 2 ); // todo: <--- this not the best way to sync :p
					}
					for(int i = MAX_PRIMARYBUFFERS - 1; i >= 0; i-- ) // destroy fake primary
					{
						if( g_lpDDSFakePrimary[i] != NULL )
						{
							g_lpDDSFakePrimary[i]->DeleteAttachedSurface( 0, NULL );
							g_lpDDSFakePrimary[i]->Release();	
							g_lpDDSFakePrimary[i] = NULL;
						}
					}
					g_lpDDSRealPrimary->Release();	// release real primary
					g_lpDDSRealPrimary = NULL;
					dwRefCount = 0;
				}
				// fall thru to delete or release wrap
			}
			else 
			{
				dwRefCount = wrap->dds1->Release();
				// fall thru to delete or release wrap
			}
		}

		if( dwRefCount == 0 ) DeleteWrap( wrap );
		else ReleaseWrap( wrap );
		RETURN( dwRefCount );
	}
	// IDirectDrawSurface methods
    HRESULT __stdcall AddAttachedSurface( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSAttachedSurface ) { RETURN( wrap->dds1->AddAttachedSurface( GetInterfacePtr( lpDDSAttachedSurface ) ) ); }
    HRESULT __stdcall AddOverlayDirtyRect( WRAP* wrap, LPRECT lpRect ){ RETURN( wrap->dds1->AddOverlayDirtyRect(lpRect) ); }
	HRESULT __stdcall Blt( WRAP* wrap, LPRECT lpDestRect, LPDIRECTDRAWSURFACE lpDDSrcSurface, LPRECT lpSrcRect, DWORD dwFlags, LPDDBLTFX lpDDBltFx )
	{ 
		// Config.BltMirror support 
		// Config.BltNoTearing support
		// Config.ForceBltNoTearing support
		
		DDBLTFX fx;
		IDirectDraw* lpDD = NULL;
		IDirectDrawSurface* lpDDWorkSurface = NULL;
		bool HasFx = ( lpDDBltFx && ( sizeof( DDBLTFX ) == lpDDBltFx->dwSize ) );
		bool HasDDFX = ( HasFx && ( dwFlags & DDBLT_DDFX ) ); 

		/////////// unwrap interfaces //////////
		lpDDSrcSurface = GetInterfacePtr( lpDDSrcSurface ); 
		if( HasFx )
		{
			bool UsesPattern = false;
			if( dwFlags & DDBLT_ROP ) UsesPattern = RopUsesPattern( lpDDBltFx->dwROP );		
			if( dwFlags & DDBLT_DDROPS ) UsesPattern |= RopUsesPattern( lpDDBltFx->dwDDROP ); // roll the dice (probably DDBLT_DDROPS will never happen)
			if( UsesPattern || ( dwFlags & ( DDBLT_ALPHADESTSURFACEOVERRIDE | DDBLT_ALPHASRCSURFACEOVERRIDE | DDBLT_ZBUFFERDESTOVERRIDE | DDBLT_ZBUFFERSRCOVERRIDE )) )
			{
				memcpy( &fx, lpDDBltFx, sizeof(fx) );
				if( dwFlags & DDBLT_ALPHADESTSURFACEOVERRIDE ) fx.lpDDSAlphaDest   = GetInterfacePtr( fx.lpDDSAlphaDest   );
				if( dwFlags & DDBLT_ALPHASRCSURFACEOVERRIDE  ) fx.lpDDSAlphaSrc    = GetInterfacePtr( fx.lpDDSAlphaSrc    );
				if( dwFlags & DDBLT_ZBUFFERDESTOVERRIDE      ) fx.lpDDSZBufferDest = GetInterfacePtr( fx.lpDDSZBufferDest );
				if( dwFlags & DDBLT_ZBUFFERSRCOVERRIDE       ) fx.lpDDSZBufferSrc  = GetInterfacePtr( fx.lpDDSZBufferSrc  );
				if( UsesPattern )
				{
					if( ! IsBadReadPtr( fx.lpDDSPattern, 8 ) ) fx.lpDDSPattern = GetInterfacePtr( fx.lpDDSPattern );
				}
				lpDDBltFx = &fx;
			}
		}

		////////// mirroring ///////////
		if( ( Config.BltMirror == 1 ) && HasDDFX && ( lpDDBltFx->dwDDFX & ( DDBLTFX_MIRRORLEFTRIGHT | DDBLTFX_MIRRORUPDOWN ) ) )
		{
			if( SUCCEEDED( GetDDInterface_Internal( wrap, (LPVOID*) &lpDD ) ) )
			{
				// if lpSrcRect is NULL then we need to find the width and height of src (this can be done with GDI32.GetDeciceCaps)
				// but we also need to known what size DDSURFACEDESC_X struct to use so we can create a temp surface
				// so we'll determine the size of DDSURFACEDESC_X by querying for the height and width of the src surface 
				// of course we could just pass dwDescSize as an arg to BltProc...
				DDSURFACEDESC2 ddsd;
				DWORD dwDescSize = 0;
				ddsd.dwSize = sizeof( DDSURFACEDESC );
				if( SUCCEEDED( lpDDSrcSurface->GetSurfaceDesc( (LPDDSURFACEDESC)&ddsd ) )) dwDescSize = sizeof( DDSURFACEDESC );
				else{
					ddsd.dwSize = sizeof( DDSURFACEDESC2 ); // try it bigger (v4 and v7)
					if( SUCCEEDED( lpDDSrcSurface->GetSurfaceDesc( (LPDDSURFACEDESC)&ddsd ) )) dwDescSize = sizeof( DDSURFACEDESC2 );
				}
				if( dwDescSize ) 
				{
					DWORD dwX;
					DWORD dwY;
					DWORD dwWidth;
					DWORD dwHeight;
					if( lpSrcRect == NULL )
					{
						dwX = 0;
						dwY = 0;
						dwWidth  = ddsd.dwWidth;					
						dwHeight = ddsd.dwHeight;		
					} else {
						dwX = lpSrcRect->left;
						dwY = lpSrcRect->top;
						dwWidth  = lpSrcRect->right - lpSrcRect->left;
						dwHeight = lpSrcRect->bottom - lpSrcRect->top;
					}

					// create temp surface
					memset( &ddsd, 0, sizeof(ddsd) );
					ddsd.dwSize = dwDescSize;
					ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
					ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
					ddsd.dwWidth = dwWidth;
					ddsd.dwHeight = dwHeight;
					if( SUCCEEDED( lpDD->CreateSurface( (LPDDSURFACEDESC)&ddsd, &lpDDWorkSurface, NULL ) ) )
					{
						if( dwFlags & DDBLT_KEYSRC )
						{
							DDCOLORKEY ddck;
							if( SUCCEEDED( lpDDSrcSurface->GetColorKey( DDCKEY_SRCBLT, &ddck ) ) )
							{
								lpDDWorkSurface->SetColorKey( DDCKEY_SRCBLT, &ddck );
							}
						}

						// mirror src surface onto temp surface
						HDC hdcWork; 
						if( SUCCEEDED( lpDDWorkSurface->GetDC( &hdcWork ) ) )
						{
							HDC hdcSrc;
							if( SUCCEEDED( lpDDSrcSurface->GetDC( &hdcSrc ) ) )
							{	
								//	if( RC_STRETCHBLT & GetDeviceCaps( hdcSrc, RASTERCAPS ) )
								if( StretchBlt( 
									hdcWork, 0, 0, ddsd.dwWidth, ddsd.dwHeight,
									hdcSrc, 
									( lpDDBltFx->dwDDFX & DDBLTFX_MIRRORLEFTRIGHT ) ? (dwX + (dwWidth - 1)) : dwX,
									( lpDDBltFx->dwDDFX & DDBLTFX_MIRRORUPDOWN ) ? (dwY + (dwHeight - 1)) : dwY,
									( lpDDBltFx->dwDDFX & DDBLTFX_MIRRORLEFTRIGHT ) ? (~(dwWidth - 1)) : dwWidth,
									( lpDDBltFx->dwDDFX & DDBLTFX_MIRRORUPDOWN ) ? (~(dwHeight - 1)) : dwHeight,
									SRCCOPY ) )
								{
									lpDDBltFx->dwDDFX &= (~(DDBLTFX_MIRRORLEFTRIGHT | DDBLTFX_MIRRORUPDOWN));
									lpSrcRect = NULL;
									lpDDSrcSurface->ReleaseDC( hdcSrc );
									lpDDSrcSurface = lpDDWorkSurface;
								}
								else lpDDSrcSurface->ReleaseDC( hdcSrc );	
							}
							lpDDWorkSurface->ReleaseDC( hdcWork );	
						}		
					}
				}
			}
		}


		///////// NoTearing ///////////
		if( Config.ForceBltNoTearing == 1 )
		{
			if( ( wrap->dds1 == g_lpDDSRealPrimary ) || ( wrap->dds1 == g_lpDDSFakePrimary[0] ) ) // if dealing with the primary
			{
				// add no tearing flag //
				dwFlags |= DDBLT_DDFX;
				if( !HasFx )
				{
					memset( &fx, 0, sizeof( fx ) );
					fx.dwSize = sizeof( fx );
					lpDDBltFx = &fx;	
				}
				lpDDBltFx->dwDDFX |= DDBLTFX_NOTEARING;
			}
		}
		if( Config.BltNoTearing == 1 )
		{
			if( ( dwFlags & DDBLT_DDFX ) && ( lpDDBltFx->dwDDFX & DDBLTFX_NOTEARING ) ) // if has flag
			{
				lpDDBltFx->dwDDFX ^= DDBLTFX_NOTEARING; // strip flag
				// wait
				if( Config.FakeVsync ) FakeVsync( NULL );
				else if( ( lpDD != NULL ) || ( SUCCEEDED( GetDDInterface_Internal( wrap, (LPVOID*) &lpDD ) ) ) ) lpDD->WaitForVerticalBlank( DDWAITVB_BLOCKBEGIN, NULL );									
			}
		}


		/////////// Blitting /////////
		HRESULT hResult = wrap->dds1->Blt( lpDestRect, lpDDSrcSurface, lpSrcRect, dwFlags, lpDDBltFx ); 
		if(	lpDDWorkSurface ) lpDDWorkSurface->Release();
		if( lpDD ) lpDD->Release();

		////////// Show FPS /////////
		if( SUCCEEDED( hResult ) &&  ( Config.ShowFPS & 2 )  && ( ( wrap->dds1 == g_lpDDSRealPrimary ) || ( wrap->dds1 == g_lpDDSFakePrimary[0] ) ) ) 
		{
			//TrackFPS( TRUE );
			int x = 0;
			int y = 0;
			if( lpDestRect != NULL )
			{
				x = lpDestRect->left;
				y = lpDestRect->top;
			}
			//ShowFPS( wrap->dds1, x, y );
		}

		RETURN( hResult );
	}
    HRESULT __stdcall BltBatch( WRAP* wrap, LPDDBLTBATCH lpDDBltBatch, DWORD dwCount, DWORD dwFlags ) { RETURN( E_NOTIMPL ); }
    HRESULT __stdcall BltFast( WRAP* wrap, DWORD dwX, DWORD dwY, LPDIRECTDRAWSURFACE lpDDSrcSurface, LPRECT lpSrcRect, DWORD dwTrans ) 
	{
		HRESULT hResult = wrap->dds1->BltFast( dwX, dwY, GetInterfacePtr( lpDDSrcSurface ), lpSrcRect, dwTrans );
		if( SUCCEEDED( hResult ) &&  ( Config.ShowFPS & 4 )  && ( ( wrap->dds1 == g_lpDDSRealPrimary ) || ( wrap->dds1 == g_lpDDSFakePrimary[0] ) ) ) 
		{
			//TrackFPS( TRUE );
			//ShowFPS( wrap->dds1, dwX, dwY );
		}
		RETURN( hResult );
	}
    HRESULT __stdcall DeleteAttachedSurface( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWSURFACE lpDDSAttachedSurface){ RETURN( wrap->dds1->DeleteAttachedSurface( dwFlags, GetInterfacePtr( lpDDSAttachedSurface ) ) ); }
    HRESULT __stdcall EnumAttachedSurfaces( WRAP* wrap, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpEnumSurfacesCallback ) 
	{ 
		EnumStruct e;
		e.lpOriginalCallback = lpEnumSurfacesCallback;
		e.lpOriginalContext = lpContext;
		RETURN( wrap->dds1->EnumAttachedSurfaces( &e, &EnumSurfaces1Callback ) );
	}
	HRESULT __stdcall EnumOverlayZOrders( WRAP* wrap, DWORD dwFlags, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpfnCallback ) 
	{
		EnumStruct e;
		e.lpOriginalCallback = lpfnCallback;
		e.lpOriginalContext = lpContext;
		RETURN( wrap->dds1->EnumOverlayZOrders( dwFlags, &e, &EnumSurfaces1Callback ) );
	}
	HRESULT __stdcall Flip( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSurfaceTargetOverride, DWORD dwFlags ) 
	{ 
		if( Config.FakeVsync && (!( dwFlags & DDFLIP_NOVSYNC)) )
		{
			DWORD dwWait = 1;
			if( dwFlags & DDFLIP_INTERVAL2 ) dwWait = 2;
			else if( dwFlags & DDFLIP_INTERVAL3 ) dwWait = 3;
			else if( dwFlags & DDFLIP_INTERVAL4 ) dwWait = 4;
			while( dwWait-- ) FakeVsync( NULL );
			dwFlags &= ~( DDFLIP_INTERVAL2 | DDFLIP_INTERVAL3 | DDFLIP_INTERVAL4 | DDFLIP_DONOTWAIT );
			dwFlags |= DDFLIP_NOVSYNC;
		} 
		HRESULT hResult = wrap->dds1->Flip( GetInterfacePtr( lpDDSurfaceTargetOverride ), dwFlags );
		if( SUCCEEDED( hResult ) && ( Config.ShowFPS & 1 ) && ( ( wrap->dds1 == g_lpDDSRealPrimary ) || ( wrap->dds1 == g_lpDDSFakePrimary[0] ) ) ) 
		{
			//TrackFPS( TRUE );
			//ShowFPS( wrap->dds1, 0, 0 );
		}
		RETURN( hResult );
	}
    HRESULT __stdcall GetAttachedSurface( WRAP* wrap, LPDDSCAPS lpDDSCaps, LPDIRECTDRAWSURFACE* lplpDDAttachedSurface ) 
	{ 
		HRESULT hResult = wrap->dds1->GetAttachedSurface( lpDDSCaps, lplpDDAttachedSurface );
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDAttachedSurface, wrap->iid );
		RETURN( hResult );
	}
    HRESULT __stdcall GetBltStatus( WRAP* wrap, DWORD dwFlags ) { RETURN( wrap->dds1->GetBltStatus( dwFlags ) ); }
    HRESULT __stdcall GetCaps( WRAP* wrap, LPDDSCAPS lpDDSCaps ) 
	{ 
		HRESULT hResult = wrap->dds1->GetCaps( lpDDSCaps ); 
		if( SUCCEEDED( hResult ) && ( Config.NoVidMem != 0 ) )
		{
			if( wrap->dds1 == g_lpDDSFakePrimary[0] )
			{
				lpDDSCaps->dwCaps |= DDSCAPS_PRIMARYSURFACE;
			}
		}
		RETURN( hResult );
	}
    HRESULT __stdcall GetClipper( WRAP* wrap, LPDIRECTDRAWCLIPPER *lplpDDClipper ) 
	{ 
		HRESULT hResult = wrap->dds1->GetClipper( lplpDDClipper ); 
		if( SUCCEEDED( hResult ) ) GetWrap( (void**)lplpDDClipper, IID_IDirectDrawClipper );
		RETURN( hResult );
	}
    HRESULT __stdcall GetColorKey( WRAP* wrap, DWORD dwFlags, LPDDCOLORKEY lpDDColorKey ) { RETURN( wrap->dds1->GetColorKey( dwFlags, lpDDColorKey ) ); }
    HRESULT __stdcall GetDC( WRAP* wrap, HDC *lphDC ) { RETURN( wrap->dds1->GetDC( lphDC ) ); }
    HRESULT __stdcall GetFlipStatus( WRAP* wrap, DWORD dwFlags ){ RETURN( wrap->dds1->GetFlipStatus( dwFlags ) ); }
    HRESULT __stdcall GetOverlayPosition( WRAP* wrap, LPLONG lplX, LPLONG lplY ) { RETURN( wrap->dds1->GetOverlayPosition( lplX, lplY ) ); }
    HRESULT __stdcall GetPalette( WRAP* wrap, LPDIRECTDRAWPALETTE *lplpDDPalette ) { RETURN( wrap->dds1->GetPalette( lplpDDPalette ) ); }
	HRESULT __stdcall GetPixelFormat( WRAP* wrap, LPDDPIXELFORMAT lpDDPixelFormat ) { RETURN( wrap->dds1->GetPixelFormat( lpDDPixelFormat ) ); }
    HRESULT __stdcall GetSurfaceDesc( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc ) 
	{ 
		HRESULT hResult = wrap->dds1->GetSurfaceDesc( lpDDSurfaceDesc );
		if( SUCCEEDED( hResult ) && ( Config.NoVidMem != 0 ) )
		{
			if( wrap->dds1 == g_lpDDSFakePrimary[0] )
			{ // Blade Runner
				lpDDSurfaceDesc->ddsCaps.dwCaps |= DDSCAPS_PRIMARYSURFACE;
			}
		}
		RETURN( hResult );
	}
	HRESULT __stdcall Initialize( WRAP* wrap, LPDIRECTDRAW lpDD, LPDDSURFACEDESC lpDDSurfaceDesc )
	{ 
		RETURN( wrap->dds1->Initialize( GetInterfacePtr( lpDD ), lpDDSurfaceDesc ) ); 
	}
    HRESULT __stdcall IsLost( WRAP* wrap ) { RETURN( wrap->dds1->IsLost() ); }
    HRESULT __stdcall Lock( WRAP* wrap, LPRECT lpDestRect, LPDDSURFACEDESC lpDDSurfaceDesc, DWORD dwFlags, HANDLE hEvent )
	{ 
		RETURN( wrap->dds1->Lock( lpDestRect, lpDDSurfaceDesc, dwFlags, hEvent ) );
	}
    HRESULT __stdcall ReleaseDC( WRAP* wrap, HDC hDC ) { RETURN( wrap->dds1->ReleaseDC( hDC ) ); }
    HRESULT __stdcall Restore( WRAP* wrap ) { RETURN( wrap->dds1->Restore() ); }
    HRESULT __stdcall SetClipper( WRAP* wrap, LPDIRECTDRAWCLIPPER lpDDClipper ) 
	{ 
		RETURN( wrap->dds1->SetClipper( GetInterfacePtr( lpDDClipper ) ) ); 
	}
    HRESULT __stdcall SetColorKey( WRAP* wrap, DWORD dwFlags, LPDDCOLORKEY lpDDColorKey ) { RETURN( wrap->dds1->SetColorKey( dwFlags,lpDDColorKey ) ); }
    HRESULT __stdcall SetOverlayPosition( WRAP* wrap, LONG lX, LONG lY ) { RETURN( wrap->dds1->SetOverlayPosition( lX,lY ) ); }
    HRESULT __stdcall SetPalette( WRAP* wrap, LPDIRECTDRAWPALETTE lpDDPalette )
	{ 
		// only the primary surface affects the system palette
		// SetPalette( NULL ) or releasing a surface is the only way to detach
		if( wrap->dds1 == g_lpDDSFakePrimary[0] )
		{
			g_lpDDSRealPrimary->SetPalette( lpDDPalette );
		}
		RETURN( wrap->dds1->SetPalette( lpDDPalette ) ); 
	}
    HRESULT __stdcall Unlock( WRAP* wrap, LPVOID lpRect ) 
	{ 
		HRESULT hResult = wrap->dds1->Unlock( lpRect ); 
		if( SUCCEEDED( hResult ) && ( Config.ShowFPS & 8 ) && ( ( wrap->dds1 == g_lpDDSRealPrimary ) || ( wrap->dds1 == g_lpDDSFakePrimary[0] ) ) ) 
		{
			//TrackFPS( TRUE );
			//ShowFPS( wrap->dds1, 0, 0 );  // Unlock took something other than a lpRect in v1 ???
		}
		RETURN( hResult );
	}
	HRESULT __stdcall UpdateOverlay( WRAP* wrap, LPRECT lpSrcRect, LPDIRECTDRAWSURFACE lpDDDestSurface, LPRECT lpDestRect, DWORD dwFlags, LPDDOVERLAYFX lpDDOverlayFx ){ RETURN( wrap->dds1->UpdateOverlay( lpSrcRect, GetInterfacePtr( lpDDDestSurface ), lpDestRect, dwFlags, lpDDOverlayFx ) ); }
    HRESULT __stdcall UpdateOverlayDisplay( WRAP* wrap, DWORD dwFlags ) { RETURN( wrap->dds1->UpdateOverlayDisplay( dwFlags ) ); }
    HRESULT __stdcall UpdateOverlayZOrder( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWSURFACE lpDDSReference ) { RETURN( wrap->dds1->UpdateOverlayZOrder( dwFlags, GetInterfacePtr( lpDDSReference ) ) ); }
	// added in v2
    HRESULT __stdcall GetDDInterface( WRAP* wrap, LPVOID* lplpDD ) 
	{ 
		// theoretically returns IUnknown but some programs may cast it to a different interface pointer...
		// instead of querying for the interface.
		HRESULT hResult = wrap->dds2->GetDDInterface( lplpDD );
		if( SUCCEEDED( hResult ) )
		{
			if( wrap->iid == IID_IDirectDrawSurface4 ) GetWrap( lplpDD, IID_IDirectDraw4 ); 
			else if( wrap->iid == IID_IDirectDrawSurface7 ) GetWrap( lplpDD, IID_IDirectDraw7 ); 
			GetWrap( lplpDD, IID_IDirectDraw );
		}
		RETURN( hResult ); 
	}
    HRESULT __stdcall PageLock( WRAP* wrap, DWORD dwFlags ) { RETURN( wrap->dds2->PageLock( dwFlags ) ); }
    HRESULT __stdcall PageUnlock( WRAP* wrap, DWORD dwFlags ) { RETURN( wrap->dds2->PageUnlock( dwFlags ) ); }
    // added in v3
    HRESULT __stdcall SetSurfaceDesc( WRAP* wrap, LPDDSURFACEDESC lpDDSD, DWORD dwFlags ) { RETURN( wrap->dds3->SetSurfaceDesc( lpDDSD, dwFlags ) ); }
    // added in v4
    HRESULT __stdcall SetPrivateData( WRAP* wrap, const GUID & tag, LPVOID pData, DWORD cbSize, DWORD dwFlags ) { RETURN( wrap->dds4->SetPrivateData( tag, pData, cbSize, dwFlags ) ); }
    HRESULT __stdcall GetPrivateData( WRAP* wrap, const GUID & tag, LPVOID pBuffer, LPDWORD pcbBufferSize ) { RETURN( wrap->dds4->GetPrivateData( tag, pBuffer, pcbBufferSize ) ); }
    HRESULT __stdcall FreePrivateData( WRAP* wrap, const GUID & tag ) { RETURN( wrap->dds4->FreePrivateData( tag ) ); }
    HRESULT __stdcall GetUniquenessValue( WRAP* wrap, LPDWORD pValue ) { RETURN( wrap->dds4->GetUniquenessValue( pValue ) ); }
    HRESULT __stdcall ChangeUniquenessValue( WRAP* wrap ) { RETURN( wrap->dds4->ChangeUniquenessValue() ); }
    // added in v7
    HRESULT __stdcall SetPriority( WRAP* wrap, DWORD prio ) { RETURN( wrap->dds7->SetPriority( prio ) ); }
    HRESULT __stdcall GetPriority( WRAP* wrap, LPDWORD prio ) { RETURN( wrap->dds7->GetPriority( prio ) ); }
    HRESULT __stdcall SetLOD( WRAP* wrap, DWORD lod ) { RETURN( wrap->dds7->SetLOD( lod ) ); }
    HRESULT __stdcall GetLOD( WRAP* wrap, LPDWORD lod ) { RETURN( wrap->dds7->GetLOD( lod ) ); }
};


struct IDirectDrawSurface_vtable
{
	HRESULT (__stdcall * QueryInterface)( WRAP* wrap, const IID& riid, void** ppvObject ); 
	ULONG   (__stdcall * AddRef)( WRAP* wrap ); 
	ULONG   (__stdcall * Release)( WRAP* wrap );
	HRESULT (__stdcall * AddAttachedSurface)( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSAttachedSurface );
	HRESULT (__stdcall * AddOverlayDirtyRect)( WRAP* wrap, LPRECT lpRect );
	HRESULT (__stdcall * Blt)( WRAP* wrap, LPRECT lpDestRect, LPDIRECTDRAWSURFACE lpDDSrcSurface, LPRECT lpSrcRect, DWORD dwFlags, LPDDBLTFX lpDDBltFx );
	HRESULT (__stdcall * BltBatch)( WRAP* wrap, LPDDBLTBATCH lpDDBltBatch, DWORD dwCount, DWORD dwFlags );
	HRESULT (__stdcall * BltFast)( WRAP* wrap, DWORD dwX, DWORD dwY, LPDIRECTDRAWSURFACE lpDDSrcSurface, LPRECT lpSrcRect, DWORD dwTrans );
	HRESULT (__stdcall * DeleteAttachedSurface)( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWSURFACE lpDDSAttachedSurface );
	HRESULT (__stdcall * EnumAttachedSurfaces)( WRAP* wrap, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpEnumSurfacesCallback );
	HRESULT (__stdcall * EnumOverlayZOrders)( WRAP* wrap, DWORD dwFlags, LPVOID lpContext, LPDDENUMSURFACESCALLBACK lpfnCallback );
	HRESULT (__stdcall * Flip)( WRAP* wrap, LPDIRECTDRAWSURFACE lpDDSurfaceTargetOverride, DWORD dwFlags );
	HRESULT (__stdcall * GetAttachedSurface)( WRAP* wrap, LPDDSCAPS lpDDSCaps, LPDIRECTDRAWSURFACE *lplpDDAttachedSurface ); 
	HRESULT (__stdcall * GetBltStatus)( WRAP* wrap, DWORD dwFlags );
	HRESULT (__stdcall * GetCaps)( WRAP* wrap, LPDDSCAPS lpDDSCaps );
	HRESULT (__stdcall * GetClipper)( WRAP* wrap, LPDIRECTDRAWCLIPPER *lplpDDClipper );
	HRESULT (__stdcall * GetColorKey)( WRAP* wrap, DWORD dwFlags, LPDDCOLORKEY lpDDColorKey );
	HRESULT (__stdcall * GetDC)( WRAP* wrap, HDC *lphDC );
	HRESULT (__stdcall * GetFlipStatus)( WRAP* wrap, DWORD dwFlags );
	HRESULT (__stdcall * GetOverlayPosition)( WRAP* wrap, LPLONG lplX, LPLONG lplY );
	HRESULT (__stdcall * GetPalette)( WRAP* wrap, LPDIRECTDRAWPALETTE *lplpDDPalette );
	HRESULT (__stdcall * GetPixelFormat)( WRAP* wrap, LPDDPIXELFORMAT lpDDPixelFormat );
	HRESULT (__stdcall * GetSurfaceDesc)( WRAP* wrap, LPDDSURFACEDESC lpDDSurfaceDesc );
	HRESULT (__stdcall * Initialize)( WRAP* wrap, LPDIRECTDRAW lpDD, LPDDSURFACEDESC lpDDSurfaceDesc );
	HRESULT (__stdcall * IsLost)( WRAP* wrap );
	HRESULT (__stdcall * Lock)( WRAP* wrap, LPRECT lpDestRect, LPDDSURFACEDESC lpDDSurfaceDesc, DWORD dwFlags, HANDLE hEvent );
	HRESULT (__stdcall * ReleaseDC)( WRAP* wrap, HDC hDC );
	HRESULT (__stdcall * Restore)( WRAP* wrap );
	HRESULT (__stdcall * SetClipper)( WRAP* wrap, LPDIRECTDRAWCLIPPER lpDDClipper );
	HRESULT (__stdcall * SetColorKey)( WRAP* wrap, DWORD dwFlags, LPDDCOLORKEY lpDDColorKey );
	HRESULT (__stdcall * SetOverlayPosition)( WRAP* wrap, LONG lX, LONG lY );
	HRESULT (__stdcall * SetPalette)( WRAP* wrap, LPDIRECTDRAWPALETTE lpDDPalette );
	HRESULT (__stdcall * Unlock)( WRAP* wrap, LPVOID lpRect );
	HRESULT (__stdcall * UpdateOverlay)( WRAP* wrap, LPRECT lpSrcRect, LPDIRECTDRAWSURFACE lpDDDestSurface, LPRECT lpDestRect, DWORD dwFlags, LPDDOVERLAYFX lpDDOverlayFx );
	HRESULT (__stdcall * UpdateOverlayDisplay)( WRAP* wrap, DWORD dwFlags );
	HRESULT (__stdcall * UpdateOverlayZOrder)( WRAP* wrap, DWORD dwFlags, LPDIRECTDRAWSURFACE lpDDSReference );
    // added in v2
	HRESULT (__stdcall * GetDDInterface)( WRAP* wrap, LPVOID *lplpDD ); 
	HRESULT (__stdcall * PageLock)( WRAP* wrap, DWORD dwFlags );
	HRESULT (__stdcall * PageUnlock)( WRAP* wrap, DWORD dwFlags );
    // added in v3
	HRESULT (__stdcall * SetSurfaceDesc)( WRAP* wrap, LPDDSURFACEDESC lpDDSD, DWORD dwFlags );
    // added in v4
	HRESULT (__stdcall * SetPrivateData)( WRAP* wrap, const GUID & tag, LPVOID pData, DWORD cbSize, DWORD dwFlags );
	HRESULT (__stdcall * GetPrivateData)( WRAP* wrap, const GUID & tag, LPVOID pBuffer, LPDWORD pcbBufferSize );
	HRESULT (__stdcall * FreePrivateData)( WRAP* wrap, const GUID & tag );
	HRESULT (__stdcall * GetUniquenessValue)( WRAP* wrap, LPDWORD pValue );
	HRESULT (__stdcall * ChangeUniquenessValue)( WRAP* wrap );
    // added in v7
	HRESULT (__stdcall * SetPriority)( WRAP* wrap, DWORD prio );
	HRESULT (__stdcall * GetPriority)( WRAP* wrap, LPDWORD prio );
	HRESULT (__stdcall * SetLOD)( WRAP* wrap, DWORD lod );
	HRESULT (__stdcall * GetLOD)( WRAP* wrap, LPDWORD lod );
};

IDirectDrawSurface_vtable dds_vtable = {
	dds::QueryInterface, 
	dds::AddRef, 
	dds::Release,
	dds::AddAttachedSurface,
	dds::AddOverlayDirtyRect,
	dds::Blt,
	dds::BltBatch,
	dds::BltFast,
	dds::DeleteAttachedSurface,
	dds::EnumAttachedSurfaces,
	dds::EnumOverlayZOrders,
	dds::Flip,
	dds::GetAttachedSurface, 
	dds::GetBltStatus,
	dds::GetCaps,
	dds::GetClipper,
	dds::GetColorKey,
	dds::GetDC,
	dds::GetFlipStatus,
	dds::GetOverlayPosition,
	dds::GetPalette,
	dds::GetPixelFormat,
	dds::GetSurfaceDesc,
	dds::Initialize,
	dds::IsLost,
	dds::Lock,
	dds::ReleaseDC,
	dds::Restore,
	dds::SetClipper,
	dds::SetColorKey,
	dds::SetOverlayPosition,
	dds::SetPalette,
	dds::Unlock,
	dds::UpdateOverlay,
	dds::UpdateOverlayDisplay,
	dds::UpdateOverlayZOrder,
    // added in v2
	dds::GetDDInterface, 
	dds::PageLock,
	dds::PageUnlock,
    // added in v3
	dds::SetSurfaceDesc,
	// added in v4
	dds::SetPrivateData,
	dds::GetPrivateData,
	dds::FreePrivateData,
	dds::GetUniquenessValue,
	dds::ChangeUniquenessValue,
    // added in v7
	dds::SetPriority,
	dds::GetPriority,
	dds::SetLOD,
	dds::GetLOD
};
