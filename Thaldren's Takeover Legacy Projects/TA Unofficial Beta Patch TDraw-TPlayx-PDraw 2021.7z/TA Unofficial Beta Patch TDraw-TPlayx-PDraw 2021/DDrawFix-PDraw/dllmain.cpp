#include "header.h"


HMODULE g_hDll;

typedef BOOL (__stdcall* SetProcessAffinityMask_t)( HANDLE, DWORD );

BOOL __stdcall DllEntryPoint( HINSTANCE hDll, DWORD dwReason, LPVOID lpvReserved )
{
	g_hDll = hDll;
	switch(dwReason)
	{
		case DLL_PROCESS_ATTACH: 
			InitializeCriticalSection( &WrapCriticalSection );
			Config.Init( );
			if( Config.ShowFPS || Config.NoVidMem || Config.FakeVsync ) timeBeginPeriod( 1 );
			// fall thru to set affinity
		case DLL_THREAD_ATTACH:
		{
			if( Config.Affinity )
			{
				HANDLE hProcess = GetCurrentProcess();
				DWORD ProcessAffinityMask;
				DWORD SystemAffinityMask;
				if( GetProcessAffinityMask( hProcess, &ProcessAffinityMask, &SystemAffinityMask ) )
				{
					if( ProcessAffinityMask & 1 )
					{
						SetProcessAffinityMask_t spam = (SetProcessAffinityMask_t)GetProcAddress(GetModuleHandle("kernel32.dll"), "SetProcessAffinityMask");
						if( spam ) spam( hProcess, 1 );
						else SetThreadAffinityMask( GetCurrentThread(), 1 );
					}
				}
			}
			break;
		}
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if( Config.ShowFPS || Config.NoVidMem || Config.FakeVsync ) timeEndPeriod( 1 );
			DeleteCriticalSection( &WrapCriticalSection );
			break;
	}
	return TRUE;
}

