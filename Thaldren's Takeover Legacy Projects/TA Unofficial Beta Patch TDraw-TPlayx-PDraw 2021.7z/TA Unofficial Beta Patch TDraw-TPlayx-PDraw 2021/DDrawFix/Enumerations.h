#pragma once

enum STATUS
{
	SUCCESS,
	FAILURE
};

enum JUMP_TYPE
{
	JMP = 0xE9,
	CALL = 0xE8
};