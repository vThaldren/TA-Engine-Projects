void IncreaseWeaponID();
