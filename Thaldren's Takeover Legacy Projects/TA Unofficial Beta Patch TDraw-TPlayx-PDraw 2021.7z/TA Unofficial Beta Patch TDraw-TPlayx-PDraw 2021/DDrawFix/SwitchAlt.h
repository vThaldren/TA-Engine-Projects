#pragma once

class Switchalt
{
public:
	Switchalt (void)
	{
		;
	}
	Switchalt (BOOL IsSet);
	~Switchalt( )
	{
		;
	}
};
