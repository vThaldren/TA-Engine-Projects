extern char ThinFont[2048];
extern int FontOffsetUC[58][2];
extern int FontOffsetLC[26][2];
extern int SmallFontOffsetUC[58][2];
extern int SmallFontOffsetLC[26][2];


