/*#include "oddraw.h"

class tadrcfg
{
public:
	tadrcfg ();
	~tadrcfg ();
private:
	;
public:
	struct 
	{
		DWORD DialogPosX;
		DWORD DialogPosY;
		DWORD BackGround;
		DWORD KeyCode;
		DWORD WhiteboardKey;
		char ShareText[100];
		char Delay[10];
		BYTE VSync;
		BYTE OptimizeDT;
		BYTE FullRings;
		DWORD DisableDeInterlaceMovie;
	} Eye;

	struct
	{
		char Ver[100];
	} TAHook;
};*/