#pragma once

class IncreaseMixingBuffers
{
public:
	IncreaseMixingBuffers (DWORD num);
	~IncreaseMixingBuffers()
	{
		;
	}
};

