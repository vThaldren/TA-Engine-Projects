


#include "headers.h"
#include "patcher.h"



BOOL WINAPI DllMain(HINSTANCE hInstDll, DWORD fdwReason, LPVOID lpReserved)
{
	if (fdwReason == DLL_PROCESS_ATTACH)
	{
		// change DPI to 100

	}
	
	if (fdwReason == DLL_PROCESS_DETACH)
	{
		// restore original DPI

	}

	return TRUE;
}