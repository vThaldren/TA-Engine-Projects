#pragma once

#include "headers.h"
#include "valkyriecompat.h"



HANDLE(__stdcall* TA_GetCurrentProcess)() = (HANDLE(__stdcall*)())0x004FB0C8;
BOOL(__stdcall* TA_VirtualProtect)(LPVOID, SIZE_T, DWORD, PDWORD) = (BOOL(__stdcall*)(LPVOID, SIZE_T, DWORD, PDWORD))0x004FB086;
HMODULE(__stdcall* TA_GetModuleHandleA)(LPCSTR) = (HMODULE(__stdcall*)(LPCSTR))0x004FB0C2;
HANDLE(__stdcall* TA_CreateFileA)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE) = (HANDLE(__stdcall*)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE))0x0049F72E;
UINT(__stdcall* TA_GetPrivateProfileIntA)(LPCSTR, LPCSTR, INT, LPCSTR) = (UINT(__stdcall*)(LPCSTR, LPCSTR, INT, LPCSTR))0x0049F746;
DWORD(__stdcall* TA_GetModuleFileNameA)(HMODULE, LPSTR, DWORD) = (DWORD(__stdcall*)(HMODULE, LPSTR, DWORD))0x0049F782;
SHORT(__stdcall* TA_GetAsyncKeyState)(INT) = (SHORT(__stdcall*)(INT))0x004fb314;
HANDLE(__stdcall* TA_CreateSemaphoreA)(LPSECURITY_ATTRIBUTES, LONG, LONG, LPCSTR) = (HANDLE(__stdcall*)(LPSECURITY_ATTRIBUTES, LONG, LONG, LPCSTR))0x0049F7B2;
DWORD(__stdcall* TA_WaitForSingleObject)(HANDLE, DWORD) = (DWORD(__stdcall*)(HANDLE, DWORD))0x0049f770;
DWORD(__stdcall* TA_GetTickCount)() = (DWORD(__stdcall*)())0x0049F740;
HANDLE(__stdcall* TA_CreateThread)(LPSECURITY_ATTRIBUTES, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD) = (HANDLE(__stdcall*)(LPSECURITY_ATTRIBUTES, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD))0x004FB098;
void(__stdcall* TA_TestBuildSpot)(void) = (void(__stdcall*)(void))0x004197D0;
void(__stdcall* TA_MapClick)(void*) = (void(__stdcall*)(void*))0x00498F70;
void(__stdcall* TA_DrawRect)(RECT*, RECT*, int) = (void(__stdcall*)(RECT*, RECT*, int))0x004BF8C0;
unsigned short(__stdcall* TA_MouseUnit)(void) = (unsigned short(__stdcall*)(void))0x0048CD80;
HANDLE(__stdcall* TA_FindFirstFileA)(LPCSTR, LPWIN32_FIND_DATAA) = (HANDLE(__stdcall*)(LPCSTR, LPWIN32_FIND_DATAA))0x004FB19A;
INT(__stdcall* TA_MessageBoxA)(HWND, LPCSTR, LPCSTR, UINT) = (INT(__stdcall*)(HWND, LPCSTR, LPCSTR, UINT))0x0049F7F4;
void(__stdcall* TA_ShowText)(void*, char*, int, int) = (void(__stdcall*)(void*, char*, int, int))0x00463E50;
void(__stdcall* TA_InterpretCommand)(char*, int) = (void(__stdcall*)(char*, int))0x00417B50;
void(__stdcall* TA_UpdateLOSState)(int) = (void(__stdcall*)(int))0x004816A0;



unsigned int Temp1, Temp2, Temp3, Temp4, Temp5, Temp6, Temp7;
unsigned int Temp8, Temp9, Temp10, Temp11, Temp12, Temp13, Temp14;
unsigned int Temp15, Temp16, Temp17, Temp18, Temp19, Temp20, Temp21;
unsigned int Temp22, Temp23, Temp24, Temp25, Temp26, Temp27, Temp28;




struct HookStruct
{
	unsigned int Hook_Destination;
	unsigned int Hook_Function_Destination;
	unsigned int Hook_Return_Destination;

	unsigned char* Hook_Data;
	unsigned char* Original_Data;


};

//Hook();
//Hook(unsigned int, unsigned int, unsigned int, bool);
//void RePatch();
//void Revert();

struct PatchStruct
{
	unsigned int Patch_Destination;

	unsigned char* Patch_Data;
	unsigned char* Original_Data;

	unsigned int Patch_Size;


};

//Patch();
//Patch(unsigned int PatchDest, std::vector<unsigned char>, bool);
//void RePatch();
//void Revert();



void Hook(HookStruct* hook, unsigned int HookDest, unsigned int HookFuncDest, unsigned int HookRetDest, bool DoPatch)
{
	DWORD OldProtect;
	unsigned char* WritePtr;
	unsigned char* ReadPtr;
	int RelativeJump;

	hook->Hook_Destination = HookDest;
	hook->Hook_Function_Destination = HookFuncDest;
	hook->Hook_Return_Destination = HookRetDest;

	hook->Original_Data = (unsigned char*)____malloc(5);

	ReadPtr = (unsigned char*)HookDest;

	for (size_t i = 0; i < 5; i++)
	{
		hook->Original_Data[i] = ReadPtr[i];
	}

	hook->Hook_Data = (unsigned char*)____malloc(5);

	hook->Hook_Data[0] = 0xE9;

	RelativeJump = HookFuncDest - HookDest - 5;

	hook->Hook_Data[1] = unsigned char(RelativeJump & 0xFF);
	hook->Hook_Data[2] = unsigned char((RelativeJump >> 8) & 0xFF);
	hook->Hook_Data[3] = unsigned char((RelativeJump >> 16) & 0xFF);
	hook->Hook_Data[4] = unsigned char((RelativeJump >> 24) & 0xFF);

	if (DoPatch)
	{
		TA_VirtualProtect((LPVOID)HookDest, 5, PAGE_EXECUTE_READWRITE, &OldProtect);

		WritePtr = (unsigned char*)HookDest;

		for (int i = 0; i < 5; i++)
		{
			WritePtr[i] = hook->Hook_Data[i];
		}

		TA_VirtualProtect((LPVOID)HookDest, 5, OldProtect, &OldProtect);
	}
}

void RePatch(HookStruct* hook)
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	TA_VirtualProtect((LPVOID)hook->Hook_Destination, 5, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)hook->Hook_Destination;

	for (int i = 0; i < 5; i++)
	{
		WritePtr[i] = hook->Hook_Data[i];
	}

	TA_VirtualProtect((LPVOID)hook->Hook_Destination, 5, OldProtect, &OldProtect);
}

void Revert(HookStruct* hook)
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	TA_VirtualProtect((LPVOID)hook->Hook_Destination, 5, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)hook->Hook_Destination;

	for (size_t i = 0; i < 5; i++)
	{
		WritePtr[i] = hook->Original_Data[i];
	}

	TA_VirtualProtect((LPVOID)hook->Hook_Destination, 5, OldProtect, &OldProtect);
}


void Patch(PatchStruct* patch, unsigned int PatchDest, unsigned char* PatchData, size_t patchDataSize, bool DoPatch)
{
	DWORD OldProtect;
	unsigned char* WritePtr;
	unsigned char* ReadPtr;

	patch->Patch_Destination = PatchDest;

	patch->Patch_Size = patchDataSize;

	patch->Patch_Data = (unsigned char*)____malloc(patchDataSize);
	patch->Original_Data = (unsigned char*)____malloc(patchDataSize);

	for (size_t i = 0; i < patchDataSize; i++)
	{
		patch->Patch_Data[i] = PatchData[i];
	}

	ReadPtr = (unsigned char*)PatchDest;

	for (size_t i = 0; i < patchDataSize; i++)
	{
		patch->Original_Data[i] = ReadPtr[i];
	}

	if (DoPatch)
	{
		TA_VirtualProtect((LPVOID)PatchDest, patchDataSize, PAGE_EXECUTE_READWRITE, &OldProtect);

		WritePtr = (unsigned char*)PatchDest;

		for (size_t i = 0; i < patchDataSize; i++)
		{
			WritePtr[i] = patch->Patch_Data[i];
		}

		TA_VirtualProtect((LPVOID)PatchDest, patchDataSize, OldProtect, &OldProtect);
	}
}

void RePatch(PatchStruct* patch)
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	TA_VirtualProtect((LPVOID)patch->Patch_Destination, patch->Patch_Size, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)patch->Patch_Destination;

	for (size_t i = 0; i < patch->Patch_Size; i++)
	{
		WritePtr[i] = patch->Patch_Data[i];
	}

	TA_VirtualProtect((LPVOID)patch->Patch_Destination, patch->Patch_Size, OldProtect, &OldProtect);
}

void Revert(PatchStruct* patch)
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	TA_VirtualProtect((LPVOID)patch->Patch_Destination, patch->Patch_Size, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)patch->Patch_Destination;

	for (size_t i = 0; i < patch->Patch_Size; i++)
	{
		WritePtr[i] = patch->Original_Data[i];
	}

	TA_VirtualProtect((LPVOID)patch->Patch_Destination, patch->Patch_Size, OldProtect, &OldProtect);
}
