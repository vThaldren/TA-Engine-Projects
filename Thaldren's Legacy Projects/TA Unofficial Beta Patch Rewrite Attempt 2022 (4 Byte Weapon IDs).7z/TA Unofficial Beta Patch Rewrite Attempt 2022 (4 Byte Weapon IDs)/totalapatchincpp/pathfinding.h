#pragma once


#include "headers.h"



void Pathfinding()
{
	*(DWORD*)(0x0040EAD3 + 3) = 66650;
}