#pragma once


#include "headers.h"






int WINAPI WhiteboardWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

}