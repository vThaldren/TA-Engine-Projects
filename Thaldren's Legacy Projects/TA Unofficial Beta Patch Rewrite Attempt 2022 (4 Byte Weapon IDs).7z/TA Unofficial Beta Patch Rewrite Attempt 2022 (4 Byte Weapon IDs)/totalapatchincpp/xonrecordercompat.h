#pragma once



#define XONRECORDERCOMPAT

HANDLE (__stdcall* ____CreateFileMappingA)(HANDLE hFile, LPSECURITY_ATTRIBUTES lpFileMappingAttributes, DWORD flProtect, DWORD dwMaximumSizeHigh, DWORD dwMaximumSizeLow, LPCSTR lpName);
LPVOID (__stdcall* ____MapViewOfFile)(HANDLE hFileMappingObject, DWORD dwDesiredAccess, DWORD dwFileOffsetHigh, DWORD dwFileOffsetLow, SIZE_T dwNumberOfBytesToMap);
DWORD(__stdcall* ____GetLastError)();
BOOL (__stdcall* ____UnmapViewOfFile)(LPCVOID lpBaseAddress);
BOOL (__stdcall* ____CloseHandle)(HANDLE hObject);


struct XonShare
{
	char Chat[100];
	int NewData;
	int DeathStatus[10];
	int TAProgress;
	char PlayerNames[10][20];
	float IncomeM[10];
	float IncomeE[10];
	float TotalM[10];
	float TotalE[10];
	int PlayingDemo;
	int Allies[10];
	int Yehaplayground[10];
	float StoredM[10];
	float StoredE[10];
	float StorageM[10];
	float StorageE[10];
	int IsRunning;
	int EhaOff;
	char ToAllies[100];
	int ToAlliesLength;
	char  FromAllies[100];
	int FromAlliesLength;
	int MapX;
	int MapY;
	int OtherMapX[10];
	int OtherMapY[10];
	int F1Disable;
	int CommanderWarp;
	char MapName[100];
	int myCheats;
	int PlayerColors[10];
	int LockOn;
	int MaxUnits;
	int Ta3d;
	//int IsWatch;
	//int LosViewOn;
	//int WeaponIDLimit;
	//int MultiWeaponID;
	//unsigned int IniCRC;
};






HANDLE DataShareHandle;
XonShare* XonMappedView;



void XonRecorderCompat()
{
	____CreateFileMappingA = (HANDLE(__stdcall*)(HANDLE hFile, LPSECURITY_ATTRIBUTES lpFileMappingAttributes, DWORD flProtect, DWORD dwMaximumSizeHigh, DWORD dwMaximumSizeLow, LPCSTR lpName))0x004FB0FE;
	____MapViewOfFile = (HANDLE(__stdcall*)(HANDLE hFileMappingObject, DWORD dwDesiredAccess, DWORD dwFileOffsetHigh, DWORD dwFileOffsetLow, SIZE_T dwNumberOfBytesToMap))0x004FB0F8;
	____GetLastError = (DWORD (__stdcall*)())0x004FB0CE;
	____UnmapViewOfFile = (BOOL(__stdcall*)(LPCVOID lpBaseAddress))0x004FB104;
	____CloseHandle = (BOOL( __stdcall * )(HANDLE hObject))0x0049F728;

	bool AlreadyExists = false;





	DataShareHandle = ____CreateFileMappingA(
		(HANDLE)0xFFFFFFFF,
		NULL,
		PAGE_READWRITE,
		0,
		sizeof(XonShare),
		"TADemo-MKChat"
	);

	if (____GetLastError() == ERROR_ALREADY_EXISTS)
		AlreadyExists = true;

	XonMappedView = (XonShare*)____MapViewOfFile(
		DataShareHandle,
		FILE_MAP_ALL_ACCESS,
		0,
		0,
		sizeof(XonShare)
	);

	if (!AlreadyExists)
	{
		____memset(XonMappedView, 0, sizeof(XonShare));
	}
}






void XonRecorderCompatShutdown()
{
	if (XonMappedView)
		____UnmapViewOfFile(XonMappedView);
	
	if (DataShareHandle)
		____CloseHandle(DataShareHandle);
}