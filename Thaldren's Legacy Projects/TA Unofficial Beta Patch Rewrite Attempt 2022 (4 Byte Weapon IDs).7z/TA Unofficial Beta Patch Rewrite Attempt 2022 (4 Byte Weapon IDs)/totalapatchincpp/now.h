#pragma once


#include "headers.h"
#include "patcher.h"
#include "accessors.h"


enum GameType
{
	MENU = 0,
	CAMPAIGN = 1,
	SKIRMISH = 2,
	MULTI = 3
};


DWORD Arg1;


__declspec(naked) void ____Now_Replace(/* int */)
{
	__asm
	{
		mov eax, [esp+4]
		mov [Arg1], eax
	}

	if (____GetGameType() == GameType::MULTI && ____GetGameState() == GAME_STATE::IN_GAME)
	{
		*(WORD*)((* (DWORD*)(0x511DE8)) + 0x37F2F) |= 2; // for now enable
	}
	else if (____GetGameType() == GameType::SKIRMISH && ____GetGameState() == GAME_STATE::IN_GAME)
	{
		*(WORD*)((*(DWORD*)(0x511DE8)) + 0x37F2F) |= 2;
	}
	else if (____GetGameType() == GameType::CAMPAIGN && ____GetGameState() == GAME_STATE::IN_GAME)
	{
		*(WORD*)((*(DWORD*)(0x511DE8)) + 0x37F2F) |= 2;
	}

	__asm
	{
		ret 4
	}
}







void Now()
{
	WriteJumpHook((LPVOID)0x00416E90,(LPVOID)____Now_Replace);
}