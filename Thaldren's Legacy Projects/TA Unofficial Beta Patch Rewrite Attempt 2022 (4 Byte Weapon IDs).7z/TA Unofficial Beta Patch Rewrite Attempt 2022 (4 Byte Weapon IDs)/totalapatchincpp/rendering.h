#pragma once


#include "patcher.h"
#include "buildlinesandrings.h"
//#include "resourcebars.h"
#include "accessors.h"



extern bool DoRenderResourceBars;
extern void RenderResBars();
//extern void RenderWaterMark1();





LPVOID FinalRenderFunc_Hook_1_Return;



int ScreenWidth;
int ScreenHeight;









void RenderInGame()
{
	if (____GetGameState() == GAME_STATE::IN_GAME)
	{
		RenderTAHook();

		if (DoRenderResourceBars == true)
		{
			RenderResBars();
		}
	}

	//if (____GetGameState() != GAME_STATE::LOADING)
	//{
		//RenderWaterMark1();
	//}
}


__declspec(naked) void FinalRenderFunc_Hook_1()
{
	__asm
	{
		pushad
		pushfd

		call RenderInGame

		popfd
		popad

		sub esp, 0xF4
		jmp FinalRenderFunc_Hook_1_Return
	}
}



void* GetBackBuffer()
{
	__asm
	{
		mov eax, dword ptr ds:[0x51FBD0]
		mov eax, dword ptr ds:[eax + 0xBC]
		add eax, 48
	}
}

void DrawRectangleFillColor(int DestX, int DestY, int Width, int Height, unsigned char Color)
{
	int memsetcompat_Color = Color << 24 | Color << 16 | Color << 8 | Color;

	unsigned char* DestSurface = (unsigned char*)GetBackBuffer();

	int CurrentSrcX = DestX;
	int CurrentSrcY = DestY;
	int EndSrcX = DestX + Width;
	int EndSrcY = DestY + Height;
	int ResultSrcWidth = Width;
	int ResultSrcHeight = Height;
	int SubWidth = 0;
	int SubHeight = 0;

	ScreenWidth = GetScreenWidth();
	ScreenHeight = GetScreenHeight();

	if (!(DestX + Width < 0 || DestX > ScreenWidth ||
		DestY + Height < 0 || DestY > ScreenHeight))
	{
		if (DestX < 0)
		{
			SubWidth = -DestX;
			CurrentSrcX = 0;
			ResultSrcWidth = Width - SubWidth;
		}

		if (DestY < 0)
		{
			SubHeight = -DestY;
			CurrentSrcY = 0;
			ResultSrcHeight = Height - SubHeight;
		}

		if (DestX + Width > ScreenWidth)
		{
			ResultSrcWidth = ScreenWidth - DestX;
			EndSrcX = ScreenWidth;
		}

		if (DestY + Height > ScreenHeight)
		{
			ResultSrcHeight = ScreenHeight - DestY;
			EndSrcY = ScreenHeight;
		}

		DestSurface += CurrentSrcY * ScreenWidth + CurrentSrcX;

		for (int y = CurrentSrcY; y < EndSrcY; y++)
		{
			____memset(DestSurface, memsetcompat_Color, ResultSrcWidth);

			DestSurface += ScreenWidth;
		}
	}
}

void DrawRectanglePixelData(int DestX, int DestY, int Width, int Height, void* PixelData)
{
	unsigned char* DestSurface = (unsigned char*)GetBackBuffer();
	unsigned char* SrcSurface = (unsigned char*)PixelData;

	int CurrentSrcImageX = 0;
	int CurrentSrcImageY = 0;
	int CurrentSrcX = DestX;
	int CurrentSrcY = DestY;
	int EndSrcX = DestX + Width;
	int EndSrcY = DestY + Height;
	int ResultSrcWidth = Width;
	int ResultSrcHeight = Height;
	int SubWidth = 0;
	int SubHeight = 0;

	ScreenWidth = GetScreenWidth();
	ScreenHeight = GetScreenHeight();

	if (!(DestX + Width < 0 || DestX > ScreenWidth ||
		DestY + Height < 0 || DestY > ScreenHeight))
	{
		if (DestX < 0)
		{
			SubWidth = -DestX;
			CurrentSrcX = 0;
			ResultSrcWidth = Width - SubWidth;
			CurrentSrcImageX = SubWidth;
		}

		if (DestY < 0)
		{
			SubHeight = -DestY;
			CurrentSrcY = 0;
			ResultSrcHeight = Height - SubHeight;
			CurrentSrcImageY = SubHeight;
		}

		if (DestX + Width > ScreenWidth)
		{
			ResultSrcWidth = ScreenWidth - DestX;
			EndSrcX = ScreenWidth;
		}

		if (DestY + Height > ScreenHeight)
		{
			ResultSrcHeight = ScreenHeight - DestY;
			EndSrcY = ScreenHeight;
		}

		DestSurface += CurrentSrcY * ScreenWidth + CurrentSrcX;
		SrcSurface += CurrentSrcImageY * Width + CurrentSrcImageX;

		for (int y = CurrentSrcY; y < EndSrcY; y++)
		{
			____memcpy(DestSurface, SrcSurface, ResultSrcWidth);

			DestSurface += ScreenWidth;
			SrcSurface += Width;
		}
	}
}



RECT GetGameScreenRect()
{
	RECT Result;
	int Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27]
		mov Temp, eax
	}

	Result.left = Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27 + 4]
		mov Temp, eax
	}

	Result.top = Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27 + 8]
		mov Temp, eax
	}

	Result.right = Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27 + 12]
		mov Temp, eax
	}

	Result.bottom = Temp;

	return Result;
}



void Rendering()
{
	FinalRenderFunc_Hook_1_Return = (LPVOID)0x004C63A6;


	WriteJumpHook((LPVOID)0x004C63A0, (LPVOID)FinalRenderFunc_Hook_1);
}