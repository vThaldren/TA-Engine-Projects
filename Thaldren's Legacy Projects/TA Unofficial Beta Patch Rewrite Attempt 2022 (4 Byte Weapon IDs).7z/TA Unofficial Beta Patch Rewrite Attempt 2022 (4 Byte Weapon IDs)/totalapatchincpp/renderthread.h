#pragma once


#include "headers.h"



HANDLE (WINAPI* ____CreateThread)(LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId);
void (WINAPI* BlitScreen)();
void (WINAPI* DrawGameScreen)(int, int);


LPDWORD lpRenderThreadId;
LPDWORD lpRenderThreadId2;

bool StartFlag;
bool EndFlag;
bool BlitReady;
bool GameDrawReady;
bool FirstTime2;

DWORD ThreadCallBltOrigin;
DWORD ThreadCallDrawOrigin;
DWORD Eax_Temp;
DWORD Eax_ThrdTemp1;
DWORD Eax_ThrdTemp2;
DWORD Eax_ThrdTemp3;
DWORD Eax_ThrdTemp4;



void ____InterceptedBlitScreen();
void ____InterceptedBlitScreenReturn();
DWORD ____GetCurrentEIPForNextCallDirectJumpHackyReturn();
void ____InterceptedBlitScreen();
void ____InterceptedDrawGameScreen();
void ____InterceptedDrawGameScreenReturn();
DWORD ____GetCurrentEIPForNextCallDirectJumpHackyReturn2();


void ____LiveBlitThread()
{
	//while (StartFlag == false) { }

	while (EndFlag == false)
	{
		if (BlitReady)
		{
			__asm
			{

				//mov [Stor_2], edx
				//mov [Stor_3], ecx
				//mov [Stor_4], ebx
				//mov [Stor_5], esi
				//mov [Stor_6], edi
				//mov [Stor_7], ebp

				call ____GetCurrentEIPForNextCallDirectJumpHackyReturn
				call ____InterceptedBlitScreen

				

				//mov edx, [Stor_2]
				//mov ecx, [Stor_3]
				//mov ebx, [Stor_4]
				//mov esi, [Stor_5]
				//mov edi, [Stor_6]
				//mov ebp, [Stor_7]
			}

			//BlitReady = false;
		}
	}
}


void ____LiveDrawThread()
{
	while (EndFlag == false)
	{
		//if (GameDrawReady || FirstTime2)
		//{
			if(FirstTime2)
				FirstTime2 = false;

			__asm
			{

				call ____GetCurrentEIPForNextCallDirectJumpHackyReturn2

				push 1
				push 1
				call ____InterceptedDrawGameScreen

			}
		//}
	}
}





__declspec(naked) DWORD ____GetCurrentEIPForNextCallDirectJumpHackyReturn()
{
	__asm
	{
		mov [Eax_ThrdTemp3], eax
		mov eax, [esp]
		add eax, 5
		mov [ThreadCallBltOrigin], eax
		mov eax, [Eax_ThrdTemp3]
		ret
	}
}


__declspec(naked) DWORD ____GetCurrentEIPForNextCallDirectJumpHackyReturn2()
{
	__asm
	{
		mov [Eax_ThrdTemp4], eax
		mov eax, [esp]
		add eax, 5 + 2 + 2
		mov [ThreadCallDrawOrigin], eax
		mov eax, [Eax_ThrdTemp4]
		ret
	}
}




bool ____WithinExe()
{
	__asm
	{
		mov eax, [esp+4]
		mov [Eax_Temp], eax
	}

	if (Eax_Temp >= 0x401000 && Eax_Temp < 0x401000 + 0xFAA00)
		return true;

	return false;
}





__declspec(naked) void ____InterceptedBlitScreen()
{
	__asm
	{
		mov [Eax_ThrdTemp1], eax

		call ____WithinExe
		test eax, eax
		jz skip

		jmp DoRenderThread

		skip:
		mov eax, [Eax_ThrdTemp1]
		mov [BlitReady], 1
		ret // skip

		DoRenderThread:

		mov eax, [Eax_ThrdTemp1]

		push ____InterceptedBlitScreenReturn // put onto stack for 'ret' opcode (simulate call)
		sub esp, 0xF4 // reversed with jmp

		jmp BlitScreen // reversed with stack adjustment
	}
}



__declspec(naked) void ____InterceptedDrawGameScreen()
{
	__asm
	{
		test [FirstTime2], 1
		jnz skipA
		ret 8
		skipA:

		mov [Eax_ThrdTemp2], eax

		call ____WithinExe
		test eax, eax
		jz skip

		jmp DoRenderThread

		skip:
		mov eax, [Eax_ThrdTemp2]
		//mov [GameDrawReady], 1
		ret 8 // skip

		DoRenderThread:

		mov eax, [Eax_ThrdTemp2]

		push ____InterceptedDrawGameScreenReturn // put onto stack for 'ret' opcode (simulate call)
		//push 1 // dummy
		//push 1 // dummy
		sub esp, 0x214 // reversed with jmp

		jmp DrawGameScreen // reversed with stack adjustment
	}
}



__declspec(naked) void ____InterceptedBlitScreenReturn()
{
	__asm
	{
		cmp [BlitReady], 1
		jnz skip
		mov [BlitReady], 0
		jmp ThreadCallBltOrigin
		skip:
		ret // return normally
	}
}




__declspec(naked) void ____InterceptedDrawGameScreenReturn()
{
	__asm
	{
		//cmp [GameDrawReady], 1
		//jnz skip
		//mov [GameDrawReady], 0
		jmp ThreadCallDrawOrigin
		//skip:
		//ret // return normally
	}
}







void RenderThread() // init function for hooks
{
	//*(BYTE*)(0x004C63A0) = 0xC3; // Return from Blit Screen (skip rendering)
	WriteJumpHook((LPVOID)0x004C63A0, (LPVOID)____InterceptedBlitScreen);
	WriteJumpHook((LPVOID)0x00468CF0, (LPVOID)____InterceptedDrawGameScreen);

	StartFlag = false;
	EndFlag = false;
	BlitReady = false;
	GameDrawReady = false;
	FirstTime2 = true;

	____CreateThread = (HANDLE(WINAPI*)(LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId))0x004FB098;
	____CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)____LiveBlitThread, NULL, 0, lpRenderThreadId);
	____CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)____LiveDrawThread, NULL, 0, lpRenderThreadId2);

	BlitScreen = (void (WINAPI*)())(0x004C63A0 + 6); // Adjusted for custom hook
	DrawGameScreen = (void (WINAPI*)(int, int))(0x00468CF0 + 6);
}
