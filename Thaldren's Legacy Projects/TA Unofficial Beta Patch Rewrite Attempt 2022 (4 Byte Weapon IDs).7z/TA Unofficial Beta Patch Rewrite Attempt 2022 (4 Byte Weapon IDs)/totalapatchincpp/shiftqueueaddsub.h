#pragma once


#include "headers.h"



void ShiftQueueAddSub()
{
	*((BYTE*)(0x0041AC13+1)) = 10;
	*((BYTE*)(0x0041AC17+1)) = -10;
}