#pragma once


#include "headers.h"
#include "patcher.h"




LPVOID ____Insert_Hook_1_Return;
char* LastChatSentBuffer;
DWORD Storage_1;

__declspec(naked) void ____Insert_Hook_1()
{
	__asm
	{
		lea esi, [esp+0x28]
		mov [Storage_1], esi
	}

	____memcpy(LastChatSentBuffer, (LPVOID)Storage_1, ____strlen((const char*)Storage_1));
	LastChatSentBuffer[____strlen((const char*)Storage_1)] = '\0';

	__asm
	{
		mov al, [esp+0x28]

		jmp ____Insert_Hook_1_Return
	}
}







void Insert()
{
	____Insert_Hook_1_Return = (LPVOID)0x00493DF4;

	LastChatSentBuffer = (char*)____malloc(0x100);

	// record last input
	WriteJumpHook((LPVOID)0x00493DEC, ____Insert_Hook_1);
}