


#include "headers.h"
#include "patcher.h"
#include "mymod.h"
#include "weaponids.h"
#include "unitids.h"
#include "recorder.h"
#include "megamap.h"
#include "Rendering.h"
#include "unitlimittypes.h"
#include "soundmixingbuffers.h"
#include "shiftqueueaddsub.h"
#include "input.h"
#include "hotkeys.h"
#include "commanderwarp.h"
#include "buildlinesandrings.h"
#include "insert.h"
#include "resourcebars.h"
#include "xonrecordercompat.h"
#include "sfxlimit.h"
#include "pathfinding.h"
#include "now.h"
#include "watermark1.h"
#include "totalafunctions.h"
#include "renderthread.h"




HANDLE(WINAPI* ____FindFirstFileA)(LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData);
BOOL(WINAPI* ____FindClose)(HANDLE hFindFile);
int (WINAPI* ____MessageBoxA)(HWND hWnd, LPCSTR lpText, LPCSTR lpCaption, UINT uType);
HANDLE(WINAPI* ____GetCurrentProcess)();
BOOL(WINAPI* ____TerminateProcess)(HANDLE hProcess, UINT uExitCode);

void ____exit(UINT Code)
{
	HANDLE pHandle = ____GetCurrentProcess();
	____TerminateProcess(pHandle, Code);

}







BOOL WINAPI DllMain(HINSTANCE hInstDll, DWORD fdwReason, LPVOID lpReserved)
{
	//DWORD Protection = PAGE_EXECUTE_READWRITE;
	//DWORD Protection2 = PAGE_EXECUTE_READ;

	LPWIN32_FIND_DATAA findDlls;// = (LPWIN32_FIND_DATAA)____malloc(sizeof(WIN32_FIND_DATAA));
	HANDLE findHandle;
	DWORD drawLen;
	char* drawMem;
	DWORD playLen;
	char* playMem;

	if (fdwReason == DLL_PROCESS_ATTACH)
	{
		StaticInitializers_DllMain();
		StaticInitializers_TotalAFunctions();

//#ifdef MY_MOD
		findDlls = (LPWIN32_FIND_DATAA)____malloc(sizeof(WIN32_FIND_DATAA));

		____FindFirstFileA = (HANDLE(WINAPI*)(LPCSTR lpFileName, LPWIN32_FIND_DATAA lpFindFileData))0x004FB19A;
		____FindClose = (BOOL(WINAPI*)(HANDLE hFindFile))0x004FB1A6;

		____MessageBoxA = (int (WINAPI*)(HWND hWnd, LPCSTR lpText, LPCSTR lpCaption, UINT uType))0x0049F7F4;
		____GetCurrentProcess = (HANDLE(WINAPI*)())0x004FB0C8;
		____TerminateProcess = (BOOL(WINAPI*)(HANDLE hProcess, UINT uExitCode))0x004FB134;


		//____exit = (void(__cdecl*)(int Code))0x004E4620;

		// Check 1

		drawLen = ____strlen((const char*)((LPVOID)0x004FF618));
		drawMem = (char*)____malloc(drawLen + 1);

		if (drawMem)
			____memcpy(drawMem, (LPVOID)0x4FF618, drawLen + 1);

		if (____strcmpi(drawMem, "DDRAW.dll") != 0)
		{
			____MessageBoxA(NULL, "Unsupported EXE modifications found in TotalA.exe!\nUse stock 3.1 TotalA.exe before continuing.", "TotalA.exe", MB_OK);
			____exit(1);
		}



		findHandle = ____FindFirstFileA(drawMem, findDlls);

		if (findHandle != INVALID_HANDLE_VALUE) {
			____FindClose(findHandle);
			____MessageBoxA(NULL, "Unsupported DLLs found in TotalA Directory!\nRemove these files before continuing.", drawMem, MB_OK);
			____exit(1);
		}






		playLen = ____strlen((const char*)((LPVOID)0x004FF9E4));
		playMem = (char*)____malloc(playLen + 1);

		if (playMem)
			____memcpy(playMem, (LPVOID)0x004FF9E4, playLen + 1);

		if (____strcmpi(playMem, "DPLAYX.dll") != 0)
		{
			____MessageBoxA(NULL, "Unsupported EXE modifications found in TotalA.exe!\nUse stock 3.1 TotalA.exe before continuing.", "TotalA.exe", MB_OK);
			____exit(1);
		}

		//findHandle = ____FindFirstFileA(playMem, findDlls);

		//if (findHandle != INVALID_HANDLE_VALUE) {
		//	____FindClose(findHandle);
		//	____MessageBoxA(NULL, "Unsupported DLLs found in TotalA Directory!\nRemove these files before continuing.", playMem, MB_OK);
		//	____exit(1);
		//}

		// Check 2

		//findHandle = ____FindFirstFileA("?draw.dll", findDlls);

		//if (findHandle != INVALID_HANDLE_VALUE) {
		//	____FindClose(findHandle);
		//	____MessageBoxA(NULL, "Unsupported DLLs found in TotalA Directory! Remove these files before continuing.", "", MB_OK);
		//	____exit(1);
		//}
//#endif

		


		SetExeMemoryProtection((LPVOID)0x401000, (LPVOID)(0x401000 + 0xFAA00), PAGE_EXECUTE_READWRITE);
		//SetExeMemoryProtection((LPVOID)0x4FC000, (LPVOID)(0x4FC000 + 0x4800), &Protection2);

#ifdef MY_MOD
		MyMod();
#endif

		UnitLimitTypes();
		SoundMixingBuffers();
		ShiftQueueAddSub();
		Input();
		HotKeys();
		BuildLinesAndRings();
		CommanderWarp(); // no init :p
		Insert();

		// trouble two
		WeaponIds();
		UnitIds();
		// trouble two

		//Recorder();
		MegaMap(); // experimental
		Rendering();
		ResourceBars();

		// added stuff
		SFXLimit();
		Pathfinding();

		XonRecorderCompat();

		Now();



		// Experimental
		//RenderThread();




		//WaterMark1(); // Temporary Disable Watermark

		//SetExeMemoryProtection((LPVOID)0x4FC000, (LPVOID)(0x4FC000 + 0x4800), &Protection2);
		SetExeMemoryProtection((LPVOID)0x401000, (LPVOID)(0x401000 + 0xFAA00), PAGE_EXECUTE_READ);
	}
	else if (fdwReason == DLL_PROCESS_DETACH)
	{
		XonRecorderCompatShutdown();
	}

	return TRUE;
}



