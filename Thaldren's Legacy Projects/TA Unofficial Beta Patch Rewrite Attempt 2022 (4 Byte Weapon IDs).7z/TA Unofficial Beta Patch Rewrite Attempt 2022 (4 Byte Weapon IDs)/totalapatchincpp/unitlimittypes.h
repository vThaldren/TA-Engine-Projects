#pragma once


#include "headers.h"
#include "xonrecordercompat.h"


void UnitLimitTypes()
{
#ifndef XONRECORDERCOMPAT
	*((DWORD*)(0x00491666)) = 1500;
	*((DWORD*)(0x00491640)) = 1500;
	*((DWORD*)(0x00491659)) = 1500;
#endif
	*((DWORD*)(0x0044CAFE)) = 1500;
}