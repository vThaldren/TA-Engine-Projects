#pragma once


#include "valkyriecompat.h"
#include "rendering.h"
#include "accessors.h"


int(__cdecl* ____toupper)(int Character);
char* (__cdecl* ____itoa)(int Value, char* Dest, int Radix);





unsigned char CustomFont[] = { 0, 0, 255, 255, 255, 255, 0, 0, 0, 255, 255, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255,
	0, 0, 255, 255, 0, 0, 255, 255, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0,
	0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255,
	255, 255, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0,
	0, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255,
	0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
	255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
	255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0,
	0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0,
	0, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255,
	255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0,
	0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0,
	0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0,
	255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0,
	255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0,
	0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0,
	0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255,
	255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0,
	0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0,
	0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0,
	255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255,
	0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0,
	0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0,
	0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 255, 255, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0,
	0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0,
	255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0,
	0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255,
	255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0,
	0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0,
	0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
	0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0,
	255, 0, 0, 255, 0, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255,
	255, 255, 255, 255, 0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0,
	0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255,
	255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0,
	0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255,
	255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255,
	255, 255, 255, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 0,
	255, 255, 0, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0,
	0, 255, 255, 0, 255, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255,
	255, 255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
	0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255,
	0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 255, 255, 255, 255, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

unsigned char CharacterBuffer8x8[64]; // 8x8

char* PlayerNameCopy;




extern const int MAX_PLAYER_COUNT;



//struct PlayerResources
//{
//	float CurrentEnergy;
//	float EnergyProduction;
//	float EnergyExpense;
//	float CurrentMetal;
//	float MetalProduction;
//	float MetalExpense;
//	float EnergyStorageMax;
//	float MetalStorageMax;
//};


bool DoRenderResourceBars;

int XPos;
int YPos;

PlayerResources CurrentPlayerDraw;

enum RES_TYPE
{
	METAL,
	ENERGY
};

void RenderResBars();
void RenderBackground(int, int, int, int, int);
void RenderPlayerName(int, int, int);
void RenderCurrentStorage(int, int, int, int);
void RenderMaxStorage(int, int, int, int);
void RenderCurrentIncome(int, int, int, int);
void RenderCurrentExpense(int, int, int, int);
void RenderStorageOutline(int, int, int, int, int, unsigned char);
void RenderStorageBar(int, int, int, int, int, int);
void RenderText(int, int, int, int, unsigned char*, char*, unsigned char);



char* GetPlayerName(int);
/*PlayerResources*/ void GetPlayerResourcesStruct(int);

bool GetAlliedState(void*, int);
void* GetPlayerPtrFromIndex(int);

bool GetIsLocalPlayerWatcher();
bool GetIsPlayerIndexExists(int);

//char GetLocalPlayerArrayIndex();





char* GetPlayerName(int Index)
{
	char* NamePtr = 0;

	if (Index >= 0 && Index < 10)
	{
		__asm
		{
			mov esi, dword ptr ds:[0x511DE8]
			lea esi, [esi + 0x1B63]
			mov eax, 0x14B
			mov edx, Index
			mul edx
			add esi, eax
			add esi, 0x2B
			mov NamePtr, esi
		}
	}

	____memcpy(PlayerNameCopy, NamePtr, 30);

	return PlayerNameCopy;
}

/*PlayerResources*/void GetPlayerResourcesStruct(int Index)
{
	//PlayerResources Structure;

	____memset(&CurrentPlayerDraw, 0, sizeof(PlayerResources));


	float CurrentEnergy;
	float EnergyProduction;
	float EnergyExpense;
	float CurrentMetal;
	float MetalProduction;
	float MetalExpense;
	float EnergyStorageMax;
	float MetalStorageMax;

	if (Index >= 0 && Index < 10)
	{
		__asm
		{
			mov esi, dword ptr ds : [0x511DE8]
			lea esi, [esi + 0x1B63]
			mov eax, 0x14B
			mov edx, Index
			mul edx
			add esi, eax
			add esi, 0x8C

			mov eax, [esi]
			mov CurrentEnergy, eax

			mov eax, [esi + 4]
			mov EnergyProduction, eax

			mov eax, [esi + 8]
			mov EnergyExpense, eax

			mov eax, [esi + 12]
			mov CurrentMetal, eax

			mov eax, [esi + 16]
			mov MetalProduction, eax

			mov eax, [esi + 20]
			mov MetalExpense, eax

			mov eax, [esi + 24]
			mov EnergyStorageMax, eax

			mov eax, [esi + 28]
			mov MetalStorageMax, eax
		}

		CurrentPlayerDraw.CurrentEnergy = CurrentEnergy;
		CurrentPlayerDraw.EnergyProduction = EnergyProduction;
		CurrentPlayerDraw.EnergyExpense = EnergyExpense;
		CurrentPlayerDraw.CurrentMetal = CurrentMetal;
		CurrentPlayerDraw.MetalProduction = MetalProduction;
		CurrentPlayerDraw.MetalExpense = MetalExpense;
		CurrentPlayerDraw.EnergyStorageMax = EnergyStorageMax;
		CurrentPlayerDraw.MetalStorageMax = MetalStorageMax;
	}

	//return CurrentPlayerDraw;
}

bool GetAlliedState(void* Player1Ptr, int Player2Index)
{
	bool IsAllied;

	if (Player1Ptr == 0 || Player2Index >= MAX_PLAYER_COUNT)
	{
		return false;
	}

	__asm
	{
		mov eax, Player1Ptr
		add eax, 0x108
		add eax, Player2Index
		mov al, [eax]
		mov IsAllied, al
	}

	return IsAllied;
}

void* GetPlayerPtrFromIndex(int Index)
{
	void* PlayerPtr;

	__asm
	{
		mov esi, dword ptr ds : [0x511DE8]
		add esi, 0x1B63
		mov eax, 0x14B
		mov edx, Index
		mul edx
		add esi, eax
		mov PlayerPtr, esi
	}

	return PlayerPtr;
}

bool GetIsLocalPlayerWatcher()
{
	char LocalPlayerIndex = ____GetLocalPlayerArrayIndex();
	char PlayerPropertyMask;

	__asm
	{
		mov esi, dword ptr ds : [0x511DE8]
		add esi, 0x1B63
		xor eax, eax
		mov al, LocalPlayerIndex
		mov edx, 0x14B
		mul edx
		add esi, eax
		mov edi, [esi + 0x27]
		xor eax, eax
		mov al, [edi + 0x9B]
		mov PlayerPropertyMask, al
	}

	if ((PlayerPropertyMask & 0x40) > 0)
	{
		return true;
	}

	return false;
}

bool GetIsPlayerIndexExists(int Index)
{
	unsigned int IndexExists;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1B63
		mov eax, Index
		mov edx, 0x14B
		mul edx
		add esi, eax
		mov eax, [esi]
		mov IndexExists, eax
	}

	if (IndexExists > 0)
	{
		return true;
	}

	return false;
}






bool GetIsRemotePlayer(int Index)
{
	DWORD PlayerStruct = (DWORD)GetPlayerPtrFromIndex(Index);
	return *(BYTE*)(PlayerStruct + 0x73) == 0x3;
}








void RenderResBars()
{
	int Width = 250;
	int Height = 50;
	int BarWidth = 120;
	int XBarOffset = 0;
	
	int CurrentAllyIndex = 0;
	//int TargetAllyIndexToCheck = 0;

	//XPos = ((GetGameScreenRect().left + GetGameScreenRect().right) / 2) - ((XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 32) / 2);
	XPos = GetGameScreenRect().right - (XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 32) - 192;
	YPos = GetGameScreenRect().top + 24;

	if (GetIsLocalPlayerWatcher() || XonMappedView->PlayingDemo)
	{
		for (int i = 0; i < 10; i++)
		{
			if (GetIsPlayerIndexExists(i))
			{
				//if (GetAlliedState(GetPlayerPtrFromIndex(GetLocalPlayerArrayIndex()), i) == true)
				//{
				//if (GetAlliedState(GetPlayerPtrFromIndex(i), GetLocalPlayerArrayIndex()) == true)
				//{
				RenderPlayerName(i, XPos, i * Height + YPos);
				RenderStorageOutline(i, XPos + XBarOffset, i * Height + YPos + 12, BarWidth, 12, 0x00);
				RenderStorageOutline(i, XPos + XBarOffset + BarWidth + 1 + 12 + 64, i * Height + YPos + 12, BarWidth, 12, 0x00);
				RenderStorageBar(i, RES_TYPE::METAL, XPos + XBarOffset + 1, i * Height + YPos + 13, BarWidth - 2, 10);
				RenderStorageBar(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, i * Height + YPos + 13, BarWidth - 2, 10);
				RenderCurrentStorage(i, RES_TYPE::METAL, XPos, i * Height + YPos + 17 + 14);
				RenderCurrentStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, i * Height + YPos + 17 + 14);
				RenderMaxStorage(i, RES_TYPE::METAL, XPos + 64, i * Height + YPos + 17 + 14);
				RenderMaxStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 56 + 16 + 64, i * Height + YPos + 17 + 14);
				RenderCurrentIncome(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, i * Height + YPos + 12);
				RenderCurrentIncome(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, i * Height + YPos + 12);
				RenderCurrentExpense(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, i * Height + YPos + 28);
				RenderCurrentExpense(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, i * Height + YPos + 28);

				//CurrentAllyIndex++;
			//}
			//}
			}
		}
	}
	else
	{
		for (int i = 0; i < 10; i++)
		{
			//if (GetAlliedState(GetPlayerPtrFromIndex(GetLocalPlayerArrayIndex()), i) == true)
			//{
			if (GetIsPlayerIndexExists(i))
			{
				if (GetAlliedState(GetPlayerPtrFromIndex(i), ____GetLocalPlayerArrayIndex()) == true)
				{
					RenderPlayerName(i, XPos, CurrentAllyIndex * Height + YPos);
					RenderStorageOutline(i, XPos + XBarOffset, CurrentAllyIndex * Height + YPos + 12, BarWidth, 12, 0x00);
					RenderStorageOutline(i, XPos + XBarOffset + BarWidth + 1 + 12 + 64, CurrentAllyIndex * Height + YPos + 12, BarWidth, 12, 0x00);
					RenderStorageBar(i, RES_TYPE::METAL, XPos + XBarOffset + 1, CurrentAllyIndex * Height + YPos + 13, BarWidth - 2, 10);
					RenderStorageBar(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, CurrentAllyIndex * Height + YPos + 13, BarWidth - 2, 10);
					RenderCurrentStorage(i, RES_TYPE::METAL, XPos, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderCurrentStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderMaxStorage(i, RES_TYPE::METAL, XPos + 64, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderMaxStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 56 + 16 + 64, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderCurrentIncome(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, CurrentAllyIndex * Height + YPos + 12);
					RenderCurrentIncome(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, CurrentAllyIndex * Height + YPos + 12);
					RenderCurrentExpense(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, CurrentAllyIndex * Height + YPos + 28);
					RenderCurrentExpense(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, CurrentAllyIndex * Height + YPos + 28);

					CurrentAllyIndex++;
				}
			}
			//}
		}
	}
}

void RenderBackground(int Index, int X, int Y, int Width, int Height)
{
	DrawRectangleFillColor(X, Y, Width, Height, 0xFF);
}

void RenderPlayerName(int Index, int X, int Y)
{
	char* PlayerName = GetPlayerName(Index);

	RenderText(X, Y, 8, 8, CustomFont, PlayerName, 0x92);
}

void RenderCurrentStorage(int Index, int Type, int X, int Y)
{
	//std::string Text;

	char Text[256];

	/*CurrentPlayerDraw = */GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		____itoa(int(CurrentPlayerDraw.CurrentMetal), Text, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0x82);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		____itoa(int(CurrentPlayerDraw.CurrentEnergy), Text, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0xD0);
	}
}

void RenderMaxStorage(int Index, int Type, int X, int Y)
{
	char Text[256];

	/*CurrentPlayerDraw = */GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		____itoa(int(CurrentPlayerDraw.MetalStorageMax), Text, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0x82);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		____itoa(int(CurrentPlayerDraw.EnergyStorageMax), Text, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0xD0);
	}
}

void RenderCurrentIncome(int Index, int Type, int X, int Y)
{
	char Text[256];

	Text[0] = '+';

	/*CurrentPlayerDraw = */GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		//if (GetIsRemotePlayer(Index))
		//	____itoa(int(XonMappedView->IncomeM[Index]), Text + 1, 10);
		//else
			____itoa(int(CurrentPlayerDraw.MetalProduction), Text + 1, 10);
	
		RenderText(X, Y, 8, 8, CustomFont, Text, 0xE9);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		//if (GetIsRemotePlayer(Index))
		//	____itoa(int(XonMappedView->IncomeE[Index]), Text + 1, 10);
		//else
		 ____itoa(int(CurrentPlayerDraw.EnergyProduction), Text + 1, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0xE9);
	}
}

void RenderCurrentExpense(int Index, int Type, int X, int Y)
{
	char Text[256];

	Text[0] = '-';

	/*CurrentPlayerDraw = */GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		____itoa(int(CurrentPlayerDraw.MetalExpense), Text + 1, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0xF9);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		____itoa(int(CurrentPlayerDraw.EnergyExpense), Text + 1, 10);
		RenderText(X, Y, 8, 8, CustomFont, Text, 0xF9);
	}
}

void RenderStorageOutline(int Index, int X, int Y, int Width, int Height, unsigned char Color)
{
	DrawRectangleFillColor(X, Y, Width, Height, Color);
}

void RenderStorageBar(int Index, int Type, int X, int Y, int Width, int Height)
{
	int CurrentWidth;

	/*CurrentPlayerDraw = */GetPlayerResourcesStruct(Index);

	// Background
	//DrawRectangleFillColor(X, Y, Width, Height, 0x00);

	if (Type == RES_TYPE::METAL)
	{
		CurrentWidth = int((CurrentPlayerDraw.CurrentMetal / CurrentPlayerDraw.MetalStorageMax) * Width);
		DrawRectangleFillColor(X, Y, CurrentWidth, Height, 0x82); // Actual Resources (Metal/Energy)
	}
	else if (Type == RES_TYPE::ENERGY)
	{
		CurrentWidth = int((CurrentPlayerDraw.CurrentEnergy / CurrentPlayerDraw.EnergyStorageMax) * Width);
		DrawRectangleFillColor(X, Y, CurrentWidth, Height, 0xD0); // Actual Resources (Metal/Energy)
	}
}

void RenderText(int DestX, int DestY, int Width, int Height, unsigned char* Font, char* Text, unsigned char Color)
{
	unsigned char* DestSurface = (unsigned char*)GetBackBuffer();
	unsigned char* SrcSurface = Font;
	unsigned char* CharacterToDraw = CharacterBuffer8x8;

	int CharacterIndex;
	int ImageOffset;

	for (size_t i = 0; i < ____strlen(Text); i++)
	{
		Text[i] = ____toupper(Text[i]);
	}

	for (size_t i = 0; i < ____strlen(Text); i++)
	{
		if (Text[i] >= '0' && Text[i] <= '9')
		{
			CharacterIndex = Text[i] - 48;
		}

		else if (Text[i] >= 'A' && Text[i] <= 'Z')
		{
			CharacterIndex = 10 + Text[i] - 65;
		}

		else if (Text[i] == '+')
		{
			CharacterIndex = 36;
		}

		else if (Text[i] == '-')
		{
			CharacterIndex = 37;
		}

		else if (Text[i] == '_')
		{
			CharacterIndex = 38;
		}

		else if (Text[i] == ' ')
		{
			CharacterIndex = 40;
		}

		else
		{
			CharacterIndex = 39;
		}

		ImageOffset = CharacterIndex * Width * Height;

		for (int y = 0; y < Height; y++)
		{
			for (int x = 0; x < Width; x++)
			{
				if (SrcSurface[ImageOffset + y * Width + x] == 0xFF)
				{
					CharacterToDraw[y * Width + x] = Color;
				}
				else
				{
					CharacterToDraw[y * Width + x] = 0x00;
				}

				//memcpy(CharacterToDraw, (void*)ImageOffset, Width * Height);
			}
		}

		DrawRectanglePixelData(DestX, DestY, Width, Height, CharacterToDraw);

		DestX += Width;
	}
}






void ResourceBars()
{
	 ____toupper = (int(__cdecl*)(int character))0x004E71C0;
	 ____itoa = (char* (__cdecl*)(int Value, char* Dest, int Radix))0x004FA930;

	 PlayerNameCopy = (char*)____malloc(30);
	 ____memset(PlayerNameCopy, 0, 30);
}