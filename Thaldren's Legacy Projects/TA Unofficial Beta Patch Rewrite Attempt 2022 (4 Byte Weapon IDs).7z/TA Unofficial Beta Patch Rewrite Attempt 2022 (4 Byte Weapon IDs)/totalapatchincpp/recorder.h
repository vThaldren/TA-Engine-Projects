#pragma once


#include "headers.h"




LPVOID ____Real_DirectPlayCreate;// = (LPVOID)(*((DWORD*)(0x004FC038)));
LPVOID ____Real_DirectPlayLobbyCreateA;// = (LPVOID)(*((DWORD*)(0x004FC03C)));


LPVOID ____Real_lplpDP;
LPVOID ____Real_lplpDP_Interface;
LPVOID ____Real_lplpDP_Table;


LPVOID ____Real_lplpDP_QueryInterface;




LPVOID ____Real_Queried_lplpDP;
LPVOID ____Real_Queried_lplpDP_Interface;
LPVOID ____Real_Queried_lplpDP_Table;




void PatchTable_QueriedIntrerface();




HRESULT ____Wrapper_QueryInterface(LPVOID riid, LPVOID ppvObj)
{
	HRESULT hResult;

	__asm
	{
		push ppvObj
		push riid
		call ____Real_lplpDP_QueryInterface
		mov hResult, eax
	}

	____Real_Queried_lplpDP = ppvObj;

	PatchTable_QueriedIntrerface();

	return hResult;
}




void PatchTable_QueriedIntrerface()
{
	____Real_Queried_lplpDP_Interface = (LPVOID)(*(DWORD*)____Real_Queried_lplpDP);
	____Real_Queried_lplpDP_Table = (LPVOID)(*(DWORD*)____Real_Queried_lplpDP_Interface);

	// do the real patching here

}




void PatchTable_DirectPlayCreate()
{
	____Real_lplpDP_Interface = (LPVOID)(*(DWORD*)____Real_lplpDP);
	____Real_lplpDP_Table = (LPVOID)(*(DWORD*)____Real_lplpDP_Interface);

	*(DWORD*)(____Real_lplpDP_QueryInterface) = *(DWORD*)((DWORD)____Real_lplpDP_Table + 0);
	*(DWORD*)((DWORD)____Real_lplpDP_Table + 0) = (DWORD)____Wrapper_QueryInterface;


}



HRESULT WINAPI ____DirectPlayCreate(LPVOID lpGuid, LPVOID lplpDP, LPVOID pUnk)
{
	HRESULT hResult;

	__asm
	{
		push pUnk
		push lplpDP
		push lpGuid
		call ____Real_DirectPlayCreate
		mov hResult, eax
	}

	____Real_lplpDP = lplpDP;

	if (hResult == 0) // DP_OK
	{
		PatchTable_DirectPlayCreate();
	}

	return hResult;

	//return 0;
}





HRESULT WINAPI ____DirectPlayLobbyCreateA(LPVOID lpGuid, LPVOID lplpDPL, LPVOID pUnk, LPVOID a4, DWORD a5)
{
	return 0;
}


void StaticInitializers_Recorder()
{
	____Real_DirectPlayCreate = (LPVOID)(*((DWORD*)(0x004FC038)));
	____Real_DirectPlayLobbyCreateA = (LPVOID)(*((DWORD*)(0x004FC03C)));
}

void InitHooks_Recorder()
{
	// DirectPlayCreate
	*((DWORD*)(0x004FC038)) = (DWORD)____DirectPlayCreate;
	*((DWORD*)(0x004FC03C)) = (DWORD)____DirectPlayLobbyCreateA;
}

void Recorder()
{
	StaticInitializers_Recorder();

	InitHooks_Recorder();
}