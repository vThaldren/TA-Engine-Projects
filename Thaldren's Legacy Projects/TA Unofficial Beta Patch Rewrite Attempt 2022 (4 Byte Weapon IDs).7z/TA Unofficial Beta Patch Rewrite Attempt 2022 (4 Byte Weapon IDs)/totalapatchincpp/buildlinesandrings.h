#pragma once



#include "headers.h"
#include "valkyriecompat.h"






enum STATE
{
	OFF,
	ON
};

enum PlayerOrderType
{
	BUILD = 14
};

struct BuildLineMessage
{
	int XPos;
	int YPos;
	int Status;
};


bool WriteLine = false;
bool WriteRing = false;
short g_FootPrintX;
short g_FootPrintY;
int MouseStartX;
int MouseStartY;
int MouseEndX;
int MouseEndY;
short LineMatrixX[1000];
short LineMatrixY[1000];
int short MatrixLength;
unsigned char Direction = 0;
short BuildSpacing = 0;
int MouseOverUnit = 0;



int MaxBuildSpacing = 20;



PatchStruct DrawBuildRectLive[16];



int WINAPI BuildLineAndBuildRingWndProc(HWND, UINT, WPARAM, LPARAM);
void ToggleBuildRectangle(bool);
unsigned short GetMouseMapPosX();
unsigned short GetMouseMapPosY();
void SetMouseMapPosX(short PosX);
void SetMouseMapPosY(short PosY);
unsigned char GetBuildOrderType();
short GetBuildUnitId();
short GetUnitFootPrintX();
short GetUnitFootPrintY();
void CalculateBuildLine();
void CalculateBuildRing();
void CalculateBuildRing(int, int, int, int);
void WriteBuildLine();
void PlaceNewPendingBuilding(int, int);
void UpdateBuildSpacing();
void RenderTAHook();
void ShowBuildLine();
void SetBuildSpotState(char);
char GetBuildSpotState();
void DrawBuildRectangle(int, int, int, int, int);
unsigned int GetCircleSelectPos1X();
unsigned int GetCircleSelectPos1Y();
unsigned int GetCircleSelectPos1Z();
int GetEyeMapPosX();
int GetEyeMapPosY();
int GetScreenWidth();
int GetScreenHeight();


int WINAPI BuildLineAndBuildRingWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == WM_KEYUP)
	{
		if (wParam == 0x58) // X key
		{
			WriteLine = false;
			WriteRing = false;
			ToggleBuildRectangle(STATE::ON); // On
		}
	}
	else if (msg == WM_LBUTTONDOWN)
	{
		if (WriteRing)
		{
			WriteBuildLine();
			return true;
		}
		else if (WriteLine && (TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
		{
			g_FootPrintX = GetUnitFootPrintX();
			g_FootPrintY = GetUnitFootPrintY();

			if (g_FootPrintX == 0)
			{
				g_FootPrintX = 1;
			}

			if (g_FootPrintY == 0)
			{
				g_FootPrintY = 1;
			}

			MouseEndX = GetMouseMapPosX();
			MouseEndY = GetMouseMapPosY();

			WriteBuildLine();

			MouseStartX = GetMouseMapPosX();
			MouseStartY = GetMouseMapPosY();

			LineMatrixX[0] = -1;
			LineMatrixY[0] = -1;

			return true;
		}
		else if (GetBuildOrderType() == PlayerOrderType::BUILD && (TA_GetAsyncKeyState(0x58) & 0x8000) > 0 && LOWORD(lParam) > 127)
		{
			g_FootPrintX = GetUnitFootPrintX();
			g_FootPrintY = GetUnitFootPrintY();

			if (g_FootPrintX == 0)
			{
				g_FootPrintX = 1;
			}

			if (g_FootPrintY == 0)
			{
				g_FootPrintY = 1;
			}

			WriteLine = true;

			ToggleBuildRectangle(STATE::OFF);

			MouseEndX = GetMouseMapPosX();
			MouseEndY = GetMouseMapPosY();
			MouseStartX = GetMouseMapPosX();
			MouseStartY = GetMouseMapPosY();

			LineMatrixX[0] = -1;
			LineMatrixY[0] = -1;

			CalculateBuildLine();

			return true;
		}
	}
	else if (msg == WM_LBUTTONUP)
	{
		if (WriteRing)
		{
			return true;
		}

		if ((TA_GetAsyncKeyState(0x58) & 0x8000) == 0)
		{
			WriteLine = false;
			ToggleBuildRectangle(STATE::ON);
		}
	}
	else if (msg == WM_RBUTTONDOWN)
	{
		if ((TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
		{
			return true;
		}
	}
	else if (msg == WM_RBUTTONUP)
	{
		WriteRing = false;
	}
	else if(msg == WM_MOUSEMOVE)
	{
		if (WriteLine)
		{
			MouseEndX = GetMouseMapPosX();
			MouseEndY = GetMouseMapPosY();

			CalculateBuildLine();
		}
		else if (GetBuildOrderType() == PlayerOrderType::BUILD && (TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
		{
			MouseOverUnit = TA_MouseUnit();

			if (MouseOverUnit)
			{
				CalculateBuildRing();

				WriteRing = true;
			}
			else
			{
				WriteRing = false;

				if (!WriteLine)
				{
					ToggleBuildRectangle(STATE::ON);
				}
			}
		}
		else
		{
			WriteRing = false;
		}

	}
	else if(msg == WM_MOUSEWHEEL)
	{
		if (HIWORD(wParam) > 120)
		{
			if ((TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
			{
				BuildSpacing--;

				if (BuildSpacing < 0)
				{
					BuildSpacing = 0;
				}

				UpdateBuildSpacing();

				return true;
			}

		}
		else if (HIWORD(wParam) <= 120)
		{
			if ((TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
			{
				BuildSpacing++;

				if (BuildSpacing > MaxBuildSpacing)
				{
					BuildSpacing = MaxBuildSpacing;
				}

				UpdateBuildSpacing();

				return true;
			}
		}
	}

	return false;
}

void ToggleBuildRectangle(bool state)
{
	if (state == STATE::ON)
	{
		Revert(&DrawBuildRectLive[0]);

		Revert(&DrawBuildRectLive[1]);
		Revert(&DrawBuildRectLive[2]);

		Revert(&DrawBuildRectLive[3]);
		Revert(&DrawBuildRectLive[4]);
		Revert(&DrawBuildRectLive[5]);
		Revert(&DrawBuildRectLive[6]);

		Revert(&DrawBuildRectLive[7]);
	
		Revert(&DrawBuildRectLive[8]);

		Revert(&DrawBuildRectLive[9]);
		Revert(&DrawBuildRectLive[10]);

		Revert(&DrawBuildRectLive[11]);
		Revert(&DrawBuildRectLive[12]);
		Revert(&DrawBuildRectLive[13]);
		Revert(&DrawBuildRectLive[14]);

		Revert(&DrawBuildRectLive[15]);
	}
	else
	{
		RePatch(&DrawBuildRectLive[0]);

		RePatch(&DrawBuildRectLive[1]);
		RePatch(&DrawBuildRectLive[2]);

		RePatch(&DrawBuildRectLive[3]);
		RePatch(&DrawBuildRectLive[4]);
		RePatch(&DrawBuildRectLive[5]);
		RePatch(&DrawBuildRectLive[6]);

		RePatch(&DrawBuildRectLive[7]);

		RePatch(&DrawBuildRectLive[8]);

		RePatch(&DrawBuildRectLive[9]);
		RePatch(&DrawBuildRectLive[10]);

		RePatch(&DrawBuildRectLive[11]);
		RePatch(&DrawBuildRectLive[12]);
		RePatch(&DrawBuildRectLive[13]);
		RePatch(&DrawBuildRectLive[14]);

		RePatch(&DrawBuildRectLive[15]);
	}
}

short GetUnitFootPrintX()
{
	short UnitId;

	UnitId = GetBuildUnitId();

	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov esi, dword ptr ds:[esi + 0x1439b]
		mov eax, 0x249
		xor edx, edx
		mov dx, UnitId
		mul edx
		add esi, eax
		add esi, 0x14a
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

short GetUnitFootPrintY()
{
	short UnitId;

	UnitId = GetBuildUnitId();

	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov esi, dword ptr ds:[esi + 0x1439b]
		mov eax, 0x249
		xor edx, edx
		mov dx, UnitId
		mul edx
		add esi, eax
		add esi, 0x14c
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

short GetBuildUnitId()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr [esi + 0x2cc4]
	}
}

unsigned short GetMouseMapPosX()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 2
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

unsigned short GetMouseMapPosY()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 10
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

void SetMouseMapPosX(short PosX)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 2
		xor eax, eax
		mov ax, PosX
		mov word ptr [esi], ax
	}
}

void SetMouseMapPosY(short PosY)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 10
		xor eax, eax
		mov ax, PosY
		mov word ptr [esi], ax
	}
}

unsigned char GetBuildOrderType()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		xor eax, eax
		mov al, byte ptr [esi + 0x2CC3]
	}
}

void WriteBuildLine()
{
	int Index = 0;

	while (LineMatrixX[Index] != -1 && LineMatrixY[Index] != -1)
	{
		PlaceNewPendingBuilding(LineMatrixX[Index], LineMatrixY[Index]);

		Index++;
	}
}

void PlaceNewPendingBuilding(int PosX, int PosY)
{
	int OriginalMouseX = GetMouseMapPosX();
	int OriginalMouseY = GetMouseMapPosY();

	BuildLineMessage BLM;
	BLM.Status = 5;

	SetMouseMapPosX(PosX);
	SetMouseMapPosY(PosY);

	TA_TestBuildSpot();

	TA_MapClick(&BLM);

	SetMouseMapPosX(OriginalMouseX);
	SetMouseMapPosY(OriginalMouseY);
}

void UpdateBuildSpacing()
{
	if (WriteLine)
	{
		CalculateBuildLine();
	}

	if (WriteRing)
	{
		CalculateBuildRing();
	}
}

void CalculateBuildLine()
{
	int DeltaX = (MouseEndX - MouseStartX) / 16;
	int DeltaY = (MouseEndY - MouseStartY) / 16;
	int IncrementX = 16;
	int IncrementY = 16;
	int X = MouseStartX;
	int Y = MouseStartY;
	int FootPrintX = BuildSpacing + g_FootPrintX;
	int FootPrintY = BuildSpacing + g_FootPrintY;
	int Error;
	int Index;

	if (DeltaX < 0)
	{
		IncrementX = IncrementX * -1;
		DeltaX = DeltaX * -1;
	}
	
	if (DeltaY < 0)
	{
		IncrementY = IncrementY * -1;
		DeltaY = DeltaY * -1;
	}

	if (DeltaX > DeltaY)
	{
		DeltaX = DeltaX / FootPrintX;
		IncrementX *= FootPrintX;

		if (DeltaX >= 1000)
		{
			return;
		}

		LineMatrixX[DeltaX + 1] = -1;
		LineMatrixY[DeltaX + 1] = -1;

		MatrixLength = DeltaX;
		Direction = 1;

		Error = (DeltaY + DeltaY) - DeltaX;

		for (Index = 0; Index <= DeltaX; Index++)
		{
			LineMatrixX[Index] = X;
			LineMatrixY[Index] = Y;

			while (Error >= 0 && DeltaX != 0)
			{
				Error -= (DeltaX + DeltaX);
				Y += IncrementY;
			}

			Error += (DeltaY + DeltaY);
			X += IncrementX;
		}
	}
	else
	{
		DeltaY = DeltaY / FootPrintY;
		IncrementY *= FootPrintY;

		if (DeltaY >= 1000)
		{
			return;
		}

		LineMatrixX[DeltaY + 1] = -1;
		LineMatrixY[DeltaY + 1] = -1;

		MatrixLength = DeltaY;
		Direction = 2;

		Error = (DeltaX + DeltaX) - DeltaY;

		for (Index = 0; Index <= DeltaY; Index++)
		{
			LineMatrixX[Index] = X;
			LineMatrixY[Index] = Y;

			while (Error >= 0 && DeltaY != 0)
			{
				Error -= (DeltaY + DeltaY);
				X += IncrementX;
			}

			Error += (DeltaX + DeltaX);
			Y += IncrementY;
		}
	}
}

void CalculateBuildRing()
{
	//void* TAInGameUnitsArrayPtr;
	short Temp1;
	short Temp2;
	short Temp3;
	short Temp4;
	int FootPrintX;
	int FootPrintY;
	int PositionX;
	int PositionY;
	int UnitArrayOffset;

	UnitArrayOffset = MouseOverUnit * 0x118;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x92
		mov eax, [eax]
		add eax, 0x14A
		mov dx, [eax] // FootprintX
		mov Temp1, dx

		mov eax, dword ptr ds : [0x511de8]
		mov eax, dword ptr ds : [eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x92
		mov eax, [eax]
		add eax, 0x14C
		mov dx, [eax] // FootprintY
		mov Temp2, dx

		mov eax, dword ptr ds : [0x511de8]
		mov eax, dword ptr ds : [eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x76 // GridPosX
		mov dx, [eax]
		mov Temp3, dx

		mov eax, dword ptr ds : [0x511de8]
		mov eax, dword ptr ds : [eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x78
		mov dx, [eax] // GridPosY
		mov Temp4, dx
	}

	FootPrintX = Temp1 + BuildSpacing * 2;
	FootPrintY = Temp2 + BuildSpacing * 2;
	PositionX = Temp3 * 16 - BuildSpacing * 16;
	PositionY = Temp4 * 16 - BuildSpacing * 16;

	CalculateBuildRing(PositionX, PositionY, FootPrintX, FootPrintY);
}

void CalculateBuildRing(int PositionX, int PositionY, int FootPrintX, int FootPrintY)
{
	int Position;
	int Addition;
	int LineLengthX;
	int LineLengthY;

	int UnitFootX;
	int UnitFootY;

	Position = 0;
	Addition = 0;

	UnitFootX = GetUnitFootPrintX();
	UnitFootY = GetUnitFootPrintY();

	Addition = (FootPrintX % UnitFootX && UnitFootX < 3 && UnitFootY < 3) ? 1 : 0;
	LineLengthX = (FootPrintX / UnitFootX) + Addition + 1;

	Addition = (FootPrintY % UnitFootY && UnitFootX < 3 && UnitFootY < 3) ? 1 : 0;
	LineLengthY = (FootPrintY / UnitFootY) + Addition + 1;

	for (int i = 0; i < LineLengthX; i++)
	{
		LineMatrixX[Position] = PositionX + (UnitFootX * 16) / 2 + i * UnitFootX * 16;
		LineMatrixY[Position] = PositionY - (UnitFootY * 16) / 2;
		Position++;
	}

	for (int i = 0; i < LineLengthY; i++)
	{
		LineMatrixX[Position] = PositionX + FootPrintX * 16 + (UnitFootX * 16) / 2;
		LineMatrixY[Position] = PositionY + (UnitFootY * 16) / 2 + i * UnitFootY * 16;
		Position++;
	}

	for (int i = 0; i < LineLengthX; i++)
	{
		LineMatrixX[Position] = PositionX + FootPrintX * 16 - (UnitFootX * 16) / 2 - UnitFootX * 16 * i;
		LineMatrixY[Position] = PositionY + FootPrintY * 16 + (UnitFootY * 16) / 2;
		Position++;
	}

	for (int i = 0; i < LineLengthY; i++)
	{
		LineMatrixX[Position] = PositionX - (UnitFootX * 16) / 2;
		LineMatrixY[Position] = PositionY + FootPrintY * 16 - (UnitFootY * 16) / 2 - UnitFootY * 16 * i;
		Position++;
	}

	LineMatrixX[Position] = -1;
	LineMatrixY[Position] = -1;
}

void RenderTAHook()
{
	if (WriteLine || WriteRing)
	{
		ToggleBuildRectangle(STATE::ON);
		ShowBuildLine();
		ToggleBuildRectangle(STATE::OFF);
	}
}

void ShowBuildLine()
{
	int Index = 0;
	int OriginalMouseX;
	int OriginalMouseY;
	int Color;

	while (LineMatrixX[Index] != -1 && LineMatrixY[Index] != -1)
	{
		OriginalMouseX = GetMouseMapPosX();
		OriginalMouseY = GetMouseMapPosY();

		SetMouseMapPosX(LineMatrixX[Index]);
		SetMouseMapPosY(LineMatrixY[Index]);

		SetBuildSpotState(70);

		TA_TestBuildSpot();

		if (GetBuildSpotState() == 70)
		{
			Color = 234;
		}
		else
		{
			Color = 214;
		}

		DrawBuildRectangle(
			(GetCircleSelectPos1X() - GetEyeMapPosX()) + 128,
			(GetCircleSelectPos1Y() - GetEyeMapPosY()) + 32 - (GetCircleSelectPos1Z() / 2),
			GetUnitFootPrintX() * 16,
			GetUnitFootPrintY() * 16,
			Color
			);

		Index++;

		SetMouseMapPosX(OriginalMouseX);
		SetMouseMapPosY(OriginalMouseY);
	}
}

void DrawBuildRectangle(int PosX, int PosY, int SizeX, int SizeY, int Color)
{
	RECT Rectangle =
	{
		PosX,
		PosY,
		PosX + SizeX,
		PosY + SizeY
	};

	int ScreenWidth = GetScreenWidth();
	int ScreenHeight = GetScreenHeight();

	if (Rectangle.top < 32)
	{
		Rectangle.top = 32;
	}

	if (Rectangle.top > ScreenHeight - 33)
	{
		Rectangle.top = ScreenHeight - 33;
	}

	if (Rectangle.bottom < 32)
	{
		Rectangle.bottom = 32;
	}

	if (Rectangle.bottom > ScreenHeight - 33)
	{
		Rectangle.bottom = ScreenHeight - 33;
	}

	if (Rectangle.left < 128)
	{
		Rectangle.left = 128;
	}

	if (Rectangle.left > ScreenWidth)
	{
		Rectangle.left = ScreenWidth;
	}

	if (Rectangle.right < 128)
	{
		Rectangle.right = 128;
	}

	if (Rectangle.right > ScreenWidth)
	{
		Rectangle.right = ScreenWidth;
	}

	TA_DrawRect(NULL, &Rectangle, Color);

	Rectangle.top++;
	Rectangle.bottom++;
	Rectangle.left++;
	Rectangle.right++;

	if (Rectangle.top < 32)
	{
		Rectangle.top = 32;
	}

	if (Rectangle.top > ScreenHeight - 33)
	{
		Rectangle.top = ScreenHeight - 33;
	}

	if (Rectangle.bottom < 32)
	{
		Rectangle.bottom = 32;
	}

	if (Rectangle.bottom > ScreenHeight - 33)
	{
		Rectangle.bottom = ScreenHeight - 33;
	}

	if (Rectangle.left < 128)
	{
		Rectangle.left = 128;
	}

	if (Rectangle.left > ScreenWidth)
	{
		Rectangle.left = ScreenWidth;
	}

	if (Rectangle.right < 128)
	{
		Rectangle.right = 128;
	}

	if (Rectangle.right > ScreenWidth)
	{
		Rectangle.right = ScreenWidth;
	}

	TA_DrawRect(NULL, &Rectangle, Color);
}

void SetBuildSpotState(char state)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2cc6]
		mov al, state
		mov byte ptr [esi], al
	}
}

char GetBuildSpotState()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2cc6]
		xor eax, eax
		mov al, byte ptr [esi]
	}
}

unsigned int GetCircleSelectPos1X()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x2c92]
	}
}

unsigned int GetCircleSelectPos1Y()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x2c9a]
	}
}

unsigned int GetCircleSelectPos1Z()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x2c96]
	}
}

int	GetEyeMapPosX()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x1431f]
	}
}

int	GetEyeMapPosY()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x14323]
	}
}

int GetScreenWidth()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x37e1f]
	}
}

int GetScreenHeight()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x37e23]
	}
}









void BuildLinesAndRings()
{
	unsigned char Byte = 0x90;
	
	Patch(&DrawBuildRectLive[0], 0x00469EB6, &Byte, 1, false);
	Patch(&DrawBuildRectLive[1], 0x00469EBB, &Byte, 1, false);
	Patch(&DrawBuildRectLive[2], 0x00469EBC, &Byte, 1, false);
	Patch(&DrawBuildRectLive[3], 0x00469EC5, &Byte, 1, false);
	Patch(&DrawBuildRectLive[4], 0x00469EC6, &Byte, 1, false);
	Patch(&DrawBuildRectLive[5], 0x00469EC7, &Byte, 1, false);
	Patch(&DrawBuildRectLive[6], 0x00469EC8, &Byte, 1, false);
	Patch(&DrawBuildRectLive[7], 0x00469EC9, &Byte, 1, false);
	Patch(&DrawBuildRectLive[8], 0x00469F02, &Byte, 1, false);
	Patch(&DrawBuildRectLive[9], 0x00469F07, &Byte, 1, false);
	Patch(&DrawBuildRectLive[10], 0x00469F08, &Byte, 1, false);
	Patch(&DrawBuildRectLive[11], 0x00469F1E, &Byte, 1, false);
	Patch(&DrawBuildRectLive[12], 0x00469F1F, &Byte, 1, false);
	Patch(&DrawBuildRectLive[13], 0x00469F20, &Byte, 1, false);
	Patch(&DrawBuildRectLive[14], 0x00469F21, &Byte, 1, false);
	Patch(&DrawBuildRectLive[15], 0x00469F22, &Byte, 1, false);
}