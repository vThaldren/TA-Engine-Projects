#pragma once



#define TRASHBINCOMPAT