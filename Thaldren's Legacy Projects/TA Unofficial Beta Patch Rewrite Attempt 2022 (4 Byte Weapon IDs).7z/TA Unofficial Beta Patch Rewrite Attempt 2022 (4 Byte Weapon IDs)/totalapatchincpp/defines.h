#pragma once




#define MAX_NUMBER_OF_WEAPONS 4096

// must stay static!!!!
#define WEAPON_ID_STRUCT_SIZE 0x119 // 0x115 + 0x4 [for ID expansion]



// must be multiples of 8, otherwise wonky integer things happen
#define MAX_NUMBER_OF_UNITS 4096

//#define 


#define SPECIAL_KEY_SHIFT 249
#define SPECIAL_KEY_CONTROL 250
#define SPECIAL_KEY_ALT 251




//#define MEGAMAP_CONTROLS
//#define MY_MOD
