#pragma once



#include "headers.h"
#include "xonrecordercompat.h"



#define DISABLED 0
#define ALLDONE 3

#define TAPROGRESS_INGAME 3


bool CmdWarpDone = false;


int ____GetScreenHeight_CmdWarp()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x37e23]
	}
}



void SetNewCommanderPosition(int xMapPos, int zMapPos)
{
	DWORD TAMainStructPtr = *(DWORD*)(0x00511DE8);
	DWORD Commander = *(DWORD*)(TAMainStructPtr + 0x1B63 + 0x67);
	*(WORD*)(Commander + 0x6C) = xMapPos;
	*(WORD*)(Commander + 0x74) = zMapPos;
}




int WINAPI CommanderWarpWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (XonMappedView->TAProgress != TAPROGRESS_INGAME)
		return FALSE;

	if (XonMappedView->CommanderWarp == DISABLED || XonMappedView->CommanderWarp == ALLDONE)
		return FALSE;

	if (____strcmpi(LastChatSentBuffer, ".ready") == 0)
	{
		CmdWarpDone = !CmdWarpDone; // Flip
		LastChatSentBuffer[0] = '\0';
		return FALSE;
	}

	if (CmdWarpDone)
		return FALSE;

	switch (msg)
	{
		case WM_LBUTTONDOWN:
			int xPos = LOWORD(lParam);
			int yPos = HIWORD(lParam);

			DWORD TAMainStructPtr = *(DWORD*)(0x00511DE8);
			DWORD MapXLook = (TAMainStructPtr + 0x1431F);
			DWORD MapYLook = (TAMainStructPtr + 0x14323);

			if (xPos > 128 && yPos > 32 && yPos < ____GetScreenHeight_CmdWarp() - 32)
			{
				SetNewCommanderPosition((xPos - 128) + *(DWORD*)MapXLook, yPos + *(DWORD*)MapYLook);
			}
			return TRUE;
			break;
	}

	return FALSE;
}







void CommanderWarp()
{
	// nothing to init?
}