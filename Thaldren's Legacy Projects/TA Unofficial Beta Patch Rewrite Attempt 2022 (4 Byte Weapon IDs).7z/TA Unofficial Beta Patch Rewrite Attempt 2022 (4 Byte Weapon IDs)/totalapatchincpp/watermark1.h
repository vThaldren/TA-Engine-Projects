#pragma once


#include "defines.h"
#include "rendering.h"



const char* T;// = "T";
const char* h;// = "h";
const char* a;// = "a";
const char* l;// = "l";
const char* d;// = "d";
const char* r;// = "r";
const char* e;// = "e";
const char* n;// = "n";
//char endl = '\0';

const char* ____Ver;
const char* ____Ver2;

LPVOID ____T;
LPVOID ____h;
LPVOID ____a;
LPVOID ____l;
LPVOID ____d;
LPVOID ____r;
LPVOID ____e;
LPVOID ____n;

LPVOID ____Version;
LPVOID ____Version2;
LPVOID ____Version3;



void RenderWaterMark1()
{
	//int xPos = GetScreenWidth() - 64;
	//int yPos = GetScreenHeight() - 8;

	//int xPos = 0; // GetScreenWidth();
	//int yPos = 0; // GetScreenHeight();

	int xPos = GetScreenWidth() / 2 - 8*8 / 2;
	int yPos = GetScreenHeight() - 26;

	RenderText(xPos-4, yPos + 16, 8, 8, CustomFont, (char*)____T, 0xFF);
	RenderText(xPos+8-4, yPos + 16, 8, 8, CustomFont, (char*)____h, 0xFF);
	RenderText(xPos+16-4, yPos + 16, 8, 8, CustomFont, (char*)____a, 0xFF);
	RenderText(xPos+24-4, yPos + 16, 8, 8, CustomFont, (char*)____l, 0xFF);
	RenderText(xPos+32-4, yPos + 16, 8, 8, CustomFont, (char*)____d, 0xFF);
	RenderText(xPos+40-4, yPos + 16, 8, 8, CustomFont, (char*)____r, 0xFF);
	RenderText(xPos+48-4, yPos + 16, 8, 8, CustomFont, (char*)____e, 0xFF);
	RenderText(xPos+54-4, yPos + 16, 8, 8, CustomFont, (char*)____n, 0xFF);

	RenderText(xPos + 8, yPos, 8, 8, CustomFont, (char*)____Version, 0xA5);
	RenderText(xPos, yPos + 8, 8, 8, CustomFont, (char*)____Version2, 0xA5);
	//RenderText(xPos, yPos + 24, 8, 8, CustomFont, (char*)____Version3, 0xA5);
	//RenderText(xPos+54, yPos, 8, 8, CustomFont, &endl, 0xFF);
}




void WaterMark1()
{
	T = "T";
	h = "h";
	a = "a";
	l = "l";
	d = "d";
	r = "r";
	e = "e";
	n = "n";

	____Ver = "Alpha";
	____Ver2 = "5 0 0 0";
	//____Ver3 = (char*)""

	____T = ____malloc(____strlen(T));
	____memcpy(____T, (LPVOID)T, ____strlen(T) + 1);

	____h = ____malloc(____strlen(h));
	____memcpy(____h, (LPVOID)h, ____strlen(h) + 1);

	____a = ____malloc(____strlen(a));
	____memcpy(____a, (LPVOID)a, ____strlen(a) + 1);

	____l = ____malloc(____strlen(l));
	____memcpy(____l, (LPVOID)l, ____strlen(l) + 1);

	____d = ____malloc(____strlen(d));
	____memcpy(____d, (LPVOID)d, ____strlen(d) + 1);

	____r = ____malloc(____strlen(r));
	____memcpy(____r, (LPVOID)r, ____strlen(r) + 1);

	____e = ____malloc(____strlen(e));
	____memcpy(____e, (LPVOID)e, ____strlen(e) + 1);

	____n = ____malloc(____strlen(n));
	____memcpy(____n, (LPVOID)n, ____strlen(n) + 1);

	____Version = ____malloc(____strlen(____Ver));
	____memcpy(____Version, (LPVOID)____Ver, ____strlen(____Ver) + 1);

	____Version2 = ____malloc(____strlen(____Ver2));
	____memcpy(____Version2, (LPVOID)____Ver2, ____strlen(____Ver2) + 1);

	//____Version3 = (char*)____malloc(sizeof(____Ver3));
	//____memcpy(____Version3, (LPVOID)____Ver3, sizeof(____Ver3));
}