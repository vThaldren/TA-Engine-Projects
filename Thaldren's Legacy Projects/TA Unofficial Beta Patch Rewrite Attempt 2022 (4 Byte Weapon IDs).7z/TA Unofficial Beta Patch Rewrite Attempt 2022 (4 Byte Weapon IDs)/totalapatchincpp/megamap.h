#pragma once



#include "valkyriecompat.h"
#include "rendering.h"
#include "defines.h"


// MegaMap
HookStruct LoadMap;
//HookStruct PostGameScreenRender;
HookStruct SkipGameScreenRender;





struct TNTMapHeader
{
	int IDVersion;
	int Width;
	int Height;
	WORD* MapDataPtr;
	WORD* MapAttrPtr;
	LPBYTE TileGFXPtr;
	int Tiles;
	int TileAnims;
	int TileAnimPtr;
	int SeaLevel;
	LPBYTE MiniMapPtr;
	int Unknown1;
	int Padding[4];
};

int GameScreenWidth;
int GameScreenHeight;
LPBYTE MegaMapImage;
TNTMapHeader TNTMap;
int MapWidth;
int MapHeight;
RECT MegaMapRect;
RECT MegaMapPosition;
RECT EmptyRect1;
RECT EmptyRect2;
RECT TAMapTAPos;

// When to update next
DWORD NextTickCount;

// Dispensible Live Surface
LPBYTE MegaMapSurface = 0;
LPBYTE LastMegaMapSurface = 0;

// LOS
LPBYTE LOSMap;



// UnitsMap
unsigned char MegaWeaponColor1;
unsigned char MegaWeaponColor2;
unsigned char MegaWeaponColor3;

unsigned char MegaRadarColor;
unsigned char MegaSonarColor;
unsigned char MegaRadarJamColor;
unsigned char MegaSonarJamColor;
unsigned char MegaAntiNukeColor;

unsigned char PlayerIconColors[10];
unsigned char OriginalIconColors[10];

int IconWidth = 8;
int IconHeight = 8;

bool RenderMegaMap = false;

void LoadMegaMap(TNTMapHeader*);
void RenderMap();

void DrawLOSOnMegaMapSurface(/*LPBYTE*/);
void DrawUnitsOnMegaMapSurface();
void DrawProjectilesOnMegaMapSurface();

void MoveToMouseMapPositionOnMegaMap(int, int);




enum SelectButtonState
{
	Down,
	Select,
	Up,
	None
};



int SelectState;
RECT SelectScreenRectangle;
DWORD SelectTick;





int WINAPI MegaMapWndProc(HWND, UINT, WPARAM, LPARAM);











const int MAX_PLAYER_COUNT = 10;

struct PlayerResources
{
	float CurrentEnergy;
	float EnergyProduction;
	float EnergyExpense;
	float CurrentMetal;
	float MetalProduction;
	float MetalExpense;
	float EnergyStorageMax;
	float MetalStorageMax;
};




//int ____GetGameState();
unsigned char GetMapSeaLevel();
int GetGameScreenWidth();
int GetGameScreenHeight();
int GetScreenWidth();
int GetScreenHeight();
RECT GetGameScreenRect();
short GetMaxScrollX();
short GetMaxScrollZ();
char GetDesktopGUIRadarObjectColorByIndex(int Index);
unsigned short GetLOSType();









int GetGameScreenWidth()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov eax, [esi + 0x37E37]
	}
}

int GetGameScreenHeight()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov eax, [esi + 0x37E3B]
	}
}

char GetDesktopGUIRadarObjectColorByIndex(int Index)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x519
		add esi, 0x8B2
		add esi, Index
		xor eax, eax
		mov al, [esi]
	}
}

unsigned short GetLOSType()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		xor eax, eax
		mov ax, [esi + 0x14281]
	}
}

unsigned char GetMapSeaLevel()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x141FB
		add esi, 0x84
		xor eax, eax
		mov al, [esi]
	}
}


short GetMaxScrollX()
{
	int* TAMemPtr;
	int ScreenWidth;
	int* MapSizeX;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov TAMemPtr, eax

		mov eax, dword ptr ds:[0x51fbd0]
		mov eax, [eax + 0xD4]
		mov ScreenWidth, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422b]
		mov MapSizeX, eax
	}

	return *MapSizeX - (ScreenWidth - 128);
}

short GetMaxScrollZ()
{
	int* TAMemPtr;
	int ScreenHeight;
	int* MapSizeZ;

	__asm
	{
		mov eax, ds:[0x511de8]
		mov TAMemPtr, eax

		mov eax, ds:[0x51fbd0]
		mov eax, [eax + 0xD8]
		mov ScreenHeight, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422f]
		mov MapSizeZ, eax
	}

	return *MapSizeZ - (ScreenHeight - 64);
}









































void LoadMegaMap(TNTMapHeader* TNT)
{
	int MapDataPitch;
	int MapDataWidth;
	int MapDataHeight;
	float XInterval;
	float YInterval;
	float MegaMapScale;

	int MegaMapImageYStart;
	int MegaMapTileIndexYOffset;
	int MegaMapTileYOffset;

	int TileIndex;
	int MegaMapByte;
	LPBYTE TileImageStart;

	GameScreenWidth = GetGameScreenWidth();
	GameScreenHeight = GetGameScreenHeight();

	MegaMapImage = (LPBYTE)____malloc(GameScreenWidth * GameScreenHeight);
	MapWidth = GameScreenWidth;
	MapHeight = GameScreenHeight;

	____memset(&TNTMap, 0, sizeof(TNTMapHeader));

	// Parse Map Header

	____memcpy(&TNTMap, TNT, sizeof(TNTMapHeader));

	TNTMap.Width /= 2;
	TNTMap.Height /= 2;
	TNTMap.MapDataPtr = (WORD*)((int)(TNTMap.MapDataPtr) + (int)TNT);
	TNTMap.MapAttrPtr = (WORD*)((int)(TNTMap.MapAttrPtr) + (int)TNT);
	TNTMap.TileGFXPtr = (LPBYTE)((int)(TNTMap.TileGFXPtr) + (int)TNT);
	TNTMap.TileAnimPtr = ((int)(TNTMap.TileAnimPtr) + (int)TNT);
	TNTMap.MiniMapPtr = (LPBYTE)((int)(TNTMap.MiniMapPtr) + (int)TNT);

	// Parse Map

	MapDataPitch = TNTMap.Width;
	MapDataWidth = MapDataPitch - 1;
	MapDataHeight = TNTMap.Height - 4;
	MegaMapScale = float(MapWidth) / float(MapHeight);

	if ((MapDataHeight * MegaMapScale) < MapDataWidth)
	{
		MapHeight = int(float(MapWidth) / float(MapDataWidth) * float(MapDataHeight));
	}
	else if(MapDataHeight * MegaMapScale > MapDataWidth)
	{
		MapWidth = int(float(MapHeight) / float(MapDataHeight) * float(MapDataWidth));
	}
	else
	{
		if (MapWidth < MapHeight)
		{
			MapHeight = MapWidth;
		}
		else
		{
			MapWidth = MapHeight;
		}
	}

	XInterval = (float(MapDataWidth) * 32.0f) / MapWidth;
	YInterval = (float(MapDataHeight) * 32.0f) / MapHeight;

	if (XInterval < 1)
	{
		XInterval = 1;
	}

	if (YInterval < 1)
	{
		YInterval = 1;
	}

	if (MapWidth * MapHeight < GameScreenWidth * GameScreenHeight)
	{
		____free(MegaMapImage);
		MegaMapImage = (LPBYTE)____malloc(MapWidth * MapHeight);
	}

	for (int YPos = 0, Y2 = 0; YPos < MapHeight; YPos++, Y2 = int(YPos * YInterval))
	{
		MegaMapImageYStart = YPos * MapWidth;
		MegaMapTileIndexYOffset = (Y2 / 32) * MapDataPitch;
		MegaMapTileYOffset = (Y2 % 32) * 32;

		for (int XPos = 0, X2 = 0; XPos < MapWidth; XPos++, X2 = int(XPos * XInterval))
		{
			TileIndex = TNTMap.MapDataPtr[MegaMapTileIndexYOffset + X2 / 32];

			if (TileIndex < 0)
			{
				TileIndex = 0;
			}

			TileImageStart = &(TNTMap.TileGFXPtr[TileIndex * 32 * 32]);

			MegaMapByte = TileImageStart[MegaMapTileYOffset + (X2 % 32)];

			MegaMapImage[MegaMapImageYStart + XPos] = MegaMapByte;
		}
	}

	//MegaMapRect = GetGameScreenRect(); // should work? Nope!

	MegaMapPosition.left = GetGameScreenRect().left;
	MegaMapPosition.top = GetGameScreenRect().top;
	MegaMapPosition.right = MegaMapPosition.left + GameScreenWidth;
	MegaMapPosition.bottom = MegaMapPosition.top + GameScreenHeight;

	MegaMapRect.left = 0;
	MegaMapRect.top = 0;
	MegaMapRect.right = MegaMapPosition.right - MegaMapPosition.left;
	MegaMapRect.bottom = MegaMapPosition.bottom - MegaMapPosition.top;

	if (MapWidth < MegaMapRect.right && MegaMapRect.right - MapWidth > 2)
	{
		MegaMapRect.left = (MegaMapRect.right - MapWidth) / 2;
		MegaMapRect.right = (MegaMapRect.left + MapWidth);

		EmptyRect1.top = MegaMapPosition.top;
		EmptyRect1.bottom = MegaMapPosition.bottom;
		EmptyRect1.left = MegaMapPosition.left;
		EmptyRect1.right = MegaMapPosition.right - (MegaMapRect.right - MapWidth) / 2;

		EmptyRect2.top = MegaMapPosition.top;
		EmptyRect2.bottom = MegaMapPosition.bottom;
		EmptyRect2.left = MegaMapPosition.left + (MegaMapRect.left + MapWidth);
		EmptyRect2.right = MegaMapPosition.right;
	}

	if (MapHeight < MegaMapRect.bottom && MegaMapRect.bottom - MapHeight > 2)
	{
		MegaMapRect.top = (MegaMapRect.bottom - MapHeight) / 2;
		MegaMapRect.bottom = (MegaMapRect.top + MapHeight);

		EmptyRect1.top = MegaMapPosition.top;
		EmptyRect1.bottom = MegaMapPosition.top + (MegaMapPosition.bottom - MapHeight) / 2;
		EmptyRect1.left = MegaMapPosition.left;
		EmptyRect1.right = MegaMapPosition.right;

		EmptyRect2.top = MegaMapPosition.bottom - (MegaMapPosition.top + MapHeight);
		EmptyRect2.bottom = MegaMapPosition.bottom;
		EmptyRect2.left = MegaMapPosition.left;
		EmptyRect2.right = MegaMapPosition.right;
	}

	MegaMapPosition.top += MegaMapRect.top;
	MegaMapPosition.bottom = MegaMapPosition.top + MapHeight;
	MegaMapPosition.left += MegaMapRect.left;
	MegaMapPosition.right = MegaMapPosition.left + MapWidth;

	TAMapTAPos.left = 0;
	TAMapTAPos.top = 0;
	TAMapTAPos.right = (TNT->Width - 1) * 16;
	TAMapTAPos.bottom = (TNT->Height - 4) * 16;

	// LOS Map

	LOSMap = (LPBYTE)____malloc(MapWidth * MapHeight/* + 1*/);

	// Units Map

	MegaWeaponColor1 = GetDesktopGUIRadarObjectColorByIndex(6);
	MegaWeaponColor2 = 1;
	MegaWeaponColor3 = 1;
	MegaRadarColor = GetDesktopGUIRadarObjectColorByIndex(10);
	MegaSonarColor = GetDesktopGUIRadarObjectColorByIndex(10);
	MegaRadarJamColor = GetDesktopGUIRadarObjectColorByIndex(12);
	MegaSonarJamColor = GetDesktopGUIRadarObjectColorByIndex(12);
	MegaAntiNukeColor = GetDesktopGUIRadarObjectColorByIndex(15);

	// Unit Colors Here

	// 

	//

	// Rest of Init is simple / not doing at the moment




	// Done!
}

void RenderMap()
{
	//LPBYTE LocalMegaMapSurface;
	DWORD TickCount;

	if (____GetGameState() == GAME_STATE::IN_GAME)
	{
		if (RenderMegaMap == true)
		{
			//LocalMegaMapSurface = MegaMapImage;
			TickCount = TA_GetTickCount();

			if (TickCount >= NextTickCount)
			{
				if (MegaMapSurface == 0)
				{
					MegaMapSurface = (LPBYTE)____malloc(MapWidth * MapHeight);
				}

				// Clear MegaMapSurface
				//memset(MegaMapSurface, 0, MapWidth * MapHeight);

				____memcpy(MegaMapSurface, MegaMapImage, MapWidth * MapHeight);

				// LOS Map
				DrawLOSOnMegaMapSurface();

				// Units Map
				DrawUnitsOnMegaMapSurface();

				// Projectiles Map
				DrawProjectilesOnMegaMapSurface(); // To Do


				LastMegaMapSurface = MegaMapSurface;

				// Make into Config
				NextTickCount = TickCount + int(1000.0f / 30); // maybe modify to flag update on each engine tick
			}

			DrawRectangleFillColor(EmptyRect1.left, EmptyRect1.top, EmptyRect1.right - EmptyRect1.left, EmptyRect1.bottom - EmptyRect1.top, 0x00);
			DrawRectangleFillColor(EmptyRect2.left, EmptyRect2.top, EmptyRect2.right - EmptyRect2.left, EmptyRect2.bottom - EmptyRect2.top, 0x00);

			DrawRectanglePixelData(MegaMapPosition.left, MegaMapPosition.top, MapWidth, MapHeight, LastMegaMapSurface);
		}
	}
}

void DrawLOSOnMegaMapSurface(/*LPBYTE MapSurface*/)
{
	//int Line;
	//int SrcLine;

	char PlayerId;
	int MapX;
	int MapY;
	float XScale;
	float YScale;
	float MappedMemoryWidth;
	float MappedMemoryHeight;
	int i, j;
	int YOff;
	int LOSBitYOff;
	int PlayerMapX;
	int PlayerMapY;
	char SeaLevel;
	float LOSWidth;
	float LOSHeight;
	void* PlayerPtr;
	LPBYTE PlayerLOSMap;
	LPWORD LOSMemory;
	BYTE GrayTable[256];
	void* GrayTablePtr;

	//if (LOSMap)
	//{
	//	for (int j = 0; j < MapHeight; j++)
	//	{
	//		Line = MapWidth * j;
	//		SrcLine = MapWidth * j;

	//		for (int i = 0; i < MapWidth; i++)
	//		{
	//			//LOSMap[Line + i] = MegaMapSurface[SrcLine + i];
	//		}
	//	}
	//}

	//LOSMap = MegaMapSurface;

	// No Mapping
	if ((GetLOSType() & 1) == 1)
	{
		// Not Permanent
		if ((GetLOSType() & 2) != 2)
		{
			__asm
			{
				mov esi, dword ptr ds : [0x511DE8]
				xor eax, eax
				mov al, [esi + 0x2A43]
				mov PlayerId, al

				add esi, 0x1B63
				xor eax, eax
				mov al, PlayerId
				mov edx, 0x14B
				mul edx
				add esi, eax
				mov PlayerPtr, esi

				mov esi, dword ptr ds : [0x511DE8]
				mov eax, [esi + 0x14233]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapX, eax

				mov eax, [esi + 0x14237]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapY, eax

				mov eax, [esi + 0x14273]
				mov LOSMemory, eax
			}

			XScale = float(MapX) / float(MapWidth);
			YScale = float(MapY) / float(MapHeight);

			for (i = 0, MappedMemoryHeight = 0.0f; i < MapHeight; i++, MappedMemoryHeight += YScale)
			{
				YOff = i * MapWidth;
				LOSBitYOff = int(MappedMemoryHeight) * MapX;

				if ((((LOSMemory[LOSBitYOff + int(MappedMemoryWidth)]) & (1 << PlayerId)) >> PlayerId) == 0)
				{
					MegaMapSurface[YOff + j] = 0;
				}
			}
		}
		else
		{
			__asm
			{
				mov esi, dword ptr ds : [0x511DE8]
				xor eax, eax
				mov al, [esi + 0x2A43]
				mov PlayerId, al

				add esi, 0x1B63
				xor eax, eax
				mov al, PlayerId
				mov edx, 0x14B
				mul edx
				add esi, eax
				mov PlayerPtr, esi

				mov esi, dword ptr ds:[0x511DE8]
				mov eax, [esi + 0x14233]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapX, eax

				mov eax, [esi + 0x14237]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapY, eax

				mov eax, [esi + 0x14273]
				mov LOSMemory, eax
			}

			XScale = float(MapX) / float(MapWidth);
			YScale = float(MapY) / float(MapHeight);

			__asm
			{
				mov esi, dword ptr ds:[0x51FBD0]
				mov eax, [esi + 0xCC]
				mov GrayTablePtr, eax
			}

			____memcpy(GrayTable, GrayTablePtr, 256);

			__asm
			{
				mov esi, PlayerPtr
				add esi, 0x80
				mov eax, [esi]
				mov PlayerMapX, eax

				add esi, 4
				mov eax, [esi]
				mov PlayerMapY, eax

				sub esi, 8
				mov eax, [esi]
				mov PlayerLOSMap, eax
			}

			// Sea Level
			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				add esi, 0x141FB
				add esi, 0x84
				xor eax, eax
				mov al, [esi]
				mov SeaLevel, al
			}

			for (i = 0, MappedMemoryHeight = float(0 - SeaLevel / 20); i < MapHeight; i++, MappedMemoryHeight += YScale)
			{
				YOff = i * MapWidth;
				LOSBitYOff = int(MappedMemoryHeight < 0 ? 0 : MappedMemoryHeight) * MapX;

				for (j = 0, MappedMemoryWidth = 0.0f; j < MapWidth; j++, MappedMemoryWidth += XScale)
				{
					if ((((LOSMemory[LOSBitYOff + int(MappedMemoryWidth)]) & (1 << PlayerId)) >> PlayerId) == 0)
					{
						MegaMapSurface[YOff + j] = 0;
					}
					else
					{
						if (PlayerLOSMap[LOSBitYOff + int(MappedMemoryWidth)] == 0)
						{
							MegaMapSurface[YOff + j] = GrayTable[MegaMapSurface[YOff + j]];
						}
					}
				}
			}
		}
	}
	else
	{
		if ((GetLOSType() & 2) != 2)
		{
			// Full View ??????? Seems backwards
		}
		else
		{
			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				xor eax, eax
				mov al, [esi + 0x2A43]
				mov PlayerId, al

				add esi, 0x1B63
				xor eax, eax
				mov al, PlayerId
				mov edx, 0x14B
				mul edx
				add esi, eax
				mov PlayerPtr, esi

				mov esi, dword ptr ds : [0x511DE8]
				mov eax, [esi + 0x14233]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapX, eax

				mov eax, [esi + 0x14237]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapY, eax

				mov eax, [esi + 0x14273]
				mov LOSMemory, eax
			}

			XScale = float(MapX) / float(MapWidth);
			YScale = float(MapY) / float(MapHeight);

			__asm
			{
				mov esi, dword ptr ds:[0x51FBD0]
				mov eax, [esi + 0xCC]
				mov GrayTablePtr, eax
			}

			____memcpy(GrayTable, GrayTablePtr, 256);

			__asm
			{
				mov esi, PlayerPtr
				add esi, 0x80
				mov eax, [esi]
				mov PlayerMapX, eax

				add esi, 4
				mov eax, [esi]
				mov PlayerMapY, eax

				sub esi, 8
				mov eax, [esi]
				mov PlayerLOSMap, eax
			}

			// Sea Level
			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				add esi, 0x141FB
				add esi, 0x84
				xor eax, eax
				mov al, [esi]
				mov SeaLevel, al
			}

			for (i = 0, LOSHeight = float(0 - SeaLevel / 20); i < MapHeight; i++, LOSHeight += YScale)
			{
				YOff = i * MapWidth;
				LOSBitYOff = int(LOSHeight < 0 ? 0 : LOSHeight) * MapX;

				for (j = 0, LOSWidth = 0.0f; j < MapWidth; j++, LOSWidth += XScale)
				{
					if (PlayerLOSMap[LOSBitYOff + int(LOSWidth)] == 0)
					{
						MegaMapSurface[YOff + j] = GrayTable[MegaMapSurface[YOff + j]];
					}
				}
			}
		}
	}

	//MegaMapSurface = LOSMap;
}

void DrawUnitsOnMegaMapSurface()
{
	void* BeginUnitsArrayPtr;
	void* CurrentUnitPtr;
	short CurrentUnitId;
	int HotRadarUnitsCount;
	void* HotRadarUnitsPtr;

	//int PlayerId;
	int TAX;
	int TAY;

	int XPos;
	int YPos;
	int ZPos;

	int DestWidth;
	int DestHeight;

	int DestPixelYStart;
	int SrcPixelYStart;

	char UnitOwnerIndex;
	//void* UnitOwnerPtr;

	unsigned char PlayerColor;

	WORD FootPrintX;
	WORD FootPrintY;

	RECT DestPosSize;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov eax, [esi + 0x14357]
		mov BeginUnitsArrayPtr, eax

		mov eax, [esi + 0x1436B] // Hot Radar Units
		mov HotRadarUnitsCount, eax

		mov eax, [esi + 0x14363]
		mov HotRadarUnitsPtr, eax
	}

	for (int i = 0; i < HotRadarUnitsCount; i++)
	{
		__asm
		{
			mov esi, HotRadarUnitsPtr
			mov eax, 10
			mov edx, i
			mul edx
			add esi, eax
			xor eax, eax
			mov ax, [esi] // ID
			mov CurrentUnitId, ax
			mov edx, 0x118
			mul edx
			mov esi, BeginUnitsArrayPtr
			add esi, eax
			mov CurrentUnitPtr, esi
		}

		if (CurrentUnitId != 0)
		{
			// Draw Unit Icon

			__asm
			{
				// TAX - First
				mov esi, CurrentUnitPtr
				add esi, 0x6A
				xor eax, eax
				mov ax, [esi + 2]
				mov XPos, eax

				// TAY - First
				mov esi, CurrentUnitPtr
				add esi, 0x6A
				xor eax, eax
				mov ax, [esi + 10]
				mov YPos, eax

				mov esi, CurrentUnitPtr
				add esi, 0x6A
				xor eax, eax
				mov ax, [esi + 6]
				mov ZPos, eax

				mov esi, CurrentUnitPtr
				mov esi, [esi + 0x92]
				xor eax, eax
				mov ax, [esi + 0x14A]
				mov FootPrintX, ax

				mov esi, CurrentUnitPtr
				mov esi, [esi + 0x92]
				xor eax, eax
				mov ax, [esi + 0x14C]
				mov FootPrintY, ax

				mov esi, CurrentUnitPtr
				mov al, [esi + 0xFF]
				mov UnitOwnerIndex, al
			}

			TAX = XPos - FootPrintX / 2;
			TAY = YPos - ZPos / 2 - FootPrintY / 2;

			DestPosSize.left = int(float(TAX) * (float(MapWidth) / float(TAMapTAPos.right))) - IconWidth / 2;
			DestPosSize.right = DestPosSize.left + IconWidth;
			DestPosSize.top = int(float(TAY) * (float(MapHeight) / float(TAMapTAPos.bottom))) - IconHeight / 2;
			DestPosSize.bottom = DestPosSize.top + IconHeight;

			if (DestPosSize.left < 0)
			{
				DestPosSize.left = 0;
			}

			if (DestPosSize.right > MapWidth - IconWidth)
			{
				DestPosSize.right = MapWidth - IconWidth;
			}

			if (DestPosSize.top < 0)
			{
				DestPosSize.top = 0;
			}

			if (DestPosSize.bottom > MapHeight - IconHeight)
			{
				DestPosSize.bottom = MapHeight - IconHeight;
			}

			DestWidth = DestPosSize.bottom - DestPosSize.top;
			DestHeight = DestPosSize.right - DestPosSize.left;

			//Rendering::DrawRectangleFillColor(DestPosSize.left, DestPosSize.top, DestWidth, DestHeight, Color);
			// Lol! Can't have MegaMap drawing on top of this line
			// That is what was happening :p

			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				add esi, 0x1B63
				mov eax, 0x14B
				xor edx, edx
				mov dl, UnitOwnerIndex
				mul edx
				add esi, eax
				mov esi, [esi + 0x27]
				xor eax, eax
				mov al, [esi + 0x96] // Player Color
				mov PlayerColor, al
			}

			// OTA
			OriginalIconColors[0] = 227;
			OriginalIconColors[1] = 212;
			OriginalIconColors[2] = 80;
			OriginalIconColors[3] = 235;
			OriginalIconColors[4] = 108;
			OriginalIconColors[5] = 219;
			OriginalIconColors[6] = 208;
			OriginalIconColors[7] = 93;
			OriginalIconColors[8] = 130;
			OriginalIconColors[9] = 67;

			// Total Mayhem
			//PlayerIconColors[0] = 227;
			//PlayerIconColors[1] = 201;
			//PlayerIconColors[2] = 193;
			//PlayerIconColors[3] = 165;
			//PlayerIconColors[4] = 32;
			//PlayerIconColors[5] = 148;
			//PlayerIconColors[6] = 80;
			//PlayerIconColors[7] = 242;
			//PlayerIconColors[8] = 115;
			//PlayerIconColors[9] = 67;

			//for (int i = 0; i < 10; i++)
			//{
				//if (PlayerColor == OriginalIconColors[i])
				//{
					PlayerColor = OriginalIconColors[PlayerColor];
					//i = 10;
				//}
			//}

			for (int YPos = 0; YPos < DestHeight; YPos++)
			{
				DestPixelYStart = (YPos + DestPosSize.top) * MapWidth;
				SrcPixelYStart = YPos * IconWidth;

				for (int XPos = 0; XPos < DestWidth; XPos++)
				{
					MegaMapSurface[DestPixelYStart + (XPos + DestPosSize.left)] = PlayerColor;
				}
			}
		}
	}
}

void DrawProjectilesOnMegaMapSurface()
{

}

void MoveToMouseMapPositionOnMegaMap(int xPos, int yPos)
{
	int TAPosX;
	int TAPosY;
	int TAPosZ;

	int MoveTAX;
	int MoveTAY;
	int MoveTAZ;

	int TAXNew;
	int TAYNew;
	//int TAZNew;

	int NewXPos;
	int NewYPos;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov dword ptr [esi + 0x142F3], 0
	}

	NewXPos = xPos;
	NewYPos = yPos;

	if (NewXPos > MegaMapPosition.right)
	{
		NewXPos = MegaMapPosition.right;
	}

	if (NewXPos < MegaMapPosition.left)
	{
		NewXPos = MegaMapPosition.left;
	}

	if (NewYPos > MegaMapPosition.bottom)
	{
		NewYPos = MegaMapPosition.bottom;
	}

	if (NewYPos < MegaMapPosition.top)
	{
		NewYPos = MegaMapPosition.top;
	}

	// These are needed!
	NewXPos -= MegaMapPosition.left;
	NewYPos -= MegaMapPosition.top;

	// Get TA Position
	TAPosX = int(float(NewXPos) / float(float(MapWidth) / float(TAMapTAPos.right - TAMapTAPos.left)));
	TAPosY = int(float(NewYPos) / float(float(MapHeight) / float(TAMapTAPos.bottom - TAMapTAPos.top)));

	TAPosZ = GetMapSeaLevel();

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x2CAA
		mov eax, TAPosX
		mov [esi], eax
		mov eax, TAPosY
		mov [esi + 4], eax
		mov eax, TAPosZ
		mov [esi + 8], eax
	}

	MoveTAX = TAPosX + (MapWidth / 2 - NewXPos);
	MoveTAY = TAPosY + (MapHeight / 2 - NewYPos);
	MoveTAZ = TAPosZ;

	TAXNew = MoveTAX - ((GetScreenWidth() - GetGameScreenRect().left) / 2);
	TAYNew = MoveTAY - ((GetScreenHeight() - GetGameScreenRect().top) / 2);

	if (TAXNew < 0)
	{
		TAXNew = 0;
	}

	if (TAYNew < 0)
	{
		TAYNew = 0;
	}

	if (TAXNew > GetMaxScrollX())
	{
		TAXNew = GetMaxScrollX();
	}

	if (TAYNew > GetMaxScrollZ())
	{
		TAYNew = GetMaxScrollZ();
	}

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1431F
		mov eax, TAXNew
		mov [esi], eax
		mov eax, TAYNew
		mov [esi + 4], eax
		mov eax, TAXNew
		mov [esi + 8], eax
		mov eax, TAYNew
		mov [esi + 12], eax
	}

	TA_UpdateLOSState(0);
}



















__declspec(naked) void LoadMap_Hook_1()
{
	__asm
	{
		mov [Temp15], eax
		mov [Temp16], edx
		mov [Temp17], ecx
		mov [Temp18], ebx
		mov [Temp19], esi
		mov [Temp20], edi
		mov [Temp21], ebp

		push eax
		call LoadMegaMap
		add esp, 4 // Needed since not __stdcall

		mov eax, [Temp15]
		mov edx, [Temp16]
		mov ecx, [Temp17]
		mov ebx, [Temp18]
		mov esi, [Temp19]
		mov edi, [Temp20]
		mov ebp, [Temp21]

		mov ebx, eax
		mov eax, [ebx]
		cmp eax, 0x1020

		jmp [LoadMap.Hook_Return_Destination]
	}
}



__declspec(naked) void BypassGameScreenRender()
{
	__asm
	{
		mov [Temp1], eax
		mov [Temp2], edx
		mov [Temp3], ecx
		mov [Temp4], ebx
		mov [Temp5], esi
		mov [Temp6], edi
		mov [Temp7], ebp

		call RenderMap

		mov eax, [Temp1]
		mov edx, [Temp2]
		mov ecx, [Temp3]
		mov ebx, [Temp4]
		mov esi, [Temp5]
		mov edi, [Temp6]
		mov ebp, [Temp7]

		jmp [SkipGameScreenRender.Hook_Return_Destination]
	}
}




#ifdef MEGAMAP_CONTROLS


bool ____SelectLeftButtonDown(int x, int y, bool check)
{
	if (check == false)
	{
		SelectState = 0;
		SelectScreenRectangle.left = x;
		SelectScreenRectangle.top = y;
		SelectTick = TA_GetTickCount();
	}

	return FALSE;
}





bool ____DoubleClick(int x, int y, bool shift)
{

}




bool ____SelectLeftButtonUp(int x, int y, bool check, bool shift)
{
	DWORD TAMainStructPtr = *(DWORD*)(0x00511DE8);

	if (SelectState == SelectButtonState::Select)
	{
		int Temp;
		PositionDWORD TempPos;


	}

}

#endif



void MegaMap()
{
	//WriteJumpHook((LPVOID)0x00469624, (LPVOID)BypassGameScreenRender); // use valkyrie compat for now
	Hook(&LoadMap, 0x00483638, (unsigned int)LoadMap_Hook_1, 0x00483641, true);
	Hook(&SkipGameScreenRender, 0x00469624, (unsigned int)BypassGameScreenRender, 0x00469F23, false);
}