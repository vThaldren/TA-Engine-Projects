#pragma once


#include "headers.h"




DWORD SFXAddressArray[] =
{
	0x00471184,
	0x004713D9,
	0x00471509,
	0x0047163E,
	0x00471783,
	0x004718B2,
	0x00471AD8,
	0x00472072,
	0x004721A0,
	0x004722D0,
	0x004723D7,
	0x004724D6,
	0x004725D5,
	0x004726C1,
	0x004727B1,
	0x0047289B,
	0x0047297B,
	0x00472A5B,
	0x00472BF4,
	0x00472CDA
};




void SFXLimit()
{
	DWORD SFXLimit = 0x5000;
	DWORD SFXVectorLimit = 0x32000;

	*(DWORD*)(0x00471C83) = SFXVectorLimit;

	*(DWORD*)(0x00471184) = SFXLimit;
	*(DWORD*)(0x004713D9) = SFXLimit;
	*(DWORD*)(0x00471509) = SFXLimit;
	*(DWORD*)(0x0047163E) = SFXLimit;
	*(DWORD*)(0x00471783) = SFXLimit;
	*(DWORD*)(0x004718B2) = SFXLimit;
	*(DWORD*)(0x00471AD8) = SFXLimit;
	*(DWORD*)(0x00472072) = SFXLimit;
	*(DWORD*)(0x004721A0) = SFXLimit;
	*(DWORD*)(0x004722D0) = SFXLimit;
	*(DWORD*)(0x004723D7) = SFXLimit;
	*(DWORD*)(0x004724D6) = SFXLimit;
	*(DWORD*)(0x004725D5) = SFXLimit;
	*(DWORD*)(0x004726C1) = SFXLimit;
	*(DWORD*)(0x004727B1) = SFXLimit;
	*(DWORD*)(0x0047289B) = SFXLimit;
	*(DWORD*)(0x0047297B) = SFXLimit;
	*(DWORD*)(0x00472A5B) = SFXLimit;
	*(DWORD*)(0x00472BF4) = SFXLimit;
	*(DWORD*)(0x00472CDA) = SFXLimit;

}