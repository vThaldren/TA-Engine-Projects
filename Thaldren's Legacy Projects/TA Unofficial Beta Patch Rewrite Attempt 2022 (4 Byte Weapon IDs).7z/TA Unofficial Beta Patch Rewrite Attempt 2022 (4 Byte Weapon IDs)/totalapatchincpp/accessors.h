#pragma once



enum GAME_STATE
{
	LOADING = 5,
	IN_GAME = 6
};




short ____GetMaxScrollX()
{
	int* TAMemPtr;
	int ScreenWidth;
	int* MapSizeX;

	__asm
	{
		mov eax, ds: [0x511de8]
		mov TAMemPtr, eax

		mov eax, ds : [0x51fbd0]
		mov eax, [eax + 0xD4]
		mov ScreenWidth, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422b]
		mov MapSizeX, eax
	}

	return *MapSizeX - (ScreenWidth - 128);
}

short ____GetMaxScrollZ()
{
	int* TAMemPtr;
	int ScreenHeight;
	int* MapSizeZ;

	__asm
	{
		mov eax, ds: [0x511de8]
		mov TAMemPtr, eax

		mov eax, ds : [0x51fbd0]
		mov eax, [eax + 0xD8]
		mov ScreenHeight, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422f]
		mov MapSizeZ, eax
	}

	return *MapSizeZ - (ScreenHeight - 64);
}




unsigned short ____GetMouseOverUnit()
{
	__asm
	{
		mov eax, dword ptr ds : [0x511DE8]
		mov dx, [eax + 0x2CBA]
		xor eax, eax
		mov ax, dx
	}
}




char ____GetMouseOverUnitPlayerArrayIndex()
{
	void* BeginInGameUnitsArray;
	unsigned short MouseOverUnit;
	char UnitPlayerArrayIndex;

	__asm
	{
		mov eax, dword ptr ds : [0x511DE8]
		mov eax, [eax + 0x14357]
		mov BeginInGameUnitsArray, eax

		mov eax, dword ptr ds : [0x511DE8]
		mov ax, [eax + 0x2CBA]
		mov MouseOverUnit, ax

		xor eax, eax
		xor edx, edx
		mov eax, 0x118
		mov dx, MouseOverUnit
		mul edx
		mov edx, BeginInGameUnitsArray
		add eax, edx
		mov eax, [eax + 0x96]
		mov al, [eax + 0x146]
		mov UnitPlayerArrayIndex, al
	}

	return UnitPlayerArrayIndex;
}




char ____GetLocalPlayerArrayIndex()
{
	char LocalHumanPlayerId;
	void* PlayersArrayStart;
	char LocalPlayerArrayIndex;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov al, [eax + 0x2A42]
		mov LocalHumanPlayerId, al

		mov eax, dword ptr ds:[0x511DE8]
		lea eax, [eax + 0x1B63]
		mov PlayersArrayStart, eax

		xor eax, eax
		mov eax, 0x14B
		xor edx, edx
		mov dl, LocalHumanPlayerId
		mul edx
		mov edx, PlayersArrayStart
		add eax, edx
		mov al, [eax + 0x146]
		mov LocalPlayerArrayIndex, al
	}

	return LocalPlayerArrayIndex;
}


int ____GetGameState()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x391F1]
	}
}



__declspec(naked) int ____GetGameType()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax+0x391E9]
		mov eax, [eax]
		ret
	}
}