#pragma once


#include "headers.h"
#include "hotkeys.h"
#include "buildlinesandrings.h"
#include "insert.h"
#include "megamap.h"
#include "resourcebars.h"
#include "commanderwarp.h"
#include "totalafunctions.h"

LPVOID ____KeyboardInputHandler_Hook_1_Return;
LPVOID ____WndProc_Hook_1_Return;


extern char* LastChatSentBuffer;



LRESULT(WINAPI* ____DefWindowProcA)(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
int(WINAPI* ____ChatCommandHandler)(char* ChatText, DWORD CommandMask);



BOOL WINAPI ____KeyboardInputHandler(BYTE Key)
{
	if (____GetGameState() == GAME_STATE::IN_GAME)
	{
		switch (Key)
		{
		case 0xAB: // B  ???
		//case 0x42: // B
			if (____GetAsyncSpecialKeyState(SPECIAL_KEY_CONTROL)) // Ctrl
			{
				____DeselectAllUnits();
				____NextIdleConstruction();
				____UpdateSelectedUnitEffect();
				____UpdateSelectedtUnitMenu();
				return TRUE; // skip all other input
			}
			break;
		case 0xBC: // Need to restore Ctrl+S Default Functionality into Ctrl+Shift+S
			// Ctrl+S - No Shift
			if (/*(TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && */(TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0)
			{
				____DeselectAllUnits();
				____SelectUnitsWithWeaponsOnScreen();
				____UpdateSelectedUnitEffect();
				____UpdateSelectedtUnitMenu();
				return TRUE;
			}
		case 0xEE: // INS button (Insert)
			if (____strlen(LastChatSentBuffer) > 0)
			{
				if (LastChatSentBuffer[0] == '+')
				{
					DWORD CommandMask = 1; // Normal
					DWORD TAMainStructPtr = *(DWORD*)(0x00511DE8);
					if ((*(DWORD*)(TAMainStructPtr + 0x37F2F) & 2) != 0)
					{
						CommandMask = 7; // Debug
					}
					if (*(DWORD*)(0x005091CC) == 1) // CheatsEnabled???
					{
						CommandMask |= 2; // Cheat Command???
					}
					/*int HandlerResult = */____ChatCommandHandler(LastChatSentBuffer + 1, CommandMask);
					// Tentative More Code???
					return TRUE;
				}
			}
			break;
		}
	}

	return FALSE;
}





BOOL WINAPI OverrideInputWndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	if (____GetGameState() == GAME_STATE::IN_GAME)
	{
		switch (Msg)
		{
		case WM_LBUTTONDOWN:
			if (____GetAsyncSpecialKeyState(SPECIAL_KEY_CONTROL) && ____GetAsyncSpecialKeyState(SPECIAL_KEY_SHIFT) && ____GetAsyncSpecialKeyState(SPECIAL_KEY_ALT))
			{
				if (____strlen(LastChatSentBuffer) > 0)
				{
					if (LastChatSentBuffer[0] == '+')
					{
						DWORD CommandMask = 1; // Normal
						DWORD TAMainStructPtr = *(DWORD*)(0x00511DE8);
						if ((*(DWORD*)(TAMainStructPtr + 0x37F2F) & 2) != 0)
						{
							CommandMask = 7; // Debug
						}
						if (*(DWORD*)(0x005091CC) == 1) // CheatsEnabled???
						{
							CommandMask |= 2; // Cheat Command???
						}
						/*int HandlerResult = */____ChatCommandHandler(LastChatSentBuffer + 1, CommandMask);
						// Tentative More Code???
						return TRUE;
					}
				}
			}
			break;
		case WM_KEYDOWN:
			if (wParam == 0x37 && ((TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && (TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) > 0))
			{
				DoRenderResourceBars = !DoRenderResourceBars;
				return TRUE;
			}
			break;

		case WM_LBUTTONDBLCLK:
		case WM_RBUTTONDBLCLK:
			// Double Click Unit

			if ((TA_GetAsyncKeyState(0x58) & 0x8000) == 0)
			{
				if (LOWORD(lParam) > GetGameScreenRect().left && LOWORD(lParam) < GetGameScreenRect().right &&
					HIWORD(lParam) > GetGameScreenRect().top && HIWORD(lParam) < GetGameScreenRect().bottom)
				{
					if (____GetMouseOverUnit() != 0)
					{
						if (____GetLocalPlayerArrayIndex() == ____GetMouseOverUnitPlayerArrayIndex())
						{
							____DeselectAllUnits();
							____SelectAllOfDoubleClickedUnitOnScreen();
							____UpdateSelectedUnitEffect();
							____UpdateSelectedtUnitMenu();
							return TRUE;
						}
					}
				}
			}
		}
	}
	return FALSE;
}







int WINAPI MegaMapWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
#ifdef MEGAMAP_CONTROLS
	int xPos;
	int yPos;
	bool shift;
#endif

	if (____GetGameState() == GAME_STATE::IN_GAME)
	{
		if (msg == WM_MOUSEWHEEL)
		{
			if (((TA_GetAsyncKeyState(0x58) & 0x8000) == 0) && ((TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0) && ((TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) == 0))
			{
				if ((short)HIWORD(wParam) < 0)
				{
					if (RenderMegaMap == false)
					{
						RePatch(&SkipGameScreenRender);
						____PlaySoundEffect("Options", 0);
						RenderMegaMap = true;
					}

					return TRUE;
				}
				else if ((short)HIWORD(wParam) > 0)
				{
					if (RenderMegaMap == true)
					{
						// Move To Mouse Position On Map
						MoveToMouseMapPositionOnMegaMap(LOWORD(lParam), HIWORD(lParam));

						// Disable MegaMap Render
						Revert(&SkipGameScreenRender);
						____PlaySoundEffect("Previous", 0);
						RenderMegaMap = false;
					}

					return TRUE;
				}
			}
		}

#ifdef MEGAMAP_CONTROLS
		switch (msg)
		{
			case WM_LBUTTONDOWN:
				____SelectLeftButtonDown(xPos, yPos, false);
				break;
			case WM_LBUTTONDBLCLK:
				____DoubleClick(xPos, yPos, shift);
		}
#endif

	}
	return FALSE;
}












__declspec(naked) void ____KeyboardInputHandler_Hook_1()
{
	__asm
	{
		//mov [Buffer_Key], ebp
		
		push ebp
		call ____KeyboardInputHandler
		test eax, eax
		jz KeepChecking
		pop edi
		pop esi
		pop ebp
		pop edx
		add esp, 0x230
		ret

		KeepChecking:
		push 249
		jmp ____KeyboardInputHandler_Hook_1_Return

	}
}


__declspec(naked) void ____WndProc_Hook_1()
{
	__asm
	{

		mov eax, [esp + 16]
		mov ecx, [esp + 12]
		mov edx, [esp + 8]
		push eax
		mov eax, [esp + 4 + 4]
		push ecx
		push edx
		push eax

		call CommanderWarpWndProc
		test eax, eax
		jz keepChecking4
		mov eax, [esp + 16]
		mov ecx, [esp + 12]
		mov edx, [esp + 8]
		push eax
		mov eax, [esp + 4 + 4]
		push ecx
		push edx
		push eax
		call ____DefWindowProcA
		ret 16

		keepChecking4:
		mov eax, [esp+16]
		mov ecx, [esp+12]
		mov edx, [esp+8]
		push eax
		mov eax, [esp+4+4]
		push ecx
		push edx
		push eax

		call MegaMapWndProc
		test eax, eax
		jz keepChecking3
		mov eax, [esp+16]
		mov ecx, [esp+12]
		mov edx, [esp+8]
		push eax
		mov eax, [esp+4+4]
		push ecx
		push edx
		push eax
		call ____DefWindowProcA
		ret 16

		keepChecking3:
		mov eax, [esp + 16]
		mov ecx, [esp + 12]
		mov edx, [esp + 8]
		push eax
		mov eax, [esp + 4 + 4]
		push ecx
		push edx
		push eax

		call BuildLineAndBuildRingWndProc
		test eax, eax
		jz KeepChecking2
		mov eax, [esp + 16]
		mov ecx, [esp + 12]
		mov edx, [esp + 8]
		push eax
		mov eax, [esp + 4 + 4]
		push ecx
		push edx
		push eax
		call ____DefWindowProcA
		ret 16

		keepChecking2:
		mov eax, [esp+16]
		mov ecx, [esp+12]
		mov edx, [esp+8]
		push eax
		mov eax, [esp+4+4]
		push ecx
		push edx
		push eax

		call OverrideInputWndProc
		test eax, eax
		jz KeepChecking1
		mov eax, [esp+16]
		mov ecx, [esp+12]
		mov edx, [esp+8]
		push eax
		mov eax, [esp+4+4]
		push ecx
		push edx
		push eax
		call ____DefWindowProcA
		ret 16

		KeepChecking1:
		sub esp, 0x18
		push esi
		mov esi, [esp+0x24]
		jmp ____WndProc_Hook_1_Return
	}
}



void Input()
{
	____KeyboardInputHandler_Hook_1_Return = (LPVOID)0x00495EB0;
	____WndProc_Hook_1_Return = (LPVOID)0x004B5CC8; // Valkyrie Compat
	____DefWindowProcA = (LRESULT(WINAPI*)(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam))0x004FB308;
	____ChatCommandHandler = (int(WINAPI*)(char* ChatText, DWORD CommandMask))0x00417B50;


	WriteJumpHook((LPVOID)0x00495EAB, ____KeyboardInputHandler_Hook_1);
	WriteJumpHook((LPVOID)0x004B5CC0, ____WndProc_Hook_1); // Valkyrie Compat

}
