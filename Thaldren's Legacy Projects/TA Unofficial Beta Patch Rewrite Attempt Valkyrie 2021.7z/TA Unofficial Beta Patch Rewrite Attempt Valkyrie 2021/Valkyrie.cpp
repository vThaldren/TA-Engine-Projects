
#ifndef Valkyrie_cpp
#define Valkyrie_cpp

//#define DEBUG_BUILD

#define MAYHEM_MOD
//#define MAYHEM_MOD_OLD
//#define ESCALATION_MOD
//#define OTA_MOD
//#define VMOD_MOD

#pragma warning ( disable : 6001 )
#pragma warning ( disable : 6385 )
#pragma warning ( disable : 6386 )
#pragma warning ( disable : 26495 )
#pragma warning ( disable : 6011 )
#pragma warning ( disable : 6387 )

#pragma comment (lib, "DbgHelp.lib")
#pragma comment (lib, "Advapi32.lib")

#include <Windows.h>
#include <TlHelp32.h>
#include <DbgHelp.h>
#include <AclAPI.h>
#include <exception>
#include <codecvt>
#include <wchar.h>
#include <fstream>
#include <sstream>
#include <tchar.h>
#include <locale>
#include <vector>
#include <string>
#include <ctime>

/*
---------------------------------------------------------------------------------

	core function declarations and definitions

---------------------------------------------------------------------------------
*/

namespace Valkyrie
{
	namespace TotalA
	{
		HANDLE(__stdcall* TA_GetCurrentProcess)() = (HANDLE(__stdcall *)())0x004FB0C8;
		BOOL(__stdcall* TA_VirtualProtect)(LPVOID, SIZE_T, DWORD, PDWORD) = (BOOL(__stdcall *)(LPVOID, SIZE_T, DWORD, PDWORD))0x004FB086;
		HMODULE(__stdcall* TA_GetModuleHandleA)(LPCSTR) = (HMODULE(__stdcall *)(LPCSTR))0x004FB0C2;
		HANDLE(__stdcall* TA_CreateFileA)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE) = (HANDLE(__stdcall *)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE))0x0049F72E;
		UINT(__stdcall* TA_GetPrivateProfileIntA)(LPCSTR, LPCSTR, INT, LPCSTR) = (UINT(__stdcall *)(LPCSTR, LPCSTR, INT, LPCSTR))0x0049F746;
		DWORD(__stdcall* TA_GetModuleFileNameA)(HMODULE, LPSTR, DWORD) = (DWORD(__stdcall *)(HMODULE, LPSTR, DWORD))0x0049F782;
		SHORT(__stdcall* TA_GetAsyncKeyState)(INT) = (SHORT(__stdcall*)(INT))0x004fb314;
		HANDLE(__stdcall* TA_CreateSemaphoreA)(LPSECURITY_ATTRIBUTES, LONG, LONG, LPCSTR) = (HANDLE(__stdcall*)(LPSECURITY_ATTRIBUTES, LONG, LONG, LPCSTR))0x0049F7B2;
		DWORD(__stdcall* TA_WaitForSingleObject)(HANDLE, DWORD) = (DWORD(__stdcall*)(HANDLE, DWORD))0x0049f770;
		DWORD(__stdcall* TA_GetTickCount)() = (DWORD(__stdcall*)())0x0049F740;
		HANDLE(__stdcall* TA_CreateThread)(LPSECURITY_ATTRIBUTES, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD) = (HANDLE(__stdcall*)(LPSECURITY_ATTRIBUTES, SIZE_T, LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD))0x004FB098;
		void(__stdcall* TA_TestBuildSpot)(void) = (void(__stdcall*)(void))0x004197D0;
		void(__stdcall* TA_MapClick)(void*) = (void(__stdcall*)(void*))0x00498F70;
		void(__stdcall* TA_DrawRect)(RECT*, RECT*, int) = (void(__stdcall*)(RECT*, RECT*, int))0x004BF8C0;
		unsigned short(__stdcall* TA_MouseUnit)(void) = (unsigned short(__stdcall*)(void))0x0048CD80;
		HANDLE(__stdcall* TA_FindFirstFileA)(LPCSTR, LPWIN32_FIND_DATAA) = (HANDLE(__stdcall *)(LPCSTR, LPWIN32_FIND_DATAA))0x004FB19A;
		INT(__stdcall* TA_MessageBoxA)(HWND, LPCSTR, LPCSTR, UINT) = (INT(__stdcall*)(HWND, LPCSTR, LPCSTR, UINT))0x0049F7F4;
		void(__stdcall* TA_ShowText)(void*, char*, int, int) = (void(__stdcall*)(void*, char*, int, int))0x00463E50;
		void(__stdcall* TA_InterpretCommand)(char*, int) = (void(__stdcall*)(char*, int))0x00417B50;
		void(__stdcall* TA_UpdateLOSState)(int) = (void(__stdcall*)(int))0x004816A0;
	}
}

namespace Valkyrie
{
	namespace Patching
	{
		struct Hook
		{
			unsigned int Hook_Destination;
			unsigned int Hook_Function_Destination;
			unsigned int Hook_Return_Destination;

			unsigned char* Hook_Data;
			unsigned char* Original_Data;

			Hook();
			Hook(unsigned int, unsigned int, unsigned int, bool);
			void RePatch();
			void Revert();
		};

		struct Patch
		{
			unsigned int Patch_Destination;

			unsigned char* Patch_Data;
			unsigned char* Original_Data;

			unsigned int Patch_Size;

			Patch();
			Patch(unsigned int PatchDest, std::vector<unsigned char>, bool);
			void RePatch();
			void Revert();
		};
	}
}

Valkyrie::Patching::Hook::Hook()
{

}

Valkyrie::Patching::Hook::Hook(unsigned int HookDest, unsigned int HookFuncDest, unsigned int HookRetDest, bool DoPatch)
{
	DWORD OldProtect;
	unsigned char* WritePtr;
	unsigned char* ReadPtr;
	int RelativeJump;

	Hook_Destination = HookDest;
	Hook_Function_Destination = HookFuncDest;
	Hook_Return_Destination = HookRetDest;

	Original_Data = new unsigned char[5];

	ReadPtr = (unsigned char*)HookDest;

	for (size_t i = 0; i < 5; i++)
	{
		Original_Data[i] = ReadPtr[i];
	}

	Hook_Data = new unsigned char[5];

	Hook_Data[0] = 0xE9;

	RelativeJump = HookFuncDest - HookDest - 5;

	Hook_Data[1] = unsigned char(RelativeJump & 0xFF);
	Hook_Data[2] = unsigned char((RelativeJump >> 8) & 0xFF);
	Hook_Data[3] = unsigned char((RelativeJump >> 16) & 0xFF);
	Hook_Data[4] = unsigned char((RelativeJump >> 24) & 0xFF);

	if (DoPatch)
	{
		Valkyrie::TotalA::TA_VirtualProtect((LPVOID)HookDest, 5, PAGE_EXECUTE_READWRITE, &OldProtect);

		WritePtr = (unsigned char*)HookDest;

		for (int i = 0; i < 5; i++)
		{
			WritePtr[i] = Hook_Data[i];
		}

		Valkyrie::TotalA::TA_VirtualProtect((LPVOID)HookDest, 5, OldProtect, &OldProtect);
	}
}

void Valkyrie::Patching::Hook::RePatch()
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Hook_Destination, 5, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)Hook_Destination;

	for (int i = 0; i < 5; i++)
	{
		WritePtr[i] = Hook_Data[i];
	}

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Hook_Destination, 5, OldProtect, &OldProtect);
}

void Valkyrie::Patching::Hook::Revert()
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Hook_Destination, 5, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)Hook_Destination;

	for (size_t i = 0; i < 5; i++)
	{
		WritePtr[i] = Original_Data[i];
	}

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Hook_Destination, 5, OldProtect, &OldProtect);
}

Valkyrie::Patching::Patch::Patch()
{

}

Valkyrie::Patching::Patch::Patch(unsigned int PatchDest, std::vector<unsigned char> PatchData, bool DoPatch)
{
	DWORD OldProtect;
	unsigned char* WritePtr;
	unsigned char* ReadPtr;

	Patch_Destination = PatchDest;

	Patch_Size = PatchData.size();

	Patch_Data = new unsigned char[PatchData.size()];
	Original_Data = new unsigned char[PatchData.size()];

	for (size_t i = 0; i < PatchData.size(); i++)
	{
		Patch_Data[i] = PatchData[i];
	}

	ReadPtr = (unsigned char*)PatchDest;

	for (size_t i = 0; i < PatchData.size(); i++)
	{
		Original_Data[i] = ReadPtr[i];
	}

	if (DoPatch)
	{
		Valkyrie::TotalA::TA_VirtualProtect((LPVOID)PatchDest, PatchData.size(), PAGE_EXECUTE_READWRITE, &OldProtect);

		WritePtr = (unsigned char*)PatchDest;

		for (size_t i = 0; i < PatchData.size(); i++)
		{
			WritePtr[i] = Patch_Data[i];
		}

		Valkyrie::TotalA::TA_VirtualProtect((LPVOID)PatchDest, PatchData.size(), OldProtect, &OldProtect);
	}
}

void Valkyrie::Patching::Patch::RePatch()
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Patch_Destination, Patch_Size, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)Patch_Destination;

	for (size_t i = 0; i < Patch_Size; i++)
	{
		WritePtr[i] = Patch_Data[i];
	}

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Patch_Destination, Patch_Size, OldProtect, &OldProtect);
}

void Valkyrie::Patching::Patch::Revert()
{
	DWORD OldProtect;
	unsigned char* WritePtr;

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Patch_Destination, Patch_Size, PAGE_EXECUTE_READWRITE, &OldProtect);

	WritePtr = (unsigned char*)Patch_Destination;

	for (size_t i = 0; i < Patch_Size; i++)
	{
		WritePtr[i] = Original_Data[i];
	}

	Valkyrie::TotalA::TA_VirtualProtect((LPVOID)Patch_Destination, Patch_Size, OldProtect, &OldProtect);
}

namespace Valkyrie
{
	namespace Debugging
	{
		void CreateMemoryDump();
		void CreateMemoryDumpManual();
	}
}

void Valkyrie::Debugging::CreateMemoryDump()
{
	DWORD MemoryDumpFlags;
	HANDLE FileHandle;
	BOOL Result;

	time_t CurrentTime;
	tm GMT_Time;

	std::string FileName;

	CurrentTime = time(0);
	gmtime_s(&GMT_Time, &CurrentTime);

	FileName = std::to_string(GMT_Time.tm_year + 1900) + "_" + std::to_string(GMT_Time.tm_mon + 1) + "_" + std::to_string(GMT_Time.tm_mday) + "___" +
		std::to_string(GMT_Time.tm_hour) + "_" + std::to_string(GMT_Time.tm_min) + "_" + std::to_string(GMT_Time.tm_sec) + "_Valkyrie_CrashDump.dmp";

	MemoryDumpFlags = MiniDumpWithFullMemory | MiniDumpWithHandleData |
		MiniDumpWithProcessThreadData | MiniDumpWithFullMemoryInfo |
		MiniDumpWithThreadInfo | MiniDumpIgnoreInaccessibleMemory |
		MiniDumpWithModuleHeaders;

	FileHandle = Valkyrie::TotalA::TA_CreateFileA(FileName.c_str(), GENERIC_ALL, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (FileHandle)
	{
		Result = MiniDumpWriteDump(Valkyrie::TotalA::TA_GetCurrentProcess(), GetCurrentProcessId(), FileHandle, (MINIDUMP_TYPE)MemoryDumpFlags, nullptr, nullptr, nullptr);
	}
}

void Valkyrie::Debugging::CreateMemoryDumpManual()
{
	DWORD MemoryDumpFlags;
	HANDLE FileHandle;
	BOOL Result;

	time_t CurrentTime;
	tm GMT_Time;

	std::string FileName;

	CurrentTime = time(0);
	gmtime_s(&GMT_Time, &CurrentTime);

	FileName = std::to_string(GMT_Time.tm_year + 1900) + "_" + std::to_string(GMT_Time.tm_mon + 1) + "_" + std::to_string(GMT_Time.tm_mday) + "___" +
		std::to_string(GMT_Time.tm_hour) + "_" + std::to_string(GMT_Time.tm_min) + "_" + std::to_string(GMT_Time.tm_sec) + "_Valkyrie_Manual_Dump.dmp";

	MemoryDumpFlags = MiniDumpWithFullMemory | MiniDumpWithHandleData |
		MiniDumpWithProcessThreadData | MiniDumpWithFullMemoryInfo |
		MiniDumpWithThreadInfo | MiniDumpIgnoreInaccessibleMemory |
		MiniDumpWithModuleHeaders;

	FileHandle = Valkyrie::TotalA::TA_CreateFileA(FileName.c_str(), GENERIC_ALL, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (FileHandle)
	{
		Result = MiniDumpWriteDump(Valkyrie::TotalA::TA_GetCurrentProcess(), GetCurrentProcessId(), FileHandle, (MINIDUMP_TYPE)MemoryDumpFlags, nullptr, nullptr, nullptr);
	}
}

/*
---------------------------------------------------------------------------------

	function declarations

---------------------------------------------------------------------------------
*/

BOOL WINAPI DllMain(
	HINSTANCE hInstDLL,
	DWORD fdwReason,
	LPVOID lpvReserved
);

namespace Valkyrie
{
	namespace Temporary_Data
	{
		unsigned int TempPtr1;
		unsigned int Temp1, Temp2, Temp3, Temp4, Temp5, Temp6, Temp7;
		unsigned int Temp8, Temp9, Temp10, Temp11, Temp12, Temp13, Temp14;
		unsigned int Temp15, Temp16, Temp17, Temp18, Temp19, Temp20, Temp21;
		unsigned int Temp22, Temp23, Temp24, Temp25, Temp26, Temp27, Temp28;
		unsigned int TempErrorReportingStack[0x100000];
	}

	DWORD WINAPI DebuggingThreadFunction(LPVOID);

	namespace Debugging
	{
		unsigned int CrashDumpWritten;

#ifdef DEBUG_BUILD

		struct SharedMemStruct
		{
			DWORD LastGameReportedTickCount;
			DWORD InGame;
		};

		TCHAR SharedName[] = TEXT("Global\\DebuggingSharedMemStruct");
		SharedMemStruct* SharedStruct;

		HANDLE hFile = NULL;
		HANDLE hMapFile = NULL;
		void* pBuf = NULL;

		HANDLE ErrorCheckingThread;
		HANDLE MainThreadHandle;
		DWORD MainThreadId;
		bool FirstRun = 1;

		

		int LagTicksAllowedBeforeReport = 0;
		DWORD LastGameReportedTickCount;
		DWORD Reported_EIP;


		void ThreadReportData();

		SYSTEM_INFO SysInfo;
		DWORD Granularity;
		DWORD FileOffset = 0;
		DWORD FileMapStart = 0;
		DWORD MapViewSize = 0;
		DWORD FileMapSize = 0;
		DWORD iViewDelta = 0;
		DWORD BytesWritten;
		DWORD FileSize;
		LPVOID MapAddress;


		char* pData;
		SharedMemStruct* sData;

		HANDLE NamedPipe;
		HANDLE EventToChild;
		HANDLE EventFromChild;
#endif
	}

	namespace Variables
	{
		const char NewDataFileName[] = "Valkyrie.vky";

#ifdef OTA_MOD
		Patching::Patch NoCD[3];
#endif

#ifdef MAYHEM_MOD_OLD
		Patching::Patch NoCD[3];
		Patching::Patch HighTrajectoryBallisticWeapons;
		Patching::Patch HoldPositionDontChaseAttackers;
		Patching::Patch FireWeaponsWhileNanolathing[5];
		Patching::Patch Weapon3;
		Patching::Patch SubmergedTargets[5];
		Patching::Patch TargetLocking[4];
		Patching::Patch HealTime[3];
		Patching::Patch InitCloakedAfterUnitBuilt;
		Patching::Patch ResurrectedUnitsOn;
		Patching::Patch CommanderOrdersNoResetWhenAttacked;
		Patching::Patch AlliedVictoryOnByDefault;
		Patching::Patch StaticPlayerSlots[4];
		Patching::Patch AlwaysShowAllPlayersOnFinalScoreboard[2];
		Patching::Patch BuildUnitsBeforeRepairPatrolMode;
		Patching::Patch AIResourceIncome[11];
		Patching::Patch AIAntiNuke;

		Patching::Patch GP3Edits[9];
#endif

		Patching::Hook COBExtensionsHandler[2];


		Patching::Hook DataFile;

		Patching::Hook UnitLimitHook;
		Patching::Patch UnitLimitPatch;
		Patching::Patch Pathfinding;
		Patching::Patch CompositeBuffer[2];
		Patching::Patch SFXLimit[21];

		unsigned int SFXAddressArray[] =
		{
			0x00471184,
			0x004713D9,
			0x00471509,
			0x0047163E,
			0x00471783,
			0x004718B2,
			0x00471AD8,
			0x00472072,
			0x004721A0,
			0x004722D0,
			0x004723D7,
			0x004724D6,
			0x004725D5,
			0x004726C1,
			0x004727B1,
			0x0047289B,
			0x0047297B,
			0x00472A5B,
			0x00472BF4,
			0x00472CDA
		};

		Patching::Hook MixingBuffers;
		Patching::Patch DrawBuildRectLive[16];
		Patching::Hook MainWndProc;
		Patching::Hook RenderForTAHook;
		Patching::Patch CtrlShiftBuildQueueLive[2];

		Patching::Hook CrashDumps1;
		Patching::Hook CrashDumps2;
		Patching::Hook CrashDumps3;
		Patching::Hook CrashDumps4;

#ifdef MAYHEM_MOD_OLD
		Patching::Patch UnitCancellationOnDamageDeath;
#endif

		Patching::Hook LOSHooks[18];
		Patching::Patch LOSPatches[1];

		//Patching::Hook AlliedResourceBars;

		Patching::Patch Mayhem[256];
		Patching::Patch Escalation[256];

		// MegaMap
		Patching::Hook LoadMap;
		Patching::Hook PostGameScreenRender;
		Patching::Hook SkipGameScreenRender;

#ifdef DEBUG_BUILD
		Patching::Hook DebuggingThreadReporter;
#endif
	}

	namespace Main
	{
		void OpenDllFunction();
		void CloseDllFunction();

		int CheckUndesirableDLLs();
	}

	namespace Config
	{
		std::string ConfigFileName = "Valkyrie.ini";
		std::string ConfigFileName2 = "Valkyrie-ChatMacro.ini";
		TCHAR ConfigFileNameFullPath[256];
		TCHAR ConfigFileNameFullPath2[256];

		const int MAX_MACRO_CHAT_LINES = 32;
		std::string ConfigChatMacro[32];

		bool UseNoCD;
		bool UseMaxUnitLimit;
		unsigned short MaxUnitLimit;
		bool UsePathfinding;
		unsigned int PathfindingCycles;
		bool UseCompositeBuffer;
		unsigned int CompositeX;
		unsigned int CompositeY;
		bool UseSFXLimit;
		unsigned int SFXLimit;
		bool UseMixingBuffers;
		unsigned int MixingBuffers;
		bool UseTAHook;
		unsigned short MaxBuildSpacing;
		bool UseHotKeys;
		char CtrlShiftBuildQueueIncDecAmount;


		void ReadConfig();
		void AdjustConfigFilePath();
		void AdjustConfigFilePath2();
	}

	namespace TotalA
	{
		const int MAX_PLAYER_COUNT = 10;
		const int UNIT_STRUCT_SIZE = 0x118;

		namespace LOS
		{
			namespace Variables
			{
				int ViewPlayer;
				int AlliedStateChanged;
				int TestPlayerIndex;
				void* TestPlayerPtr;
				void* PlayerPtr;
				void* UnitPtr;
				int TestPlayer;

				struct LOSUpdatesStruct
				{
					void* Player;
					void* LargeGrid;
					void* UnitSightDistance;
					unsigned char FieldA;
					unsigned char FieldB;
					void* RecentDamageAndThings;
					unsigned int XPos;
					unsigned int YPos;
					unsigned int ZPos;
					unsigned int Unknown1;
					unsigned int Unknown2;
				};

				LOSUpdatesStruct* LOSUpdatesPtr;
			}
		}

		namespace COB
		{
			namespace Constants
			{
				const int VETERAN_LEVEL = 32;
				const int MIN_ID = 69;
				const int MAX_ID = 70;
				const int MY_ID = 71;
				const int UNIT_TEAM = 72;
				const int UNIT_BUILD_PERCENT_LEFT = 73;
				const int UNIT_ALLIED = 74;
				const int UNIT_IS_ON_THIS_COMP = 75;
				const int UNIT_CLOAKED = 111;

				const int CUSTOM_LOW = VETERAN_LEVEL;
				const int CUSTOM_HIGH = UNIT_CLOAKED;
			}

			namespace ASM_Functions
			{
				int CustomGetters(int, void*, int, int, int, int);
				void CustomSetters(int, void*, int);
			}

			namespace Data
			{
				bool GetIsAlteredUnitLimit();
				unsigned short GetActualUnitLimit();
				unsigned short GetMaxUnitLimit();
				void* GetUnitsPtr();
			}

			namespace Unit
			{
				unsigned char GetOwnerIndex(void*);
				void* GetOwnerPtr(void*);
				unsigned short GetKills(void*);
				int GetBuildPercentLeft(void*);

				void SetCloaked(void*, bool);
				int GetCloaked(void*);
			}

			namespace Player
			{
				bool GetAlliedState(void*, int);
				unsigned char GetPlayerType(void*);
			}

			namespace Memory
			{
				void* GetUnitPtr(int);
			}
		}
	}

	namespace Accessors
	{
		const int MAX_PLAYER_COUNT = 10;

		struct PlayerResources
		{
			float CurrentEnergy;
			float EnergyProduction;
			float EnergyExpense;
			float CurrentMetal;
			float MetalProduction;
			float MetalExpense;
			float EnergyStorageMax;
			float MetalStorageMax;
		};

		void* GetTAMainStructPtr();
		unsigned int GetTAGameState();
		RECT GetGameScreenRect();
		unsigned short GetMouseOverUnit();
		char GetLocalPlayerArrayIndex();
		char GetMouseOverUnitPlayerArrayIndex();
		int GetGameState();

		char* GetPlayerName(int);
		PlayerResources GetPlayerResourcesStruct(int);

		bool GetAlliedState(void*, int);
		void* GetPlayerPtrFromIndex(int);

		bool GetIsLocalPlayerWatcher();
		bool GetIsPlayerIndexExists(int);

		int GetGameScreenWidth();
		int GetGameScreenHeight();

		char GetDesktopGUIRadarObjectColorByIndex(int Index);
		unsigned short GetLOSType();

		unsigned char GetMapSeaLevel();

		int GetScreenWidth();
		int GetScreenHeight();

		short GetMaxScrollX();
		short GetMaxScrollZ();
	}

	namespace Mutators
	{
		void SetIsAlteredUnitLimit(bool);
		void SetMaxUnitLimit(unsigned short);
		void UnitLimitSetter(); // Move some place else
	}

	namespace HexEdits
	{


	}

	namespace Patches
	{
#ifdef OTA_MOD
		void NoCD();
#endif

		void COBExtensionsHandler();
		void DataFile();
		void UnitLimit();
		void Pathfinding();
		void CompositeBuffer();
		void SFXLimit();
		void MixingBuffers();
		void MainWndProc();
		void DrawBuildRectLive();
		void RenderForTAHook();
		void HotKeys();
		void CrashDumps();
		void LineOfSight();

		// MegaMap
		void LoadMap();
		void RenderHooks();
		void DebuggingThreadHook();
	}

	namespace Mods
	{
		namespace Mayhem
		{
			void HexEdits();
		}

		namespace Escalation
		{
			void HexEdits();
		}
	}

	enum GAME_STATE
	{
		IN_GAME = 6
	};

	namespace TAHook
	{
		enum STATE
		{
			OFF,
			ON
		};

		enum PlayerOrderType
		{
			BUILD = 14
		};

		struct BuildLineMessage
		{
			int XPos;
			int YPos;
			int Status;
		};

		bool WriteLine = false;
		bool WriteRing = false;
		short FootPrintX;
		short FootPrintY;
		int MouseStartX;
		int MouseStartY;
		int MouseEndX;
		int MouseEndY;
		short LineMatrixX[1000];
		short LineMatrixY[1000];
		int short MatrixLength;
		unsigned char Direction = 0;
		short BuildSpacing = 0;
		int MouseOverUnit = 0;

		int BuildLineAndBuildRingWndProc(HWND, UINT, WPARAM, LPARAM);
		void ToggleBuildRectangle(bool);
		unsigned short GetMouseMapPosX();
		unsigned short GetMouseMapPosY();
		void SetMouseMapPosX(short PosX);
		void SetMouseMapPosY(short PosY);
		unsigned char GetBuildOrderType();
		short GetBuildUnitId();
		short GetUnitFootPrintX();
		short GetUnitFootPrintY();
		void CalculateBuildLine();
		void CalculateBuildRing();
		void CalculateBuildRing(int, int, int, int);
		void WriteBuildLine();
		void PlaceNewPendingBuilding(int, int);
		void UpdateBuildSpacing();
		void RenderTAHook();
		void ShowBuildLine();
		void SetBuildSpotState(char);
		char GetBuildSpotState();
		void DrawBuildRectangle(int, int, int, int, int);
		unsigned int GetCircleSelectPos1X();
		unsigned int GetCircleSelectPos1Y();
		unsigned int GetCircleSelectPos1Z();
		int GetEyeMapPosX();
		int GetEyeMapPosY();
		int GetScreenWidth();
		int GetScreenHeight();
	}

	namespace HotKeys
	{
		HANDLE IdleConstructionSemaphore;
		HANDLE IdleFactorySemaphore;
		HANDLE UnitWithWeaponsSemaphore;
		HANDLE SameUnitTypeSemaphore;

		int HotKeysWndProc(HWND, UINT, WPARAM, LPARAM);
		void UnselectAllUnits();
		void FindIdleConstruction();
		void FindIdleFactory();
		void SelectUnitWithWeaponsOnScreen();
		void SelectAllOfDoubleClickedUnitOnScreen();
		void SelectUnitEffect();
		void ApplyUnitMenu();
		void ScrollToCenter(short, short);
		short GetMaxScrollX();
		short GetMaxScrollZ();
	}

	namespace AlliedResourceBars
	{
		bool DoRenderResourceBars;

		int XPos;
		int YPos;
	
		Accessors::PlayerResources CurrentPlayerDraw;

		enum RES_TYPE
		{
			METAL,
			ENERGY
		};

		void RenderResBars();
		void RenderBackground(int, int, int, int, int);
		void RenderPlayerName(int, int, int);
		void RenderCurrentStorage(int, int, int, int);
		void RenderMaxStorage(int, int, int, int);
		void RenderCurrentIncome(int, int, int, int);
		void RenderCurrentExpense(int, int, int, int);
		void RenderStorageOutline(int, int, int, int, int, unsigned char);
		void RenderStorageBar(int, int, int, int, int, int);
		void RenderText(int, int, int, int, unsigned char*, std::string, unsigned char);
	}

	namespace Rendering
	{
		unsigned char CustomFont[] = { 0, 0, 255, 255, 255, 255, 0, 0, 0, 255, 255, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255,
			0, 0, 255, 255, 0, 0, 255, 255, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0,
			0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255,
			255, 255, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0,
			0, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255,
			0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
			255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
			255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0,
			0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0,
			0, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255,
			255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0,
			0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0,
			0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0,
			255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0,
			255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0,
			0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0,
			0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 255, 255, 255, 255, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255,
			255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0,
			0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0,
			0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0,
			255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255,
			0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0,
			0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0,
			0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 255, 255, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0,
			0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0,
			255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0,
			0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255,
			255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0,
			0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0,
			0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
			0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0,
			255, 0, 0, 255, 0, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255,
			255, 255, 255, 255, 0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0, 0,
			0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255,
			255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0,
			0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255,
			255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255,
			255, 255, 255, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 0,
			255, 255, 0, 255, 0, 0, 255, 0, 255, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0,
			0, 255, 255, 0, 255, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255,
			255, 255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0,
			0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255,
			0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 255, 255, 255, 255, 0, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

		unsigned char CharacterBuffer8x8[64]; // 8x8

		int ScreenWidth;
		int ScreenHeight;

		int GetScreenWidth();
		int GetScreenHeight();
		void* GetBackBuffer();

		void DrawRectangleFillColor(int DestX, int DestY, int Width, int Height, unsigned char Color);
		void DrawRectanglePixelData(int DestX, int DestY, int Width, int Height, void* PixelData);

		void RenderInGame();
	}

	namespace MegaMap
	{
		struct TNTMapHeader
		{
			int IDVersion;
			int Width;
			int Height;
			WORD* MapDataPtr;
			WORD* MapAttrPtr;
			LPBYTE TileGFXPtr;
			int Tiles;
			int TileAnims;
			int TileAnimPtr;
			int SeaLevel;
			LPBYTE MiniMapPtr;
			int Unknown1;
			int Padding[4];
		};

		int GameScreenWidth;
		int GameScreenHeight;
		LPBYTE MegaMapImage;
		TNTMapHeader TNTMap;
		int MapWidth;
		int MapHeight;
		RECT MegaMapRect;
		RECT MegaMapPosition;
		RECT EmptyRect1;
		RECT EmptyRect2;
		RECT TAMapTAPos;

		// When to update next
		DWORD NextTickCount;

		// Dispensible Live Surface
		LPBYTE MegaMapSurface = 0;
		LPBYTE LastMegaMapSurface = 0;

		// LOS
		LPBYTE LOSMap;



		// UnitsMap
		unsigned char MegaWeaponColor1;
		unsigned char MegaWeaponColor2;
		unsigned char MegaWeaponColor3;

		unsigned char MegaRadarColor;
		unsigned char MegaSonarColor;
		unsigned char MegaRadarJamColor;
		unsigned char MegaSonarJamColor;
		unsigned char MegaAntiNukeColor;

		unsigned char PlayerIconColors[10];
		unsigned char OriginalIconColors[10];

		int IconWidth = 12;
		int IconHeight = 12;

		bool RenderMegaMap = false;

		void LoadMegaMap(TNTMapHeader*);
		void RenderMap();

		void DrawLOSOnMegaMapSurface(/*LPBYTE*/);
		void DrawUnitsOnMegaMapSurface();
		void DrawProjectilesOnMegaMapSurface();

		void MoveToMouseMapPositionOnMegaMap(int, int);

		int MegaMapWndProc(HWND, UINT, WPARAM, LPARAM);
	}

	namespace ChatMacro
	{
		void RunChatMacro();
	}

	namespace Recorder
	{
		const DWORD DP_OK = S_OK;
		const DWORD DPSEND_GUARANTEED = 0x00000001;
		const DWORD DPERR_BUFFERTOOSMALL = 0x88770000 + 30;
		const DWORD DPSYS_DESTROYPLAYERORGROUP = 0x0005;

		struct Packet
		{
			std::string fdata;
			std::string tadata;
			
			void SJCreateNew(std::string data);
			std::string GetTAData();

			std::string Split2(std::string s, bool smartpak);

			std::string Compress(std::string);
			std::string Encrypt(std::string);
			std::string Decompress(std::string);
			std::string Decrypt(std::string);

			void Create(std::string, int);
			std::string GetRawData();
			std::string GetRawData2();
			unsigned int GetSerial();
			void SetSerial(unsigned int);
		};

		struct TDPName
		{
			DWORD dwSize;
			DWORD dwFlags;

			char* lpszShortNameA;
			char* lpszLongNameA;
		};

		//struct TDPSessionDesc2
		//{
		//	DWORD dwSize;
		//	DWORD dwFlags;

		//};

		struct TDPMsg_DestroyPlayerGroup
		{
			DWORD dwType;
			DWORD dwPlayerType;
			DWORD TDPID;
			LPVOID lpLocalData;
			DWORD dwLocalDataSize;
			LPVOID lpRemoteData;
			DWORD dwRemoteDataSize;

			TDPName dpnName;
			DWORD dpIdParent;
			DWORD dwFlags;
		};

		bool imserver;
		bool logpl;

		bool RecorderOff;
		bool dtfound;
		bool DataChanged;
		bool ResSent;
		bool ChatSent;
		bool FakeWatch = false;
		std::vector<std::string> stringbuf;
		int numplayers;
		int lastmsg[10];
		DWORD playerid[10];
		std::string playername[10];
		unsigned char playerside[10];
		unsigned char playercolor[10];
		std::string laststatmess[10];
		std::string playerip[10];
		DWORD sentpings[100];
		int servernumber;
		const char* mapname;
		WORD maxunits;
		bool isSelf;

		bool cantake[10];
		//chatview[10]; // allies
		int lastmsg[10];
		DWORD lastpacket[10];
		bool votedgo[10];
		bool clickedin[10];
		bool enemychat[10];
		bool recConnect[10];
		int internver[10];
		bool haswarned[10];

		int tastatus;
		
		const DWORD SY_UNIT = 0xEBC53551;

		HRESULT DPLAYX_Send(DWORD idFrom, DWORD idTo, DWORD dwFlags, LPVOID lpData, DWORD dwDataSize);
		HRESULT DPLAYX_Receive(LPDWORD idFrom, LPDWORD idTo, DWORD dwFlags, LPVOID lpData, LPDWORD dwDataSize);
		HRESULT DPLAYX_GetPlayerName(DWORD idPlayer, void* lpData, DWORD dwDataSize);
		HRESULT DPLAYX_Close(/* DWORD playerIdGroup, DWORD playerId */);
		HRESULT DPLAYX_Open(LPVOID lpsd, DWORD dwFlags); // lpvoid to avoid GUID definitions ;)
		void ResetRecorder();
		void SendLocal(std::string message, DWORD idTo, bool local, bool remote);
		std::string PacketHandler(std::string packetData, DWORD idFrom, DWORD idTo);
		// encrypt
		// compress
		// decrypt
		// decompress
		void HandleUnitData(std::string s, DWORD idFrom, DWORD idTo);
		void PacketLossHandler(DWORD i, DWORD idFrom);
		void HandleChatMessage(std::string chatMessage, DWORD idFrom);
		std::string SmartPak(std::string packetData, DWORD idFrom);
		std::string UnSmartPak(std::string packetData);
		int GetCRC(); // Unused?
		void ProcessCRC(std::string data);
		void CreateLogFile();
		
		std::string PtrToStr(void* pointer, int length);
		int GetGoodSource();
		unsigned char ConvertId(DWORD id);
		bool IsServer(DWORD id);
	}

	LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
}

/*
---------------------------------------------------------------------------------

	ta c++ function definitions

---------------------------------------------------------------------------------
*/

int Valkyrie::TotalA::COB::ASM_Functions::CustomGetters(int Index, void* UnitPtr, int Arg1, int Arg2, int Arg3, int Arg4)
{
	void* PlayerPtr;
	void* Unit2Ptr;
	int PlayerIndex;
	int PlayerType;

	int Result;

	Result = 0;

	if (Index >= Constants::CUSTOM_LOW && Index <= Constants::CUSTOM_HIGH)
	{
		switch (Index)
		{
		case Constants::VETERAN_LEVEL:
			Result = Unit::GetKills(UnitPtr) * 100;
			break;
		case Constants::MIN_ID:
			Result = 1;
			break;
		case Constants::MAX_ID:
			if (Data::GetIsAlteredUnitLimit())
			{
				Result = Data::GetActualUnitLimit() * Valkyrie::TotalA::MAX_PLAYER_COUNT;
			}
			else
			{
				Result = Data::GetMaxUnitLimit() * Valkyrie::TotalA::MAX_PLAYER_COUNT;
			}
			break;
		case Constants::MY_ID:
			Result = (((unsigned int)UnitPtr - (unsigned int)Data::GetUnitsPtr()) / 0x118);
			break;
		case Constants::UNIT_TEAM:
			Unit2Ptr = Memory::GetUnitPtr(Arg1);
			Result = Unit::GetOwnerIndex(Unit2Ptr);
			break;
		case Constants::UNIT_BUILD_PERCENT_LEFT:
			if (Arg1 != 0)
			{
				Unit2Ptr = Memory::GetUnitPtr(Arg1);
				Result = Unit::GetBuildPercentLeft(Unit2Ptr);
			}
			else
			{
				Result = Unit::GetBuildPercentLeft(UnitPtr);
			}
			break;
		case Constants::UNIT_ALLIED:
			PlayerPtr = Unit::GetOwnerPtr(UnitPtr);
			Unit2Ptr = Memory::GetUnitPtr(Arg1);
			PlayerIndex = Unit::GetOwnerIndex(Unit2Ptr);
			Result = Player::GetAlliedState(PlayerPtr, PlayerIndex);
			break;
		case Constants::UNIT_IS_ON_THIS_COMP:
			Unit2Ptr = Memory::GetUnitPtr(Arg1);
			PlayerPtr = Unit::GetOwnerPtr(Unit2Ptr);
			PlayerType = Player::GetPlayerType(PlayerPtr);
			if (PlayerType == 1 || PlayerType == 2)
			{
				Result = 1;
			}
			break;
		case Constants::UNIT_CLOAKED:
			if (Arg1 != 0)
			{
				Unit2Ptr = Memory::GetUnitPtr(Arg1);
				Result = Unit::GetCloaked(Unit2Ptr);
			}
			else
			{
				Result = Unit::GetCloaked(UnitPtr);
			}
			break;
		}
	}

	return Result;
}

void Valkyrie::TotalA::COB::ASM_Functions::CustomSetters(int Index, void* UnitPtr, int Arg1)
{
	if (Index >= Constants::CUSTOM_LOW && Index <= Constants::CUSTOM_HIGH)
	{
		switch (Index)
		{
		case Constants::UNIT_CLOAKED:
			Unit::SetCloaked(UnitPtr, Arg1);
			break;
		}
	}
}


bool Valkyrie::TotalA::COB::Data::GetIsAlteredUnitLimit()
{
	bool IsAltered;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov al, [eax + 0x589]
		mov [IsAltered], al
	}

	return IsAltered;
}

unsigned short Valkyrie::TotalA::COB::Data::GetActualUnitLimit()
{
	unsigned short ActualUnitLimit;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov ax, [eax + 0x37EEA]
		mov ActualUnitLimit, ax
	}

	return ActualUnitLimit;
}

unsigned short Valkyrie::TotalA::COB::Data::GetMaxUnitLimit()
{
	unsigned short MaxUnitLimit;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov ax, [eax + 0x37EEC]
		mov MaxUnitLimit, ax
	}

	return MaxUnitLimit;
}

void* Valkyrie::TotalA::COB::Data::GetUnitsPtr()
{
	void* UnitsPtr;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov eax, [eax + 0x14357]
		mov UnitsPtr, eax
	}

	return UnitsPtr;
}

unsigned char Valkyrie::TotalA::COB::Unit::GetOwnerIndex(void* UnitPtr)
{
	unsigned char OwnerIndex;

	__asm
	{
		mov eax, UnitPtr
		mov al, [eax + 0xFF]
		mov OwnerIndex, al
	}

	return OwnerIndex;
}

void* Valkyrie::TotalA::COB::Unit::GetOwnerPtr(void* UnitPtr)
{
	unsigned int* OwnerPtr;

	__asm
	{
		mov eax, UnitPtr
		mov eax, [eax + 0x96]
		mov OwnerPtr, eax
	}

	return OwnerPtr;
}

unsigned short Valkyrie::TotalA::COB::Unit::GetKills(void* UnitPtr)
{
	unsigned short UnitKills;

	__asm
	{
		mov eax, UnitPtr
		mov ax, [eax + 0xB8]
		mov UnitKills, ax
	}

	return UnitKills;
}

int Valkyrie::TotalA::COB::Unit::GetBuildPercentLeft(void* UnitPtr)
{
	float BuildTimeLeft;
	int Result;

	__asm
	{
		mov eax, UnitPtr
		mov eax, [eax + 0x104]
		mov BuildTimeLeft, eax
	}

	if (BuildTimeLeft == 0.0F)
	{
		Result = 0;
	}
	else
	{
		Result = int(1 - (BuildTimeLeft * -99.0F));
	}

	return Result;
}

void Valkyrie::TotalA::COB::Unit::SetCloaked(void* UnitPtr, bool State)
{
	if (State == 1)
	{
		__asm
		{
			mov eax, UnitPtr
			mov edx, [eax + 0x110] // Unit State
			or edx, 0x800 // Set Cloaked
			mov [eax + 0x110], edx // Unit State
		}
	}
	else
	{
		__asm
		{
			mov eax, UnitPtr
			mov edx, [eax + 0x110] // Unit State
			mov ecx, 1
			shl ecx, 11
			not ecx
			and edx, ecx // Clear Cloaked
			mov [eax + 0x110], edx // Unit State
		}
	}
}

int Valkyrie::TotalA::COB::Unit::GetCloaked(void* UnitPtr)
{
	unsigned short Bitfield;
	int Result;

	// 0x10E
	__asm
	{
		mov eax, UnitPtr
		mov dx, [eax + 0x10E]
		mov Bitfield, dx
	}

	if ((Bitfield & 0x4) == 0x4)
	{
		Result = 1;
	}
	else
	{
		Result = 0;
	}

	return Result;
}

bool Valkyrie::TotalA::COB::Player::GetAlliedState(void* Player1Ptr, int Player2Index)
{
	bool IsAllied;

	if (Player1Ptr == 0 || Player2Index >= MAX_PLAYER_COUNT)
	{
		return false;
	}

	__asm
	{
		mov eax, Player1Ptr
		add eax, 0x108
		add eax, Player2Index
		mov al, [eax]
		mov IsAllied, al
	}

	return IsAllied;
}

unsigned char Valkyrie::TotalA::COB::Player::GetPlayerType(void* PlayerPtr)
{
	unsigned char PlayerType;

	__asm
	{
		mov eax, PlayerPtr
		mov al, [eax + 0x73]
		mov PlayerType, al
	}

	return PlayerType;
}

void* Valkyrie::TotalA::COB::Memory::GetUnitPtr(int UnitIndex)
{
	void* UnitPtr;

	if (UnitIndex > (int)COB::Data::GetMaxUnitLimit() * MAX_PLAYER_COUNT)
	{
		return 0;
	}

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov eax, [eax + 0x14357]
		mov ecx, eax
		mov eax, 0x118
		mov edx, UnitIndex
		mul edx
		add ecx, eax
		mov UnitPtr, ecx
	}

	return UnitPtr;
}


unsigned int Valkyrie::Accessors::GetTAGameState()
{
	__asm
	{
		mov eax, ds: [0x511de8]
		mov eax, [eax + 0x391f1]
	}
}

RECT Valkyrie::Accessors::GetGameScreenRect()
{
	RECT Result;
	int Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27]
		mov Temp, eax
	}

	Result.left = Temp;

	__asm
	{
		mov eax, dword ptr ds : [0x511DE8]
		mov eax, [eax + 0x37E27 + 4]
		mov Temp, eax
	}

	Result.top = Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27 + 8]
		mov Temp, eax
	}

	Result.right = Temp;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x37E27 + 12]
		mov Temp, eax
	}

	Result.bottom = Temp;

	return Result;
}

unsigned short Valkyrie::Accessors::GetMouseOverUnit()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov dx, [eax + 0x2CBA]
		xor eax, eax
		mov ax, dx
	}
}

char Valkyrie::Accessors::GetLocalPlayerArrayIndex()
{
	char LocalHumanPlayerId;
	void* PlayersArrayStart;
	char LocalPlayerArrayIndex;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov al, [eax + 0x2A42]
		mov LocalHumanPlayerId, al

		mov eax, dword ptr ds:[0x511DE8]
		lea eax, [eax + 0x1B63]
		mov PlayersArrayStart, eax

		xor eax, eax
		mov eax, 0x14B
		xor edx, edx
		mov dl, LocalHumanPlayerId
		mul edx
		mov edx, PlayersArrayStart
		add eax, edx
		mov al, [eax + 0x146]
		mov LocalPlayerArrayIndex, al
	}

	return LocalPlayerArrayIndex;
}

char Valkyrie::Accessors::GetMouseOverUnitPlayerArrayIndex()
{
	void* BeginInGameUnitsArray;
	unsigned short MouseOverUnit;
	char UnitPlayerArrayIndex;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x14357]
		mov BeginInGameUnitsArray, eax

		mov eax, dword ptr ds:[0x511DE8]
		mov ax, [eax + 0x2CBA]
		mov MouseOverUnit, ax

		xor eax, eax
		xor edx, edx
		mov eax, 0x118
		mov dx, MouseOverUnit
		mul edx
		mov edx, BeginInGameUnitsArray
		add eax, edx
		mov eax, [eax + 0x96]
		mov al, [eax + 0x146]
		mov UnitPlayerArrayIndex, al
	}

	return UnitPlayerArrayIndex;
}

int Valkyrie::Accessors::GetGameState()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x391F1]
	}
}

char* Valkyrie::Accessors::GetPlayerName(int Index)
{
	char* NamePtr = 0;

	if (Index >= 0 && Index < 10)
	{
		__asm
		{
			mov esi, dword ptr ds:[0x511DE8]
			lea esi, [esi + 0x1B63]
			mov eax, 0x14B
			mov edx, Index
			mul edx
			add esi, eax
			add esi, 0x2B
			mov NamePtr, esi
		}
	}

	return NamePtr;
}

Valkyrie::Accessors::PlayerResources Valkyrie::Accessors::GetPlayerResourcesStruct(int Index)
{
	PlayerResources Structure = PlayerResources();

	float CurrentEnergy;
	float EnergyProduction;
	float EnergyExpense;
	float CurrentMetal;
	float MetalProduction;
	float MetalExpense;
	float EnergyStorageMax;
	float MetalStorageMax;

	if (Index >= 0 && Index < 10)
	{
		__asm
		{
			mov esi, dword ptr ds:[0x511DE8]
			lea esi, [esi + 0x1B63]
			mov eax, 0x14B
			mov edx, Index
			mul edx
			add esi, eax
			add esi, 0x8C

			mov eax, [esi]
			mov CurrentEnergy, eax

			mov eax, [esi+4]
			mov EnergyProduction, eax

			mov eax, [esi+8]
			mov EnergyExpense, eax

			mov eax, [esi+12]
			mov CurrentMetal, eax

			mov eax, [esi+16]
			mov MetalProduction, eax

			mov eax, [esi+20]
			mov MetalExpense, eax

			mov eax, [esi+24]
			mov EnergyStorageMax, eax

			mov eax, [esi+28]
			mov MetalStorageMax, eax
		}

		Structure.CurrentEnergy = CurrentEnergy;
		Structure.EnergyProduction = EnergyProduction;
		Structure.EnergyExpense = EnergyExpense;
		Structure.CurrentMetal = CurrentMetal;
		Structure.MetalProduction = MetalProduction;
		Structure.MetalExpense = MetalExpense;
		Structure.EnergyStorageMax = EnergyStorageMax;
		Structure.MetalStorageMax = MetalStorageMax;
	}

	return Structure;
}

bool Valkyrie::Accessors::GetAlliedState(void* Player1Ptr, int Player2Index)
{
	bool IsAllied;

	if (Player1Ptr == 0 || Player2Index >= Valkyrie::Accessors::MAX_PLAYER_COUNT)
	{
		return false;
	}

	__asm
	{
		mov eax, Player1Ptr
		add eax, 0x108
		add eax, Player2Index
		mov al, [eax]
		mov IsAllied, al
	}

	return IsAllied;
}

void* Valkyrie::Accessors::GetPlayerPtrFromIndex(int Index)
{
	void* PlayerPtr;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1B63
		mov eax, 0x14B
		mov edx, Index
		mul edx
		add esi, eax
		mov PlayerPtr, esi
	}

	return PlayerPtr;
}

bool Valkyrie::Accessors::GetIsLocalPlayerWatcher()
{
	char LocalPlayerIndex = GetLocalPlayerArrayIndex();
	char PlayerPropertyMask;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1B63
		xor eax, eax
		mov al, LocalPlayerIndex
		mov edx, 0x14B
		mul edx
		add esi, eax
		mov edi, [esi + 0x27]
		xor eax, eax
		mov al, [edi + 0x9B]
		mov PlayerPropertyMask, al
	}

	if ((PlayerPropertyMask & 0x40) > 0)
	{
		return true;
	}

	return false;
}

bool Valkyrie::Accessors::GetIsPlayerIndexExists(int Index)
{
	unsigned int IndexExists;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1B63
		mov eax, Index
		mov edx, 0x14B
		mul edx
		add esi, eax
		mov eax, [esi]
		mov IndexExists, eax
	}

	if (IndexExists > 0)
	{
		return true;
	}

	return false;
}

int Valkyrie::Accessors::GetGameScreenWidth()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov eax, [esi + 0x37E37]
	}
}

int Valkyrie::Accessors::GetGameScreenHeight()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov eax, [esi + 0x37E3B]
	}
}

char Valkyrie::Accessors::GetDesktopGUIRadarObjectColorByIndex(int Index)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x519
		add esi, 0x8B2
		add esi, Index
		xor eax, eax
		mov al, [esi]
	}
}

unsigned short Valkyrie::Accessors::GetLOSType()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		xor eax, eax
		mov ax, [esi + 14281]
	}
}

unsigned char Valkyrie::Accessors::GetMapSeaLevel()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x141FB
		add esi, 0x84
		xor eax, eax
		mov al, [esi]
	}
}

int Valkyrie::Accessors::GetScreenWidth()
{
	__asm
	{
		mov esi, dword ptr ds:[0x51FBD0]
		mov eax, [esi + 0xD4]
	}
}

int Valkyrie::Accessors::GetScreenHeight()
{
	__asm
	{
		mov esi, dword ptr ds:[0x51FBD0]
		mov eax, [esi + 0xD8]
	}
}

short Valkyrie::Accessors::GetMaxScrollX()
{
	int* TAMemPtr;
	int ScreenWidth;
	int* MapSizeX;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov TAMemPtr, eax

		mov eax, dword ptr ds:[0x51fbd0]
		mov eax, [eax + 0xD4]
		mov ScreenWidth, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422b]
		mov MapSizeX, eax
	}

	return *MapSizeX - (ScreenWidth - 128);
}

short Valkyrie::Accessors::GetMaxScrollZ()
{
	int* TAMemPtr;
	int ScreenHeight;
	int* MapSizeZ;

	__asm
	{
		mov eax, ds:[0x511de8]
		mov TAMemPtr, eax

		mov eax, ds:[0x51fbd0]
		mov eax, [eax + 0xD8]
		mov ScreenHeight, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422f]
		mov MapSizeZ, eax
	}

	return *MapSizeZ - (ScreenHeight - 64);
}

/*
---------------------------------------------------------------------------------

	assembly function definitions

---------------------------------------------------------------------------------
*/

__declspec(naked) void COBExtensionHandlerGetterFunc()
{
	__asm
	{
		mov eax, [ecx + 0x540]
		mov ecx, [esp + 0x04]
		sub esp, 0x24
		push esi
		test eax, eax
		jz DoZeroReturn
		mov esi, [eax + 0x0C]
		lea eax, [ecx - 0x01]
		cmp eax, 0x13
		ja Default
		jmp dword ptr ds:0x00480AC4[eax * 4]

		Default:
		inc eax // bring proper instruction index back
		mov ecx, [esp + 0x28 + 0x14]
		push ecx
		mov ecx, [esp + 0x2C + 0x10]
		push ecx
		mov ecx, [esp + 0x30 + 0x0C]
		push ecx
		mov ecx, [esp + 0x34 + 0x08]
		push ecx
		push esi
		push eax
		call Valkyrie::TotalA::COB::ASM_Functions::CustomGetters
		add esp, 0x18

		//DoReturn:
		pop esi
		add esp, 0x24
		ret 0x14

		DoZeroReturn:
		xor eax, eax
		pop esi
		add esp, 0x24
		ret 0x14
	}
}

__declspec(naked) void COBExtensionHandlerSetterFunc()
{
	__asm
	{
		mov eax, [ecx + 0x540]
		mov ecx, [esp + 0x04]
		push esi
		test eax, eax
		jz DoZeroReturn
		mov esi, [eax + 0x0C]
		lea eax, [ecx - 0x01]
		cmp eax, 0x13
		ja Default
		xor edx, edx
		mov dl, ds:0x480C18[eax]
		jmp dword ptr ds:0x00480BFC[edx * 4]

		Default:
		inc eax
		mov ecx, [esp + 0x04 + 0x08] // "set" value
		push ecx
		push esi
		push eax
		call Valkyrie::TotalA::COB::ASM_Functions::CustomSetters
		add esp, 0x0C

		//DoReturn:
		pop esi
		ret 0x8

		DoZeroReturn:
		xor eax, eax
		pop esi
		ret 0x8
	}
}

__declspec(naked) void DataFilePatchFunc()
{
	__asm
	{
		lea ecx, [esp + 0x10]
		lea edx, [Valkyrie::Variables::NewDataFileName]
		push 1
		push 0xFFFFFFFF
		push ecx
		push edx
		mov dword ptr [Valkyrie::Temporary_Data::Temp1], 0x004BC4B0
		call [Valkyrie::Temporary_Data::Temp1]
		mov esi, eax
		test esi, esi
		jl ReturnJump

		FindHPI:
		lea eax, [Valkyrie::Variables::NewDataFileName]
		push 1
		push eax
		mov dword ptr [Valkyrie::Temporary_Data::Temp1], 0x004BE0B0
		call [Valkyrie::Temporary_Data::Temp1]
		lea ecx, [esp + 0x10]
		push ecx
		push esi
		mov dword ptr [Valkyrie::Temporary_Data::Temp1], 0x004BC640
		call [Valkyrie::Temporary_Data::Temp1]
		test eax, eax
		jz FindHPI
		push esi
		mov dword ptr [Valkyrie::Temporary_Data::Temp1], 0x004BC8D0
		call [Valkyrie::Temporary_Data::Temp1]

		ReturnJump:
		
		mov eax, 0x005028D8
		push eax // "31"
		jmp [Valkyrie::Variables::DataFile.Hook_Return_Destination]
	}
}

void Valkyrie::Mutators::UnitLimitSetter()
{
	unsigned short NewMaxUnitLimit;

	Valkyrie::Mutators::SetIsAlteredUnitLimit(true);

	NewMaxUnitLimit = Valkyrie::Config::MaxUnitLimit;

	if (NewMaxUnitLimit <= 3276)
	{
		if (NewMaxUnitLimit < 20)
		{
			NewMaxUnitLimit = 20;
		}
	}
	else
	{
		NewMaxUnitLimit = 3276;
	}

	Valkyrie::Mutators::SetMaxUnitLimit(NewMaxUnitLimit);
}

__declspec(naked) void UnitLimitFunc()
{
	__asm
	{
		call Valkyrie::Mutators::UnitLimitSetter

		pop edi
		pop esi
		pop ebx
		add esp, 0x24
		retn
	}
}

__declspec(naked) void MixingBuffersFunc()
{
	__asm
	{
		mov eax, Valkyrie::Config::MixingBuffers
		mov [ecx + 0x2C], eax

		jmp [Valkyrie::Variables::MixingBuffers.Hook_Return_Destination]
	}
}

__declspec(naked) void WndProcFunc()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp8], eax
		mov [Valkyrie::Temporary_Data::Temp9], edx
		mov [Valkyrie::Temporary_Data::Temp10], ecx
		mov [Valkyrie::Temporary_Data::Temp11], ebx
		mov [Valkyrie::Temporary_Data::Temp12], esi
		mov [Valkyrie::Temporary_Data::Temp13], edi
		mov [Valkyrie::Temporary_Data::Temp14], ebp

		mov eax, [esp + 0x10]
		push eax
		mov eax, [esp + 0xC + 4]
		push eax
		mov eax, [esp + 0x8 + 8]
		push eax
		mov eax, [esp + 0x4 + 12]
		push eax

		call Valkyrie::WndProc

		cmp eax, 0
		
		mov eax, [Valkyrie::Temporary_Data::Temp8]
		mov edx, [Valkyrie::Temporary_Data::Temp9]
		mov ecx, [Valkyrie::Temporary_Data::Temp10]
		mov ebx, [Valkyrie::Temporary_Data::Temp11]
		mov esi, [Valkyrie::Temporary_Data::Temp12]
		mov edi, [Valkyrie::Temporary_Data::Temp13]
		mov ebp, [Valkyrie::Temporary_Data::Temp14]

		jne DoReturn

		sub esp, 0x18
		push esi
		mov esi, [esp + 0x24]

		jmp [Valkyrie::Variables::MainWndProc.Hook_Return_Destination]

		DoReturn:
		ret 0x10
	}
}

__declspec(naked) void FinalRenderFunc()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp1], eax
		mov [Valkyrie::Temporary_Data::Temp2], edx
		mov [Valkyrie::Temporary_Data::Temp3], ecx
		mov [Valkyrie::Temporary_Data::Temp4], ebx
		mov [Valkyrie::Temporary_Data::Temp5], esi
		mov [Valkyrie::Temporary_Data::Temp6], edi
		mov [Valkyrie::Temporary_Data::Temp7], ebp

		call Valkyrie::Rendering::RenderInGame
#ifdef DEBUG_BUILD
		call Valkyrie::Debugging::ThreadReportData
#endif
		mov eax, [Valkyrie::Temporary_Data::Temp1]
		mov edx, [Valkyrie::Temporary_Data::Temp2]
		mov ecx, [Valkyrie::Temporary_Data::Temp3]
		mov ebx, [Valkyrie::Temporary_Data::Temp4]
		mov esi, [Valkyrie::Temporary_Data::Temp5]
		mov edi, [Valkyrie::Temporary_Data::Temp6]
		mov ebp, [Valkyrie::Temporary_Data::Temp7]

		sub esp, 0xF4
		jmp [Valkyrie::Variables::RenderForTAHook.Hook_Return_Destination]
	}
}

__declspec(naked) void CrashDumpExceptionFunc1()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp1], esp
		lea esp, [Valkyrie::Temporary_Data::TempErrorReportingStack]
		add esp, 0x400000 // may have to subtract one dword
		// no pop's allowed, push's only

		// we're ideally on the new stack now, can do whatever
		cmp Valkyrie::Debugging::CrashDumpWritten, 1
		jz Done
		call Valkyrie::Debugging::CreateMemoryDump
		mov Valkyrie::Debugging::CrashDumpWritten, 1
		Done:

		// leave new stack, return to old stack and continue producing normal ErrorLog.txt entry
		mov esp, [Valkyrie::Temporary_Data::Temp1]
		mov ecx, 0x005097FC
		push ecx
		jmp [Valkyrie::Variables::CrashDumps1.Hook_Return_Destination]
	}
}

__declspec(naked) void CrashDumpExceptionFunc2()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp1], esp
		lea esp, [Valkyrie::Temporary_Data::TempErrorReportingStack]
		add esp, 0x400000 // may have to subtract one dword
		// no pop's allowed, push's only

		// we're ideally on the new stack now, can do whatever
		cmp Valkyrie::Debugging::CrashDumpWritten, 1
		jz Done
		call Valkyrie::Debugging::CreateMemoryDump
		mov Valkyrie::Debugging::CrashDumpWritten, 1
		Done:

		// leave new stack, return to old stack and continue producing normal ErrorLog.txt entry
		mov esp, [Valkyrie::Temporary_Data::Temp1]
		mov eax, 0x0050D2D0
		push eax
		mov eax, [esp + 0x04 + 4]
		jmp [Valkyrie::Variables::CrashDumps2.Hook_Return_Destination]
	}
}

__declspec(naked) void CrashDumpExceptionFunc3()
{
	__asm
	{
		mov[Valkyrie::Temporary_Data::Temp1], esp
		lea esp, [Valkyrie::Temporary_Data::TempErrorReportingStack]
		add esp, 0x400000 // may have to subtract one dword
		// no pop's allowed, push's only

		// we're ideally on the new stack now, can do whatever
		cmp Valkyrie::Debugging::CrashDumpWritten, 1
		jz Done
		call Valkyrie::Debugging::CreateMemoryDump
		mov Valkyrie::Debugging::CrashDumpWritten, 1
		Done:

		// leave new stack, return to old stack and continue producing normal ErrorLog.txt entry
		mov esp, [Valkyrie::Temporary_Data::Temp1]
		mov eax, 0x0050C8B4
		push eax
		jmp [Valkyrie::Variables::CrashDumps3.Hook_Return_Destination]
	}
}

__declspec(naked) void CrashDumpExceptionFunc4()
{
	__asm
	{
		mov[Valkyrie::Temporary_Data::Temp1], esp
		lea esp, [Valkyrie::Temporary_Data::TempErrorReportingStack]
		add esp, 0x400000 // may have to subtract one dword
		// no pop's allowed, push's only

		// we're ideally on the new stack now, can do whatever
		cmp Valkyrie::Debugging::CrashDumpWritten, 1
		jz Done
		call Valkyrie::Debugging::CreateMemoryDump
		mov Valkyrie::Debugging::CrashDumpWritten, 1
		Done:

		// leave new stack, return to old stack and continue producing normal ErrorLog.txt entry
		mov esp, [Valkyrie::Temporary_Data::Temp1]
		mov eax, [ebp + 0x08]
		push eax
		mov ecx, [ebp -  0x14]
		jmp [Valkyrie::Variables::CrashDumps4.Hook_Return_Destination]
	}
}

__declspec(naked) void LOSCommandViewFunc()
{
	__asm
	{
		mov ecx, dword ptr ds:[0x511DE8]
		mov [ecx + 0x2A43], al
		xor ecx, ecx
		mov cl, al
		mov Valkyrie::TotalA::LOS::Variables::ViewPlayer, ecx
		mov Valkyrie::TotalA::LOS::Variables::AlliedStateChanged, 1
		mov dword ptr [Valkyrie::Temporary_Data::Temp1], 0x00416BC7
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LOSRadarCanDirectlySeeUnit()
{
	__asm
	{
		mov ecx, [eax]
		test ecx, 0x10000000
		jz SkipUnit
		
		mov esi, ecx
		xor ecx, ecx
		mov cl, [eax - 0x11]
		and esi, 0xFFFFEFFF
		mov [eax], esi

		mov ecx, [eax - 0x7A]
		xor ebx, ebx
		mov bl, [ebp + 0x146]
		cmp byte ptr [ebx + ecx + 0x108], 0
		jnz CanSeeUnitOnRadar

		cmp dword ptr [ebp + 0], 0
		jz CanNotSeeUnitOnRadar
		mov ecx, [ebp + 0x27]
		test [ecx + 0x9B], 0x40
		jnz CanSeeUnitOnRadar

		CanNotSeeUnitOnRadar:
		mov ecx, [eax]
		and ch, 0xF8
		jmp SetRadarVisibleState

		CanSeeUnitOnRadar:
		mov ecx, [eax]
		or ch, 0x03

		SetRadarVisibleState:
		mov [eax], ecx

		SkipUnit:
		mov [Valkyrie::Temporary_Data::Temp1], 0x004674FB
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LOSRadarLoopCondition()
{
	__asm
	{
		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayerIndex
		mov eax, Valkyrie::TotalA::LOS::Variables::TestPlayerPtr
		mov esi, Valkyrie::TotalA::LOS::Variables::ViewPlayer
		jmp TryNextPlayer_Condition

		TryNextPlayer_NextValue:
		inc ecx
		add eax, 0x14B

		TryNextPlayer_Condition:
		cmp ecx, 10
		jnb CleanupAndExit
		cmp byte ptr [eax + esi + 0x108], 0
		jz TryNextPlayer_NextValue

		mov esi, dword ptr ds:[0x511DE8]
		mov [esi + 0x2A43], cl

		inc ecx
		mov Valkyrie::TotalA::LOS::Variables::TestPlayerIndex, ecx
		add eax, 0x14B
		mov Valkyrie::TotalA::LOS::Variables::TestPlayerPtr, eax
		
		mov dl, [esi + 0x2A43]
		mov edi, [esi + 0x14357]
		mov eax, edx
		mov ebx, [esi + 0x1435B]
		and eax, 0xFF
		add edi, 0x118
		mov ecx, eax
		add esi, eax
		shl ecx, 5
		add ecx, eax
		//cmp edi, ebx
		mov [esp + 0x14], edi
		mov [esp + 0x10], ebx
		lea ecx, [ecx + ecx * 4]
		lea ebp, [esi + ecx * 2 + 0x1B63]

		mov esi, [ebp + 0x67]
		mov eax, [ebp + 0x6B]
		cmp esi, eax
		ja SkipTest

		mov Valkyrie::Temporary_Data::Temp1, 0x0046751C
		jmp [Valkyrie::Temporary_Data::Temp1]

		SkipTest:
		mov Valkyrie::Temporary_Data::Temp1, 0x004675D2
		jmp [Valkyrie::Temporary_Data::Temp1]

		CleanupAndExit:
		mov ecx, Valkyrie::TotalA::LOS::Variables::ViewPlayer
		mov esi, dword ptr ds:[0x511DE8]
		mov [esi + 0x2A43], cl
		xor eax, eax
		pop edi
		pop esi
		pop ebp
		pop ebx
		add esp, 0x28
		ret
	}
}

__declspec(naked) void LOSRadarLoopStart()
{
	__asm
	{
		mov esi, [ebp + 0x67]
		mov eax, [ebp + 0x6B]
		cmp esi, eax
		ja ReturnToTA
		jmp Looplabel

		ReturnToTA:
		mov [Valkyrie::Temporary_Data::Temp1], 0x004675D2
		jmp [Valkyrie::Temporary_Data::Temp1]

		LoopLabel:
		xor ecx, ecx
		mov Valkyrie::TotalA::LOS::Variables::TestPlayerIndex, ecx
		
		mov esi, dword ptr ds:[0x511DE8]
		mov cl, [esi + 0x2A43]
		mov Valkyrie::TotalA::LOS::Variables::ViewPlayer, ecx

		mov eax, esi
		add eax, 0x1B63
		mov Valkyrie::TotalA::LOS::Variables::TestPlayerPtr, eax

		add esi, 0x1B63
		mov eax, 0x14B
		mul ecx
		add esi, eax
		mov Valkyrie::TotalA::LOS::Variables::PlayerPtr, esi

		jmp LOSRadarLoopCondition
	}
}

__declspec(naked) void LOSMiniMapUnitsProjectilesIsOwner()
{
	__asm
	{
		xor eax, eax
		mov al, [esi + 0x2A43]
		mov edx, [ebx + 0x96]
		cmp byte ptr [eax + edx + 0x108], 0
		jnz IsOwnerAlly

		mov Valkyrie::Temporary_Data::Temp1, 0x0046718C
		jmp [Valkyrie::Temporary_Data::Temp1]

		IsOwnerAlly:
		mov Valkyrie::Temporary_Data::Temp1, 0x00466E83
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LOSPlayerSeeUnitIsOwnerAllowedToSee()
{
	__asm
	{
		push edi
		xor ecx, ecx
		mov Valkyrie::TotalA::LOS::Variables::UnitPtr, ebx
		mov Valkyrie::TotalA::LOS::Variables::PlayerPtr, esi
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx

		mov eax, dword ptr ds:[0x511DE8]
		mov cl, [eax + 0x2A43]
		mov Valkyrie::TotalA::LOS::Variables::ViewPlayer, ecx

		xor eax, eax
		mov al, [esi + 0x146]
		mov ecx, [ebx + 0x96]
		cmp byte ptr [eax + ecx + 0x108], 0
		jnz CanSeeUnit

		mov Valkyrie::Temporary_Data::Temp1, 0x00465AE8
		jmp [Valkyrie::Temporary_Data::Temp1]

		CanSeeUnit:
		mov eax, 1
		pop edi
		pop esi
		pop ebp
		pop ebx
		add esp, 0x0C
		ret 0x08
	}
}

__declspec(naked) void LOSGUITextUnitResources()
{
	__asm
	{
		mov word ptr [esp + 0x5A], 0
		mov edx, dword ptr ds:[0x511DE8]
		xor eax, eax
		xor ecx, ecx

		mov al, [edx + 0x2A43]
		mov ecx, [esi + 0x96]
		cmp byte ptr [eax + ecx + 0x108], 0
		jnz CanSeeUnit

		//CanNotSeeUnit:
		mov Valkyrie::Temporary_Data::Temp1, 0x0046ACC8
		jmp [Valkyrie::Temporary_Data::Temp1]

		CanSeeUnit:
		mov Valkyrie::Temporary_Data::Temp1, 0x0046ACA0
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LOSGUITextSeeCommHealth()
{
	__asm
	{
		mov esi, [esp + 0x24]
		mov eax, dword ptr ds:[0x511DE8]
		xor edx, edx
		//xor ecx, ecx

		mov dl, [eax + 0x2A43]
		mov ecx, [esi + 0x96]
		cmp byte ptr [edx + ecx + 0x108], 0
		jnz CanSeeUnit

		//CanNotSeeUnit:
		mov Valkyrie::Temporary_Data::Temp1, 0x0046B033
		jmp [Valkyrie::Temporary_Data::Temp1]

		CanSeeUnit:
		mov Valkyrie::Temporary_Data::Temp1, 0x0046B048
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LOSGUITextUnitMisc()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		xor edx, edx

		mov dl, [eax + 0x2A43]
		mov ecx, [esi + 0x96]
		cmp byte ptr [edx + ecx + 0x108], 0
		jnz CanSeeUnit

		//CanNotSeeUnit:
		mov Valkyrie::Temporary_Data::Temp1, 0x0046B121
		jmp [Valkyrie::Temporary_Data::Temp1]

		CanSeeUnit:
		mov Valkyrie::Temporary_Data::Temp1, 0x0046B12E
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LOSUpdate1Retry()
{
	__asm
	{
		mov eax, Valkyrie::TotalA::LOS::Variables::PlayerPtr
		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayer

		jmp TryNextPlayerCondition
		
		TryNextPlayerNextValue:
		inc ecx

		TryNextPlayerCondition:
		cmp ecx, 0x0A
		jnb NoMoreAllies
		cmp byte ptr [eax + ecx + 0x108], 0
		jz TryNextPlayerNextValue
		cmp byte ptr [eax + 0x146], cl
		jz TryNextPlayerNextValue

		mov eax, ecx
		inc ecx
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx

		mov ecx, 0x14B
		mul ecx
		mov ecx, dword ptr ds:[0x511DE8]
		lea ecx, [ecx + 0x1B63]
		add eax, ecx

		cmp byte ptr [eax + 0], 0
		jnz DoLOS

		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayer

		jmp TryNextPlayerCondition

		DoLOS:
		cmp byte ptr [eax + 0x73], 3 // Remote Human/AI
		jnz SkipRemotePlayerOptimization
		mov ecx, Valkyrie::TotalA::LOS::Variables::ViewPlayer
		cmp cl, byte ptr [eax + 0x146]
		jz SkipRemotePlayerOptimization

		mov eax, Valkyrie::TotalA::LOS::Variables::PlayerPtr
		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayer
		jmp TryNextPlayerCondition

		SkipRemotePlayerOptimization:
		xor edx, edx
		mov ecx, dword ptr ds:[0x511DE8]
		
		mov ebx, Valkyrie::TotalA::LOS::Variables::LOSUpdatesPtr
		mov [ebx], eax

		mov dl, [eax + 0x146]
		mov al, dl
		cmp dl, al
		jnz SkipChunk
		and word ptr [ecx + 0x14281], 0xFFF7
		or byte ptr [ecx + 0x142F1], 4
		
		SkipChunk:
		mov Valkyrie::Temporary_Data::Temp1, 0x00481D8E
		jmp [Valkyrie::Temporary_Data::Temp1]

		NoMoreAllies:
		cmp ecx, 0xFFFFFFFF // -1
		jz FinalExit

		mov ecx, 0xFFFFFFFF // -1
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx
		mov eax, Valkyrie::TotalA::LOS::Variables::PlayerPtr

		jmp DoLOS

		FinalExit:
		pop edi
		pop esi
		pop ebp
		pop ebx
		add esp, 0x38
		ret 4
	}
}

__declspec(naked) void LOSUpdate1Start()
{
	__asm
	{
		mov Valkyrie::TotalA::LOS::Variables::LOSUpdatesPtr, ebx
		mov Valkyrie::TotalA::LOS::Variables::PlayerPtr, eax
		xor ecx, ecx
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx
		jmp LOSUpdate1Retry
	}
}

__declspec(naked) void LOSUpdate2Retry()
{
	__asm
	{
		mov eax, Valkyrie::TotalA::LOS::Variables::PlayerPtr
		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayer
		
		jmp TryNextPlayerCondition

		TryNextPlayerNextValue:
		inc ecx

		TryNextPlayerCondition:
		cmp ecx, 0x0A
		jnb NoMoreAllies

		cmp byte ptr [eax + ecx + 0x108], 0
		jz TryNextPlayerNextValue

		cmp byte ptr [eax + ecx + 0x146], cl
		jz TryNextPlayerNextValue

		mov eax, ecx
		inc ecx
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx

		mov ecx, 0x14B
		mul ecx
		mov ecx, dword ptr ds:[0x511DE8]
		lea ecx, [ecx + 0x1B63]
		add eax, ecx

		cmp byte ptr [eax + 0], 0
		jnz DoLOS

		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayer

		jmp TryNextPlayerCondition

		DoLOS:
		cmp byte ptr [eax + 0x73], 3 // Remote Human/AI
		jnz SkipRemotePlayerOptimization
		
		mov ecx, Valkyrie::TotalA::LOS::Variables::ViewPlayer
		cmp cl, byte ptr [eax + 0x146]
		jz SkipRemotePlayerOptimization

		mov eax, Valkyrie::TotalA::LOS::Variables::PlayerPtr
		mov ecx, Valkyrie::TotalA::LOS::Variables::TestPlayer
		jmp TryNextPlayerCondition

		SkipRemotePlayerOptimization:
		xor edx, edx
		mov ecx, dword ptr ds:[0x511DE8]
		
		mov ebx, Valkyrie::TotalA::LOS::Variables::LOSUpdatesPtr
		mov [ebx], eax

		mov dl, [eax + 0x146]
		mov al, dl
		cmp dl, al
		jnz SkipChunk
		and word ptr [ecx + 0x14281], 0xFFF7
		or byte ptr [ecx + 0x142F1], 4
		
		SkipChunk:
		mov Valkyrie::Temporary_Data::Temp1, 0x004822AE
		jmp [Valkyrie::Temporary_Data::Temp1]

		NoMoreAllies:
		cmp ecx, 0xFFFFFFFF // -1
		jz FinalExit

		mov ecx, 0xFFFFFFFF // -1
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx
		mov eax, Valkyrie::TotalA::LOS::Variables::PlayerPtr

		jmp DoLOS

		FinalExit:
		mov ecx, Valkyrie::TotalA::LOS::Variables::ViewPlayer
		mov esi, dword ptr ds:[0x511DE8]
		mov [esi + 0x2A43], cl

		pop edi
		pop esi
		pop ebp
		pop ebx
		add esp, 0x38
		ret 4
	}
}

__declspec(naked) void LOSUpdate2Start()
{
	__asm
	{
		mov Valkyrie::TotalA::LOS::Variables::LOSUpdatesPtr, ebx
		
		mov Valkyrie::TotalA::LOS::Variables::PlayerPtr, eax
		xor ecx, ecx
		mov Valkyrie::TotalA::LOS::Variables::TestPlayer, ecx

		jmp LOSUpdate2Retry
	}
}

__declspec(naked) void LOSPlayerSetAlliedStateJumpHook()
{
	__asm
	{
		mov Valkyrie::TotalA::LOS::Variables::AlliedStateChanged, 1
		xor eax, eax

		pop edi
		pop esi
		pop ebp
		pop ebx
		pop ecx
		ret 0x10
	}
}

__declspec(naked) void LOSPlayerSetAlliedStateReturnHook()
{
	__asm
	{
		mov Valkyrie::TotalA::LOS::Variables::AlliedStateChanged, 1
		xor eax, eax

		pop edi
		pop esi
		pop ebp
		pop ebx
		pop ecx
		ret 0x10
	}
}

__declspec(naked) void LOSSignalAlliedStateChange()
{
	__asm
	{
		mov ecx, Valkyrie::TotalA::LOS::Variables::AlliedStateChanged
		cmp ecx, 0
		jz SkipLOSReset

		xor ecx, ecx
		mov Valkyrie::TotalA::LOS::Variables::AlliedStateChanged, ecx

		mov [Valkyrie::Temporary_Data::Temp1], eax
		mov [Valkyrie::Temporary_Data::Temp2], edx
		mov [Valkyrie::Temporary_Data::Temp3], ecx
		mov [Valkyrie::Temporary_Data::Temp4], ebx
		mov [Valkyrie::Temporary_Data::Temp5], esi
		mov [Valkyrie::Temporary_Data::Temp6], edi
		mov [Valkyrie::Temporary_Data::Temp7], ebp

		push dword ptr 0x00000000
		mov Valkyrie::Temporary_Data::Temp1, 0x004816A0
		call [Valkyrie::Temporary_Data::Temp1]

		mov eax, [Valkyrie::Temporary_Data::Temp1]
		mov edx, [Valkyrie::Temporary_Data::Temp2]
		mov ecx, [Valkyrie::Temporary_Data::Temp3]
		mov ebx, [Valkyrie::Temporary_Data::Temp4]
		mov esi, [Valkyrie::Temporary_Data::Temp5]
		mov edi, [Valkyrie::Temporary_Data::Temp6]
		mov ebp, [Valkyrie::Temporary_Data::Temp7]

		SkipLOSReset:
		mov ecx, dword ptr ds:[0x511DE8]
		cmp bl, [ecx + 0x2A43]
		jnz SkipRadarAndMiniMapUpdate

		mov Valkyrie::Temporary_Data::Temp1, 0x0046556D
		jmp [Valkyrie::Temporary_Data::Temp1]

		SkipRadarAndMiniMapUpdate:
		mov Valkyrie::Temporary_Data::Temp1, 0x004655A6
		jmp [Valkyrie::Temporary_Data::Temp1]
	}
}

__declspec(naked) void LoadMapFunc()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp15], eax
		mov [Valkyrie::Temporary_Data::Temp16], edx
		mov [Valkyrie::Temporary_Data::Temp17], ecx
		mov [Valkyrie::Temporary_Data::Temp18], ebx
		mov [Valkyrie::Temporary_Data::Temp19], esi
		mov [Valkyrie::Temporary_Data::Temp20], edi
		mov [Valkyrie::Temporary_Data::Temp21], ebp

		push eax
		call Valkyrie::MegaMap::LoadMegaMap
		add esp, 4 // Needed?

		mov eax, [Valkyrie::Temporary_Data::Temp15]
		mov edx, [Valkyrie::Temporary_Data::Temp16]
		mov ecx, [Valkyrie::Temporary_Data::Temp17]
		mov ebx, [Valkyrie::Temporary_Data::Temp18]
		mov esi, [Valkyrie::Temporary_Data::Temp19]
		mov edi, [Valkyrie::Temporary_Data::Temp20]
		mov ebp, [Valkyrie::Temporary_Data::Temp21]

		mov ebx, eax
		mov eax, [ebx]
		cmp eax, 0x1020

		jmp [Valkyrie::Variables::LoadMap.Hook_Return_Destination]
	}
}

__declspec(naked) void PostGameScreenRender()
{
	__asm
	{
		//mov [Valkyrie::Temporary_Data::Temp1], eax
		//mov [Valkyrie::Temporary_Data::Temp2], edx
		//mov [Valkyrie::Temporary_Data::Temp3], ecx
		//mov [Valkyrie::Temporary_Data::Temp4], ebx
		//mov [Valkyrie::Temporary_Data::Temp5], esi
		//mov [Valkyrie::Temporary_Data::Temp6], edi
		//mov [Valkyrie::Temporary_Data::Temp7], ebp

		//call Valkyrie::MegaMap::RenderMap

		//mov eax, [Valkyrie::Temporary_Data::Temp1]
		//mov edx, [Valkyrie::Temporary_Data::Temp2]
		//mov ecx, [Valkyrie::Temporary_Data::Temp3]
		//mov ebx, [Valkyrie::Temporary_Data::Temp4]
		//mov esi, [Valkyrie::Temporary_Data::Temp5]
		//mov edi, [Valkyrie::Temporary_Data::Temp6]
		//mov ebp, [Valkyrie::Temporary_Data::Temp7]

		mov ecx, [ecx + 0x391E9]
		jmp [Valkyrie::Variables::PostGameScreenRender.Hook_Return_Destination]
	}
}

__declspec(naked) void BypassGameScreenRender()
{
	__asm
	{
		mov[Valkyrie::Temporary_Data::Temp1], eax
		mov[Valkyrie::Temporary_Data::Temp2], edx
		mov[Valkyrie::Temporary_Data::Temp3], ecx
		mov[Valkyrie::Temporary_Data::Temp4], ebx
		mov[Valkyrie::Temporary_Data::Temp5], esi
		mov[Valkyrie::Temporary_Data::Temp6], edi
		mov[Valkyrie::Temporary_Data::Temp7], ebp

		call Valkyrie::MegaMap::RenderMap

		mov eax, [Valkyrie::Temporary_Data::Temp1]
		mov edx, [Valkyrie::Temporary_Data::Temp2]
		mov ecx, [Valkyrie::Temporary_Data::Temp3]
		mov ebx, [Valkyrie::Temporary_Data::Temp4]
		mov esi, [Valkyrie::Temporary_Data::Temp5]
		mov edi, [Valkyrie::Temporary_Data::Temp6]
		mov ebp, [Valkyrie::Temporary_Data::Temp7]

		jmp [Valkyrie::Variables::SkipGameScreenRender.Hook_Return_Destination]
	}
}

__declspec(naked) void BypassGameScreenRender2()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp1], eax
		mov [Valkyrie::Temporary_Data::Temp2], edx
		mov [Valkyrie::Temporary_Data::Temp3], ecx
		mov [Valkyrie::Temporary_Data::Temp4], ebx
		mov [Valkyrie::Temporary_Data::Temp5], esi
		mov [Valkyrie::Temporary_Data::Temp6], edi
		mov [Valkyrie::Temporary_Data::Temp7], ebp

		call Valkyrie::MegaMap::RenderMap

		mov eax, [Valkyrie::Temporary_Data::Temp1]
		mov edx, [Valkyrie::Temporary_Data::Temp2]
		mov ecx, [Valkyrie::Temporary_Data::Temp3]
		mov ebx, [Valkyrie::Temporary_Data::Temp4]
		mov esi, [Valkyrie::Temporary_Data::Temp5]
		mov edi, [Valkyrie::Temporary_Data::Temp6]
		mov ebp, [Valkyrie::Temporary_Data::Temp7]

		jmp [Valkyrie::Variables::SkipGameScreenRender.Hook_Return_Destination]
	}
}

#ifdef DEBUG_BUILD

__declspec(naked) void ReportThreadDataFunc()
{
	__asm
	{
		mov [Valkyrie::Temporary_Data::Temp1], eax
		mov [Valkyrie::Temporary_Data::Temp2], edx
		mov [Valkyrie::Temporary_Data::Temp3], ecx
		mov [Valkyrie::Temporary_Data::Temp4], ebx
		mov [Valkyrie::Temporary_Data::Temp5], esi
		mov [Valkyrie::Temporary_Data::Temp6], edi
		mov [Valkyrie::Temporary_Data::Temp7], ebp

		call Valkyrie::Debugging::ThreadReportData

		mov eax, [Valkyrie::Temporary_Data::Temp1]
		mov edx, [Valkyrie::Temporary_Data::Temp2]
		mov ecx, [Valkyrie::Temporary_Data::Temp3]
		mov ebx, [Valkyrie::Temporary_Data::Temp4]
		mov esi, [Valkyrie::Temporary_Data::Temp5]
		mov edi, [Valkyrie::Temporary_Data::Temp6]
		mov ebp, [Valkyrie::Temporary_Data::Temp7]

		mov [Valkyrie::Temporary_Data::TempPtr1], 0x00499890
		call [Valkyrie::Temporary_Data::TempPtr1]

		jmp [Valkyrie::Variables::DebuggingThreadReporter.Hook_Return_Destination]
	}
}

#endif

/*
---------------------------------------------------------------------------------

	function definitions

---------------------------------------------------------------------------------
*/


BOOL WINAPI DllMain(
	HINSTANCE hInstDLL,
	DWORD fdwReason,
	LPVOID lpvReserved
)
{
	switch (fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		Valkyrie::Main::OpenDllFunction();
		break;

	case DLL_PROCESS_DETACH:
		Valkyrie::Main::CloseDllFunction();
		break;
	}

	return TRUE;
}

#ifdef DEBUG_BUILD
void Valkyrie::Debugging::ThreadReportData()
{

	DWORD OldProtect;


	SharedMemStruct* NewStruct = new SharedMemStruct();

	NewStruct->LastGameReportedTickCount = TotalA::TA_GetTickCount();

	if (Accessors::GetGameState() == 6)
	{
		NewStruct->InGame = 1;
	}
	else
	{
		NewStruct->InGame = 0;
	}

	VirtualProtect((LPVOID)0x004FB970, sizeof(SharedMemStruct), PAGE_READWRITE, &OldProtect);

	memcpy((void*)0x004FB970, NewStruct, sizeof(SharedMemStruct));

	VirtualProtect((LPVOID)0x004FB970, sizeof(SharedMemStruct), OldProtect, &OldProtect);
}
#endif

void Valkyrie::Main::OpenDllFunction()
{
	int Result = CheckUndesirableDLLs();

	if (Result != 0)
	{
		if (Result == 1)
		{
			Valkyrie::TotalA::TA_MessageBoxA(NULL, "ddraw.dll has been found in your TA folder! This file is not compatible with Valkyrie and must be removed before proceeding.", "ddraw.dll Found!", MB_ICONERROR);
		}
		else if (Result == 2)
		{
			Valkyrie::TotalA::TA_MessageBoxA(NULL, "dplayx.dll has been found in your TA folder! This file is not compatible with Valkyrie and must be removed before proceeding.", "dplayx.dll Found!", MB_ICONERROR);
		}
		else if (Result == 3)
		{
			Valkyrie::TotalA::TA_MessageBoxA(NULL, "ddraw.dll and dplayx.dll have been found in your TA folder! These files are not compatible with Valkyrie and must be removed before proceeding.", "ddraw.dll and dplayx.dll Found!", MB_ICONERROR);
		}

		exit(0);
	}

	Config::ReadConfig();

#ifdef OTA_MOD
	if (Config::UseNoCD) { Patches::NoCD(); }
#endif

	Patches::COBExtensionsHandler();

	Patches::DataFile();

	if (Config::UseMaxUnitLimit) { Patches::UnitLimit(); }
	if (Config::UsePathfinding) { Patches::Pathfinding(); }
	if (Config::UseCompositeBuffer) { Patches::CompositeBuffer(); }
	if (Config::UseSFXLimit) { Patches::SFXLimit(); }
	if (Config::UseMixingBuffers) { Patches::MixingBuffers(); }
	if (Config::UseTAHook || Config::UseHotKeys) { Patches::MainWndProc(); }
	if (Config::UseTAHook) { Patches::DrawBuildRectLive(); Patches::RenderForTAHook(); }
	if (Config::UseHotKeys) { Patches::HotKeys(); }

	Patches::CrashDumps();
	Patches::LineOfSight();

	Patches::LoadMap();
	Patches::RenderHooks();

#ifdef DEBUG_BUILD
	//Patches::DebuggingThreadHook();
#endif

#ifdef ESCALATION_MOD
	Mods::Escalation::HexEdits();
#endif

#ifdef MAYHEM_MOD
	Mods::Mayhem::HexEdits();
#endif

}

void Valkyrie::Main::CloseDllFunction()
{

}

int Valkyrie::Main::CheckUndesirableDLLs()
{
	int Result = 0;

	WIN32_FIND_DATAA FindFileData;
	HANDLE FindHandle;

	FindHandle = Valkyrie::TotalA::TA_FindFirstFileA("ddraw.dll", &FindFileData);

	if (FindHandle != INVALID_HANDLE_VALUE)
	{
		Result += 1;
	}

	FindHandle = Valkyrie::TotalA::TA_FindFirstFileA("dplayx.dll", &FindFileData);

	if (FindHandle != INVALID_HANDLE_VALUE)
	{
		Result += 2;
	}

	// 1 = ddraw exists
	// 2 = dplay exists
	// 3 = both exist

	return Result;
}

#ifdef DEBUG_BUILD
DWORD WINAPI Valkyrie::DebuggingThreadFunction(LPVOID lpParam)
{
	return 0;
}
#endif

LRESULT CALLBACK Valkyrie::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	int Result = 0;

	if (Valkyrie::Accessors::GetTAGameState() == Valkyrie::GAME_STATE::IN_GAME)
	{
		if (Config::UseHotKeys)
		{
			Result += Valkyrie::HotKeys::HotKeysWndProc(hwnd, msg, wParam, lParam);
		}

		if (Config::UseTAHook)
		{
			Result += Valkyrie::TAHook::BuildLineAndBuildRingWndProc(hwnd, msg, wParam, lParam);
		}

		//if (Config::UseMegaMap)
		//{
			Result += Valkyrie::MegaMap::MegaMapWndProc(hwnd, msg, wParam, lParam);
		//}
	}

	return Result;
}

void Valkyrie::Config::ReadConfig()
{
	AdjustConfigFilePath();
	AdjustConfigFilePath2(); // for Chat Macro

	UseNoCD = TotalA::TA_GetPrivateProfileIntA("Config", "UseNoCD", 0, Config::ConfigFileNameFullPath);
	UseMaxUnitLimit = TotalA::TA_GetPrivateProfileIntA("Config", "UseMaxUnitLimit", 0, Config::ConfigFileNameFullPath);
	MaxUnitLimit = TotalA::TA_GetPrivateProfileIntA("Config", "MaxUnitLimit", 250, Config::ConfigFileNameFullPath);
	UsePathfinding = TotalA::TA_GetPrivateProfileIntA("Config", "UsePathfinding", 0, Config::ConfigFileNameFullPath);
	PathfindingCycles = TotalA::TA_GetPrivateProfileIntA("Config", "PathfindingCycles", 1333, Config::ConfigFileNameFullPath);
	UseCompositeBuffer = TotalA::TA_GetPrivateProfileIntA("Config", "UseCompositeBuffer", 0, Config::ConfigFileNameFullPath);
	CompositeX = TotalA::TA_GetPrivateProfileIntA("Config", "CompositeX", 600, Config::ConfigFileNameFullPath);
	CompositeY = TotalA::TA_GetPrivateProfileIntA("Config", "CompositeY", 600, Config::ConfigFileNameFullPath);
	UseSFXLimit = TotalA::TA_GetPrivateProfileIntA("Config", "UseSFXLimit", 0, Config::ConfigFileNameFullPath);
	SFXLimit = TotalA::TA_GetPrivateProfileIntA("Config", "SFXLimit", 400, Config::ConfigFileNameFullPath);
	UseMixingBuffers = TotalA::TA_GetPrivateProfileIntA("Config", "UseMixingBuffers", 0, Config::ConfigFileNameFullPath);
	MixingBuffers = TotalA::TA_GetPrivateProfileIntA("Config", "MixingBuffers", 8, Config::ConfigFileNameFullPath);
	UseTAHook = TotalA::TA_GetPrivateProfileIntA("Config", "UseTAHook", 0, Config::ConfigFileNameFullPath);
	MaxBuildSpacing = TotalA::TA_GetPrivateProfileIntA("Config", "MaxBuildSpacing", 10, Config::ConfigFileNameFullPath);
	UseHotKeys = TotalA::TA_GetPrivateProfileIntA("Config", "UseHotKeys", 0, Config::ConfigFileNameFullPath);
	CtrlShiftBuildQueueIncDecAmount = TotalA::TA_GetPrivateProfileIntA("Config", "CtrlShiftBuildQueueIncDecAmount", 100, Config::ConfigFileNameFullPath);
}

void Valkyrie::Config::AdjustConfigFilePath()
{
	unsigned int x;

	x = Valkyrie::TotalA::TA_GetModuleFileNameA(0, Config::ConfigFileNameFullPath, 256);

	while (Config::ConfigFileNameFullPath[x] != '\\')
	{
		Config::ConfigFileNameFullPath[x] = 0x00;
		x--;
	}

	x++;

	for (size_t i = 0; i < Config::ConfigFileName.size(); i++)
	{
		Config::ConfigFileNameFullPath[x] = Config::ConfigFileName[i];
		x++;
	}

	Config::ConfigFileNameFullPath[x] = 0x00;
}

void Valkyrie::Config::AdjustConfigFilePath2()
{
	unsigned int x;

	x = Valkyrie::TotalA::TA_GetModuleFileNameA(0, Config::ConfigFileNameFullPath2, 256);

	while (Config::ConfigFileNameFullPath2[x] != '\\')
	{
		Config::ConfigFileNameFullPath2[x] = 0x00;
		x--;
	}

	x++;

	for (size_t i = 0; i < Config::ConfigFileName2.size(); i++)
	{
		Config::ConfigFileNameFullPath2[x] = Config::ConfigFileName2[i];
		x++;
	}

	Config::ConfigFileNameFullPath2[x] = 0x00;
}

void* Valkyrie::Accessors::GetTAMainStructPtr()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
	}
}

void Valkyrie::Mutators::SetIsAlteredUnitLimit(bool IsAltered)
{
	unsigned int Ptr;

	Ptr = (unsigned int)Accessors::GetTAMainStructPtr();
	*((unsigned int*)(Ptr + 0x589)) = IsAltered;
}

void Valkyrie::Mutators::SetMaxUnitLimit(unsigned short MaxUnitLimitPerPlayer)
{
	unsigned int Ptr;

	Ptr = (unsigned int)Accessors::GetTAMainStructPtr();
	*((unsigned short*)(Ptr + 0x37EEC)) = MaxUnitLimitPerPlayer;
}

/*
---------------------------------------------------------------------------------

	Escalation Patches

---------------------------------------------------------------------------------
*/

#ifdef ESCALATION_MOD
	
void Valkyrie::Mods::Escalation::HexEdits()
{
	std::vector<unsigned char> Patch5;
	std::vector<unsigned char> Patch6;
	std::vector<unsigned char> Patch7;
	std::vector<unsigned char> Patch8;
	std::vector<unsigned char> Patch9;
	std::vector<unsigned char> Patch10;
	std::vector<unsigned char> Patch11;
	std::vector<unsigned char> Patch12;
	std::vector<unsigned char> Patch13;
	std::vector<unsigned char> Patch14;
	std::vector<unsigned char> Patch15;
	std::vector<unsigned char> Patch16;
	std::vector<unsigned char> Patch17;
	std::vector<unsigned char> Patch18;
	std::vector<unsigned char> Patch19;
	std::vector<unsigned char> Patch20;
	std::vector<unsigned char> Patch21;
	std::vector<unsigned char> Patch22;
	std::vector<unsigned char> Patch23;
	std::vector<unsigned char> Patch24;
	std::vector<unsigned char> Patch25;
	std::vector<unsigned char> Patch26;
	std::vector<unsigned char> Patch27;
	std::vector<unsigned char> Patch28;
	std::vector<unsigned char> Patch29;
	std::vector<unsigned char> Patch30;
	std::vector<unsigned char> Patch31;
	std::vector<unsigned char> Patch32;
	std::vector<unsigned char> Patch33;
	std::vector<unsigned char> Patch34;
	std::vector<unsigned char> Patch35;
	std::vector<unsigned char> Patch36;
	std::vector<unsigned char> Patch37;
	std::vector<unsigned char> Patch38;
	std::vector<unsigned char> Patch39;
	std::vector<unsigned char> Patch40;
	std::vector<unsigned char> Patch41;
	std::vector<unsigned char> Patch42;
	std::vector<unsigned char> Patch43;
	std::vector<unsigned char> Patch44;
	std::vector<unsigned char> Patch45;
	std::vector<unsigned char> Patch46;
	std::vector<unsigned char> Patch47;
	std::vector<unsigned char> Patch48;
	std::vector<unsigned char> Patch49;
	std::vector<unsigned char> Patch50;
	std::vector<unsigned char> Patch51;
	std::vector<unsigned char> Patch52;
	std::vector<unsigned char> Patch53;
	std::vector<unsigned char> Patch54;
	std::vector<unsigned char> Patch55;
	std::vector<unsigned char> Patch56;
	std::vector<unsigned char> Patch57;
	std::vector<unsigned char> Patch58;
	std::vector<unsigned char> Patch59;
	std::vector<unsigned char> Patch60;
	std::vector<unsigned char> Patch61;
	std::vector<unsigned char> Patch62;
	std::vector<unsigned char> Patch63;
	std::vector<unsigned char> Patch64;
	std::vector<unsigned char> Patch65;
	std::vector<unsigned char> Patch66;
	std::vector<unsigned char> Patch67;
	std::vector<unsigned char> Patch68;
	std::vector<unsigned char> Patch69;
	std::vector<unsigned char> Patch70;
	std::vector<unsigned char> Patch71;
	std::vector<unsigned char> Patch72;
	std::vector<unsigned char> Patch73;
	std::vector<unsigned char> Patch74;
	std::vector<unsigned char> Patch75;
	std::vector<unsigned char> Patch76;
	std::vector<unsigned char> Patch77;
	std::vector<unsigned char> Patch78;
	std::vector<unsigned char> Patch79;
	std::vector<unsigned char> Patch80;
	std::vector<unsigned char> Patch81;
	std::vector<unsigned char> Patch82;
	std::vector<unsigned char> Patch83;
	std::vector<unsigned char> Patch84;
	std::vector<unsigned char> Patch85;
	std::vector<unsigned char> Patch86;
	std::vector<unsigned char> Patch87;
	std::vector<unsigned char> Patch88;
	std::vector<unsigned char> Patch89;
	std::vector<unsigned char> Patch90;
	std::vector<unsigned char> Patch91;
	std::vector<unsigned char> Patch92;
	std::vector<unsigned char> Patch93;
	std::vector<unsigned char> Patch94;
	std::vector<unsigned char> Patch95;
	std::vector<unsigned char> Patch96;
	std::vector<unsigned char> Patch97;
	std::vector<unsigned char> Patch98;
	std::vector<unsigned char> Patch99;
	std::vector<unsigned char> Patch100;
	std::vector<unsigned char> Patch101;
	std::vector<unsigned char> Patch102;
	std::vector<unsigned char> Patch103;
	std::vector<unsigned char> Patch104;
	std::vector<unsigned char> Patch105;
	std::vector<unsigned char> Patch106;
	std::vector<unsigned char> Patch107;
	std::vector<unsigned char> Patch108;
	std::vector<unsigned char> Patch109;
	std::vector<unsigned char> Patch110;
	std::vector<unsigned char> Patch111;
	std::vector<unsigned char> Patch112;
	std::vector<unsigned char> Patch113;
	std::vector<unsigned char> Patch114;
	std::vector<unsigned char> Patch115;
	std::vector<unsigned char> Patch116;
	std::vector<unsigned char> Patch117;
	std::vector<unsigned char> Patch118;
	std::vector<unsigned char> Patch119;
	std::vector<unsigned char> Patch120;
	std::vector<unsigned char> Patch121;
	std::vector<unsigned char> Patch122;
	std::vector<unsigned char> Patch123;
	std::vector<unsigned char> Patch124;
	std::vector<unsigned char> Patch125;
	std::vector<unsigned char> Patch126;
	std::vector<unsigned char> Patch127;
	std::vector<unsigned char> Patch128;
	std::vector<unsigned char> Patch129;
	std::vector<unsigned char> Patch130;
	std::vector<unsigned char> Patch131;
	std::vector<unsigned char> Patch132;
	std::vector<unsigned char> Patch133;
	std::vector<unsigned char> Patch134;
	std::vector<unsigned char> Patch135;
	std::vector<unsigned char> Patch136;
	std::vector<unsigned char> Patch137;
	std::vector<unsigned char> Patch138;
	std::vector<unsigned char> Patch139;
	std::vector<unsigned char> Patch140;
	std::vector<unsigned char> Patch141;
	std::vector<unsigned char> Patch142;
	std::vector<unsigned char> Patch143;
	std::vector<unsigned char> Patch144;
	std::vector<unsigned char> Patch145;
	std::vector<unsigned char> Patch146;
	std::vector<unsigned char> Patch147;
	std::vector<unsigned char> Patch148;
	std::vector<unsigned char> Patch149;
	std::vector<unsigned char> Patch150;
	std::vector<unsigned char> Patch151;
	std::vector<unsigned char> Patch152;
	std::vector<unsigned char> Patch153;
	std::vector<unsigned char> Patch154;
	std::vector<unsigned char> Patch155;
	std::vector<unsigned char> Patch156;
	std::vector<unsigned char> Patch157;
	std::vector<unsigned char> Patch158;
	std::vector<unsigned char> Patch159;
	std::vector<unsigned char> Patch160;
	std::vector<unsigned char> Patch161;
	std::vector<unsigned char> Patch162;
	std::vector<unsigned char> Patch163;
	std::vector<unsigned char> Patch164;
	std::vector<unsigned char> Patch165;
	std::vector<unsigned char> Patch166;
	std::vector<unsigned char> Patch167;
	std::vector<unsigned char> Patch168;
	std::vector<unsigned char> Patch169;
	std::vector<unsigned char> Patch170;
	std::vector<unsigned char> Patch171;
	std::vector<unsigned char> Patch172;
	std::vector<unsigned char> Patch173;
	std::vector<unsigned char> Patch174;

	unsigned char Bytes5[] = { 0xF6, 0x81, 0x0E, 0x01, 0x00, 0x00, 0x01, 0x8B, 0x4C, 0x24, 0x38 };
	unsigned char Bytes6[] = { 0x83, 0xFD, 0x01, 0x7F, 0x04, 0x6A, 0x00, 0xEB, 0x02 };
	unsigned char Bytes7[] = { 0x83, 0xFD, 0x01, 0x7F, 0x04, 0x6A, 0x00, 0xEB, 0x02 };
	unsigned char Bytes8[] = { 0x02 };
	unsigned char Bytes9[] = { 0xD3, 0x5A };
	unsigned char Bytes10[] = { 0x43 };
	unsigned char Bytes11[] = { 0xF1, 0x53 };
	unsigned char Bytes12[] = { 0x31 };
	unsigned char Bytes13[] = { 0xB1, 0x42 };
	unsigned char Bytes14[] = { 0xEB, 0x40 };
	unsigned char Bytes15[] = { 0x12 };
	unsigned char Bytes16[] = { 0x66, 0x25, 0x20, 0x80, 0x66, 0x3D, 0x20, 0x80, 0x0F, 0x85, 0x6C, 0x01 };
	unsigned char Bytes17[] = { 0x33, 0xFF, 0x33, 0xDB, 0x89, 0x5C, 0x24, 0x14, 0xC7, 0x44, 0x24, 0x18, 0x03, 0x00, 0x00, 0x00, 0x8B, 0x75, 0x39, 0x8A, 0x4C, 0x33, 0x1F, 0x80, 0xE1, 0x12, 0x80, 0xF9, 0x12, 0x0F, 0x85, 0x32, 0x01, 0x00, 0x00, 0x8B, 0x54, 0x33, 0x10, 0x8B, 0x8A, 0x12 };
	unsigned char Bytes18[] = { 0x01 };
	unsigned char Bytes19[] = { 0x85 };
	unsigned char Bytes20[] = { 0xF6, 0x44, 0x24, 0x24, 0x01, 0x75, 0x0C, 0xC1, 0xE9, 0x03, 0xF6, 0xC5, 0x80, 0x0F, 0x85, 0x0C, 0x01, 0x00, 0x00, 0x57, 0x56, 0xE8, 0x06, 0x17, 0x08, 0x00, 0x85, 0xC0, 0x0F, 0x84, 0x9F, 0x00, 0x00, 0x00, 0x57, 0x50, 0x56, 0x8B, 0xF0, 0xE8, 0x14, 0x21, 0x09 };
	unsigned char Bytes21[] = { 0x85, 0xC0, 0x8B, 0xC6, 0x8B, 0x75, 0x39, 0x75, 0x07, 0x66, 0xC7, 0x44, 0x33, 0x04 };
	unsigned char Bytes22[] = { 0x00, 0x8B, 0x88, 0x96 };
	unsigned char Bytes23[] = { 0x00, 0x33, 0xD2, 0x8A, 0x91, 0x46, 0x01 };
	unsigned char Bytes24[] = { 0x00, 0x8B, 0x4D, 0x00, 0x80, 0xBC, 0x0A, 0x08, 0x01 };
	unsigned char Bytes25[] = { 0x00, 0x75, 0x5E, 0x66, 0x8B, 0x88, 0xA6 };
	unsigned char Bytes26[] = { 0x00, 0x8B, 0xD6 };
	unsigned char Bytes27[] = { 0xA4 };
	unsigned char Bytes28[] = { 0x5A, 0x04, 0x01 };
	unsigned char Bytes29[] = { 0x75, 0x37, 0xF6, 0xC2, 0x10, 0x74, 0x32, 0x66, 0x8B, 0x88, 0xA6, 0x00, 0x00 };
	unsigned char Bytes30[] = { 0x8B, 0xBE, 0x92, 0x00, 0x00 };
	unsigned char Bytes31[] = { 0xBD, 0x01, 0x00, 0x00, 0x00, 0x8B, 0xBF, 0x3D, 0x02, 0x00, 0x00, 0x8B, 0xD1, 0x83, 0xE1, 0x1F, 0xC1, 0xEA, 0x05, 0xD3, 0xE5, 0x85, 0x2C, 0x97, 0x75, 0x0B, 0x8B, 0x8E, 0x12, 0x01, 0x00, 0x00, 0xF6, 0xC1, 0x0C, 0x75, 0x07, 0xE9, 0xD3, 0x00, 0x00 };
	unsigned char Bytes32[] = { 0x90, 0x90 };
	unsigned char Bytes33[] = { 0xCF };
	unsigned char Bytes34[] = { 0xE9, 0x2B, 0x03 };
	unsigned char Bytes35[] = { 0x8B, 0x7C, 0x24, 0x4C, 0x33, 0xC0, 0x8A, 0x47, 0x05, 0x83, 0xE8, 0x00, 0x0F, 0x84, 0x03, 0x02, 0x00, 0x00, 0x48, 0x0F, 0x85, 0x1A, 0x03, 0x00, 0x00, 0x6A, 0x03, 0x8B, 0xCE, 0xE8, 0xF2, 0x92, 0x07 };
	unsigned char Bytes36[] = { 0x8B, 0x8E, 0x92, 0x00, 0x00, 0x00, 0x0F, 0xBF, 0x96, 0x08, 0x01, 0x00, 0x00, 0x8B, 0x81, 0xFA, 0x01, 0x00, 0x00, 0xC1, 0xE8, 0x02, 0x8D, 0x04, 0x40, 0x3B, 0xD0, 0x73, 0x09, 0xF6, 0x81, 0x47, 0x02, 0x00, 0x00, 0x08, 0x74, 0x05, 0xE9 };
	unsigned char Bytes37[] = { 0xEB, 0x0D, 0xB8, 0x02, 0x00, 0x00, 0x00, 0xEB, 0x06, 0x90, 0xB8, 0x07, 0x00, 0x00, 0x00, 0x5F, 0x5E, 0x5D };
	unsigned char Bytes38[] = { 0xC2 };
	unsigned char Bytes39[] = { 0xE9, 0x05, 0x03 };
	unsigned char Bytes40[] = { 0x8B, 0x7C, 0x24, 0x60, 0x33, 0xC0, 0x8A, 0x47, 0x05, 0x83, 0xE8, 0x00, 0x0F, 0x84, 0x9A, 0x02, 0x00, 0x00, 0x48, 0x0F, 0x85, 0xF4, 0x02, 0x00, 0x00, 0x8B, 0x96, 0x92, 0x00, 0x00, 0x00, 0x0F, 0xBF, 0x8E, 0x08, 0x01, 0x00, 0x00, 0x8B, 0x82, 0xFA, 0x01, 0x00, 0x00, 0xC1, 0xE8, 0x02, 0x8D, 0x04, 0x40, 0x3B, 0xC8, 0x73, 0x09, 0xF6, 0x82, 0x47, 0x02, 0x00, 0x00, 0x08, 0x74, 0x05, 0xE9 };
	unsigned char Bytes41[] = { 0xEB, 0x0D, 0xB8, 0x02, 0x00, 0x00, 0x00, 0xEB, 0x06, 0x90, 0xB8, 0x07, 0x00, 0x00, 0x00, 0x5F, 0x5E, 0x5D };
	unsigned char Bytes42[] = { 0x0F, 0x85, 0xEF, 0x02 };
	unsigned char Bytes43[] = { 0x8B, 0x44, 0x24, 0x30, 0x8D, 0x7D, 0x22, 0x83, 0xC0, 0x6A, 0x57, 0x50, 0x89, 0x44, 0x24, 0x3C, 0xE8, 0xC9, 0x9A, 0x07, 0x00, 0x8B, 0xD8, 0x68, 0x00, 0x00, 0x40, 0x01, 0x53, 0xE8, 0x2B, 0x62, 0x0A, 0x00, 0x83, 0xC4, 0x08, 0x8B, 0xF0, 0xF7, 0xDE, 0x68, 0x00, 0x00, 0x40, 0x01, 0x53, 0xE8, 0x4D, 0x62, 0x0A, 0x00, 0x8B, 0x0F, 0x83, 0xC4, 0x08, 0x03, 0xF1, 0x8B, 0x4F, 0x04, 0x8B, 0x7F, 0x08, 0x6A, 0x36, 0xF7, 0xD8, 0x03, 0xF8, 0x89, 0x74, 0x24, 0x14, 0x89, 0x4C, 0x24, 0x18, 0x89, 0x7C, 0x24, 0x1C, 0xE8, 0x16, 0x40, 0x0A, 0x00, 0x33, 0xFF, 0x83, 0xC4, 0x04, 0x3B, 0xC7, 0x74, 0x11, 0x8D, 0x4C, 0x24, 0x10, 0x51, 0x55, 0x8B, 0xC8, 0xE8, 0xC0, 0xD3, 0x03, 0x00, 0x8B, 0xF0, 0xEB, 0x02, 0x33, 0xF6, 0x68, 0x50, 0x01, 0x00 };
	unsigned char Bytes44[] = { 0xCE, 0xE8, 0x0E, 0xD8, 0x03, 0x00, 0x56, 0x8B, 0xCD, 0xE8, 0xA6, 0x79, 0x02, 0x00, 0x8B, 0x5D, 0x06, 0x80, 0xCB, 0xE0, 0x89, 0x5D, 0x06, 0x8B, 0x5C, 0x24, 0x30, 0x8B, 0x93, 0x92, 0x00, 0x00, 0x00, 0x0F, 0xBF, 0x8B, 0x08, 0x01, 0x00, 0x00, 0x8B, 0x82, 0xFA, 0x01, 0x00, 0x00, 0xC1, 0xE8, 0x02, 0x8D, 0x04, 0x40, 0x3B, 0xC8, 0x73, 0x09, 0xF6, 0x82, 0x47 };
	unsigned char Bytes45[] = { 0x00, 0x00, 0x08, 0x74, 0x06, 0xE9, 0x0A, 0x01, 0x00 };
	unsigned char Bytes46[] = { 0x90 };
	unsigned char Bytes47[] = { 0xEB, 0x0D, 0xB8, 0x06, 0x00, 0x00, 0x00, 0xEB, 0x06, 0x90, 0xB8, 0x07, 0x00, 0x00, 0x00, 0x5F, 0x5E, 0x5D };
	unsigned char Bytes48[] = { 0x06 };
	unsigned char Bytes49[] = { 0x06 };
	unsigned char Bytes50[] = { 0x06 };
	unsigned char Bytes51[] = { 0xF6, 0x82, 0x47, 0x02, 0x00, 0x00, 0x08, 0x0F, 0x85, 0xDC, 0x00, 0x00, 0x00, 0x8A, 0x4C, 0x24, 0x30, 0x8B, 0x86, 0x96, 0x00, 0x00, 0x00, 0x88, 0x4C, 0x24, 0x1C, 0x33, 0xDB, 0x8D, 0x54, 0x24, 0x1C, 0x33, 0xC9, 0x89, 0x5C, 0x24, 0x20, 0x89, 0x5C, 0x24, 0x24, 0x89, 0x5C, 0x24, 0x28, 0x8A, 0x88, 0x46, 0x01, 0x00, 0x00, 0x52, 0x68, 0x00, 0x0F, 0x00, 0x00, 0x55, 0x51, 0xE8, 0x0B, 0x8F, 0xFF, 0xFF, 0x8B, 0x4C };
	unsigned char Bytes52[] = { 0x20, 0x3B, 0xCB, 0x75, 0x04 };
	unsigned char Bytes53[] = { 0xC0, 0xEB, 0x09, 0x8B, 0x44, 0x24, 0x24, 0x2B, 0xC1, 0xC1, 0xF8, 0x02, 0x33, 0xD2, 0x3B, 0xC3, 0x0F, 0x94, 0xC2, 0x84, 0xD2, 0x75, 0x72, 0x53, 0x8B, 0xCF, 0xE8, 0x83, 0x62, 0x02, 0x00, 0x8B, 0x6C };
	unsigned char Bytes54[] = { 0x20, 0x3B, 0xEB, 0x75, 0x04, 0x33, 0xC0, 0xEB, 0x09, 0x8B, 0x44, 0x24, 0x24, 0x2B, 0xC5, 0xC1, 0xF8, 0x02, 0x50, 0xE8, 0xC8, 0x45, 0x0A, 0x00, 0x8B, 0x5C, 0x85, 0x00, 0x6A, 0x56, 0xE8, 0x9D, 0x28, 0x0A };
	unsigned char Bytes55[] = { 0x8B, 0xE8, 0x83, 0xC4, 0x04, 0x85, 0xED, 0x74, 0x1F, 0x6A, 0x00, 0x6A };
	unsigned char Bytes56[] = { 0x6A, 0x00, 0x6A, 0x00, 0x53, 0x51, 0x8B, 0xCC, 0x68, 0x94, 0x1B, 0x50, 0x00, 0xE8, 0xCE, 0x60, 0x02, 0x00, 0x8B, 0xCD, 0xE8, 0x27, 0x7A, 0x02, 0x00, 0xEB, 0x02, 0x33, 0xC0, 0x50, 0x56, 0xE8, 0x0C, 0x86, 0x02, 0x00, 0xC7, 0x47, 0x06 };
	unsigned char Bytes57[] = { 0x00, 0x00, 0x00, 0x8B, 0x44, 0x24, 0x20, 0x50, 0xEB, 0x06, 0x90, 0x90, 0x90, 0x90, 0x90 };
	unsigned char Bytes58[] = { 0xDC };
	unsigned char Bytes59[] = { 0x9D };
	unsigned char Bytes60[] = { 0xFD };
	unsigned char Bytes61[] = { 0xF6, 0x82, 0x47, 0x02, 0x00, 0x00, 0x08, 0x0F, 0x85, 0xF0, 0x00, 0x00, 0x00, 0x8A, 0x54, 0x24, 0x34, 0x8D, 0x44, 0x24, 0x1C, 0x88, 0x54 };
	unsigned char Bytes62[] = { 0x1C, 0x8B, 0x96, 0x96, 0x00, 0x00, 0x00, 0x50, 0x33, 0xC0, 0x89, 0x6C, 0x24, 0x24, 0x89, 0x6C, 0x24, 0x28, 0x89, 0x6C, 0x24, 0x2C, 0x8A, 0x82, 0x46, 0x01, 0x00, 0x00, 0x8D, 0x4E, 0x6A, 0x68, 0x00, 0x0F, 0x00, 0x00, 0x51, 0x50, 0xE8, 0x8D, 0x89, 0xFF, 0xFF, 0x8B, 0x6C };
	unsigned char Bytes63[] = { 0x20, 0x85, 0xED, 0x75, 0x04 };
	unsigned char Bytes64[] = { 0xC0, 0xEB, 0x09, 0x8B, 0x44, 0x24, 0x24, 0x2B, 0xC5, 0xC1, 0xF8, 0x02, 0x33, 0xC9, 0x85, 0xC0, 0x0F, 0x94, 0xC1, 0x84, 0xC9, 0x0F, 0x85, 0x8D, 0x00, 0x00, 0x00, 0x6A, 0x00, 0x8B, 0xCF, 0xE8, 0x00, 0x5D, 0x02, 0x00, 0x8B, 0x5C };
	unsigned char Bytes65[] = { 0x20, 0x85, 0xDB, 0x75, 0x04, 0x33, 0xC0, 0xEB, 0x09, 0x8B, 0x44, 0x24, 0x24, 0x2B, 0xC3, 0xC1, 0xF8, 0x02, 0x50, 0xE8, 0x45, 0x40, 0x0A, 0x00, 0x8B, 0x2C, 0x83, 0x6A, 0x56, 0xE8, 0x1B, 0x23, 0x0A };
	unsigned char Bytes66[] = { 0x8B, 0xD8, 0x83, 0xC4, 0x04, 0x85, 0xDB, 0x74, 0x1F, 0x6A, 0x00, 0x6A };
	unsigned char Bytes67[] = { 0x6A, 0x00, 0x6A, 0x00, 0x55, 0x51, 0x8B, 0xCC, 0x68, 0x94, 0x1B, 0x50, 0x00, 0xE8, 0x4C, 0x5B, 0x02, 0x00, 0x8B, 0xCB, 0xE8, 0xA5, 0x74, 0x02, 0x00, 0xEB, 0x02, 0x33, 0xC0, 0x50, 0x56, 0xE8, 0x8A, 0x80, 0x02, 0x00, 0x8D, 0x4C, 0x24, 0x1C, 0xC7, 0x47, 0x06, 0x00, 0x00, 0x00, 0x00, 0x8B, 0x54, 0x24, 0x24, 0x8B, 0x44, 0x24, 0x20, 0x52, 0x50, 0xE8, 0xC0, 0x3F, 0xFF, 0xFF, 0x8B, 0x4C, 0x24, 0x20, 0x51, 0xE8, 0xD6, 0x22, 0x0A, 0x00, 0x83, 0xC4, 0x04, 0x33, 0xC0, 0xE9, 0xAE };
	unsigned char Bytes68[] = { 0x00, 0x00, 0x55, 0xE8, 0xC6, 0x22, 0x0A, 0x00, 0x83, 0xC4, 0x04, 0x6A, 0x02, 0xE8, 0xCC, 0x3F, 0x0A, 0x00 };
	unsigned char Bytes69[] = { 0x8B, 0x6E, 0x66, 0x85, 0xC0, 0x74, 0x07, 0x66, 0x81, 0xC5, 0x00, 0x40, 0xEB, 0x05, 0x66, 0x81, 0xED, 0x00, 0x40, 0xC1, 0xE3, 0x10, 0x53, 0x55, 0x89, 0x5C, 0x24, 0x3C, 0xE8, 0x69, 0x44, 0x0A, 0x00, 0x8B, 0x54, 0x24, 0x3C, 0x83, 0xC4, 0x08, 0x8B, 0xD8, 0x52, 0x55, 0xF7, 0xDB, 0xE8, 0x8B, 0x44, 0x0A, 0x00, 0x8B, 0x4E, 0x6A, 0x8B, 0x56, 0x6E, 0x8B, 0x76, 0x72, 0x83, 0xC4, 0x08, 0xF7, 0xD8, 0x03, 0xCB, 0x03, 0xF0, 0x6A, 0x36 };
	unsigned char Bytes70[] = { 0x4C };
	unsigned char Bytes71[] = { 0x14, 0x89, 0x54, 0x24, 0x18, 0x89, 0x74, 0x24, 0x1C, 0xE8, 0x53, 0x22, 0x0A, 0x00, 0x83, 0xC4, 0x04, 0x85, 0xC0, 0x74, 0x11, 0x8D, 0x4C, 0x24, 0x10, 0x51, 0x57, 0x8B, 0xC8, 0xE8, 0xFF, 0xB5, 0x03, 0x00, 0x8B, 0xF0, 0xEB, 0x02, 0x33, 0xF6, 0x68, 0x80, 0x00 };
	unsigned char Bytes72[] = { 0x00 };
	unsigned char Bytes73[] = { 0xCE };
	unsigned char Bytes74[] = { 0x4D, 0xBA, 0x03 };
	unsigned char Bytes75[] = { 0x56, 0x8B, 0xCF, 0xE8, 0xE5, 0x5B, 0x02, 0x00, 0xC7, 0x47, 0x06, 0xEA, 0x00, 0x01, 0x00, 0xB8, 0x01, 0x00, 0x00, 0x00, 0xEB, 0x09 };
	unsigned char Bytes76[] = { 0x97 };
	unsigned char Bytes77[] = { 0x8F };
	unsigned char Bytes78[] = { 0x82 };
	unsigned char Bytes79[] = { 0x04 };
	unsigned char Bytes80[] = { 0xC8 };
	unsigned char Bytes81[] = { 0xE5 };
	unsigned char Bytes82[] = { 0xF6, 0x82, 0x47, 0x02, 0x00, 0x00, 0x08, 0x0F, 0x85, 0xD8, 0x00, 0x00, 0x00, 0x8A, 0x54, 0x24, 0x48, 0x8B, 0x8F, 0x96, 0x00, 0x00, 0x00, 0x8D, 0x44, 0x24, 0x34, 0x88, 0x54, 0x24, 0x34, 0x50, 0x33, 0xD2, 0x89, 0x6C, 0x24, 0x3C, 0x89, 0x6C, 0x24, 0x40, 0x89, 0x6C, 0x24, 0x44, 0x8A, 0x91, 0x46, 0x01, 0x00, 0x00, 0x8D, 0x47, 0x6A, 0x68, 0x00, 0x0F, 0x00, 0x00, 0x50, 0x52, 0xE8, 0x42, 0x7A, 0xFF, 0xFF, 0x8B, 0x4C, 0x24, 0x38, 0x3B, 0xCD, 0x75, 0x04 };
	unsigned char Bytes83[] = { 0xC0, 0xEB, 0x09, 0x8B, 0x44, 0x24, 0x3C, 0x2B, 0xC1, 0xC1, 0xF8, 0x02, 0x33, 0xD2, 0x3B, 0xC5, 0x0F, 0x94, 0xC2, 0x84, 0xD2, 0x75, 0x79, 0x55, 0x8B, 0xCE, 0xE8, 0xBA, 0x4D, 0x02, 0x00, 0x8B, 0x5C, 0x24, 0x38, 0x3B, 0xDD, 0x75, 0x04, 0x33, 0xC0, 0xEB, 0x09, 0x8B, 0x44, 0x24, 0x3C, 0x2B, 0xC3, 0xC1, 0xF8, 0x02, 0x50, 0xE8, 0xFF, 0x30, 0x0A, 0x00, 0x8B, 0x2C, 0x83, 0x6A, 0x56, 0xE8, 0xD5, 0x13, 0x0A };
	unsigned char Bytes84[] = { 0x8B, 0xD8, 0x83, 0xC4, 0x04, 0x85, 0xDB, 0x74, 0x1F, 0x6A, 0x00, 0x6A };
	unsigned char Bytes85[] = { 0x6A, 0x00, 0x6A, 0x00, 0x55, 0x51, 0x8B, 0xCC, 0x68, 0x94, 0x1B, 0x50, 0x00, 0xE8, 0x06, 0x4C, 0x02, 0x00, 0x8B, 0xCB, 0xE8, 0x5F, 0x65, 0x02, 0x00, 0xEB, 0x02, 0x33, 0xC0, 0x50, 0x57, 0xE8, 0x44, 0x71, 0x02, 0x00, 0xC7, 0x46, 0x06 };
	unsigned char Bytes86[] = { 0x00, 0x00, 0x00, 0x8B, 0x44, 0x24, 0x38, 0x50, 0xE8, 0xA3, 0x13, 0x0A, 0x00, 0x83, 0xC4, 0x04, 0x33, 0xC0, 0xEB, 0x18, 0x90, 0x90, 0x90, 0x51, 0xE8, 0x93, 0x13, 0x0A };
	unsigned char Bytes87[] = { 0x83, 0xC4, 0x04, 0xB8, 0x02, 0x00, 0x00, 0x00, 0xEB, 0x05, 0xB8, 0x07, 0x00, 0x00, 0x00, 0x5F, 0x5E, 0x5D };
	unsigned char Bytes88[] = { 0xC1, 0xFA, 0x04, 0x8B, 0xC2, 0xC1, 0xE8, 0x1F, 0x03, 0xD0, 0x50 };
	unsigned char Bytes89[] = { 0x10 };
	unsigned char Bytes90[] = { 0xE9, 0x58, 0x01, 0x00, 0x00, 0x8B, 0x74, 0x24, 0x5C, 0x33, 0xC0, 0x33, 0xED, 0x8A, 0x46, 0x05, 0x2B, 0xC5, 0x0F, 0x84, 0xA9, 0x04, 0x00, 0x00, 0x48 };
	unsigned char Bytes91[] = { 0x85, 0x97, 0x05 };
	unsigned char Bytes92[] = { 0xF6, 0xC1, 0xE0, 0x74, 0x09, 0x33, 0xC0, 0xB0, 0x06, 0xE9, 0x32, 0x01, 0x00, 0x00, 0x6A, 0x36, 0xE8, 0xD1, 0xFB, 0x09, 0x00 };
	unsigned char Bytes93[] = { 0x04, 0x3B, 0xC5, 0x74, 0x10, 0x8D, 0x4E, 0x22, 0x51, 0x56, 0x8B, 0xC8, 0xE8, 0x7E, 0x8F, 0x03, 0x00, 0x8B, 0xD8, 0xEB, 0x02, 0x33, 0xDB };
	unsigned char Bytes94[] = { 0x7C, 0x24, 0x58, 0x8B, 0xCB, 0x8B, 0x97, 0x92, 0x00, 0x00, 0x00, 0x0F, 0xBF, 0x82, 0x1C, 0x02, 0x00, 0x00, 0x50, 0xE8, 0x4F, 0x93, 0x03 };
	unsigned char Bytes95[] = { 0x53, 0x8B, 0xCE, 0xE8, 0x57, 0x35, 0x02, 0x00, 0x6A, 0x2D, 0x8B, 0xCE, 0xE8, 0xFE, 0x4A, 0x02, 0x00, 0x8B, 0x46, 0x06, 0x0C, 0xE0, 0x89, 0x46, 0x06, 0x8B, 0x97, 0x92, 0x00 };
	unsigned char Bytes96[] = { 0x00, 0x0F, 0xBF, 0x8F, 0x08, 0x01, 0x00, 0x00 };
	unsigned char Bytes97[] = { 0x82, 0xFA, 0x01 };
	unsigned char Bytes98[] = { 0xC1, 0xE8, 0x02, 0x8D, 0x04, 0x40, 0x3B, 0xC8, 0x0F, 0x83, 0xD2 };
	unsigned char Bytes99[] = { 0x00, 0xF6, 0x82, 0x47, 0x02, 0x00, 0x00, 0x08 };
	unsigned char Bytes100[] = { 0x85 };
	unsigned char Bytes101[] = { 0x7D };
	unsigned char Bytes102[] = { 0x7D };
	unsigned char Bytes103[] = { 0x74 };
	unsigned char Bytes104[] = { 0x2E };
	unsigned char Bytes105[] = { 0x15 };
	unsigned char Bytes106[] = { 0x75, 0x0D, 0xE9, 0x63, 0x01 };
	unsigned char Bytes107[] = { 0x00, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
	unsigned char Bytes108[] = { 0x57 };
	unsigned char Bytes109[] = { 0x00, 0x00 };
	unsigned char Bytes110[] = { 0x4C };
	unsigned char Bytes111[] = { 0x81, 0x42 };
	unsigned char Bytes112[] = { 0xA8, 0x08, 0x74, 0x1F, 0x8B, 0x87, 0x92, 0x00 };
	unsigned char Bytes113[] = { 0xF6, 0x80, 0x42, 0x02, 0x00 };
	unsigned char Bytes114[] = { 0x02, 0x74, 0x10, 0xF6, 0x81, 0x47, 0x02, 0x00 };
	unsigned char Bytes115[] = { 0x08, 0x75, 0x07, 0xB8, 0x0C, 0x00, 0x00, 0x00, 0xEB, 0x23 };
	unsigned char Bytes116[] = { 0x79 };
	unsigned char Bytes117[] = { 0x3A };
	unsigned char Bytes118[] = { 0x2E };
	unsigned char Bytes119[] = { 0x19, 0xB8, 0x78, 0x1B, 0x50 };
	unsigned char Bytes120[] = { 0x8B, 0x8E, 0x42, 0x02, 0x00 };
	unsigned char Bytes121[] = { 0xF6, 0xC1, 0x08, 0x0F, 0x85, 0x76, 0x08, 0x00, 0x00, 0xE9, 0x7F, 0x01, 0x00, 0x00, 0x8B, 0x86, 0x42, 0x02, 0x00, 0x00, 0xA8, 0x08, 0x74, 0x20, 0x85, 0xDB };
	unsigned char Bytes122[] = { 0x1C, 0x8B, 0x97, 0x92, 0x00, 0x00, 0x00, 0xF6, 0x82, 0x42, 0x02, 0x00, 0x00, 0x02, 0x74, 0x0D, 0xF6, 0x86, 0x47 };
	unsigned char Bytes123[] = { 0x00, 0x00, 0x08, 0x0F, 0x84, 0x9B, 0x01, 0x00, 0x00, 0x57, 0x8B, 0xCD, 0xE8, 0x08, 0xA1, 0x04, 0x00, 0x85, 0xC0, 0x74, 0x18, 0x8B, 0x86, 0x42, 0x02, 0x00, 0x00 };
	unsigned char Bytes124[] = { 0x08 };
	unsigned char Bytes125[] = { 0xFF };
	unsigned char Bytes126[] = { 0xF9 };
	unsigned char Bytes127[] = { 0xEA };
	unsigned char Bytes128[] = { 0x0F, 0xBF };
	unsigned char Bytes129[] = { 0x85, 0xC0, 0x74, 0x53, 0x0F, 0xBF, 0x96, 0x08, 0x01, 0x00 };
	unsigned char Bytes130[] = { 0x3B, 0x91, 0xFA, 0x01, 0x00 };
	unsigned char Bytes131[] = { 0x73, 0x44, 0x8B, 0x8E, 0x04, 0x01, 0x00, 0x00, 0x85, 0xC9, 0x75, 0x3A, 0x8B, 0x0D, 0xE8, 0x1D, 0x51, 0x00, 0x84, 0x81, 0x47, 0x8A, 0x03, 0x00, 0x75, 0x2C, 0x90, 0xC1, 0xE0, 0x03, 0x8B, 0xC8, 0xB8, 0x89, 0x88, 0x88, 0x88, 0xF7, 0xE9, 0x03, 0xD1, 0x51, 0xC1, 0xFA, 0x02, 0x8B, 0xC2, 0xC1, 0xE8, 0x1F, 0x03, 0xD0, 0x89, 0x54 };
	unsigned char Bytes132[] = { 0xDB, 0x44 };
	unsigned char Bytes133[] = { 0x20, 0xD9, 0x1C, 0x24, 0x56, 0x56, 0xE8, 0x75, 0x0D, 0xF9, 0xFF, 0x56, 0xE8, 0x1F, 0x08, 0xFB, 0xFF, 0x56, 0xE8, 0x29, 0x0B, 0xFB, 0xFF, 0x8B, 0x0E, 0x85, 0xC9, 0x74, 0x0C, 0x56, 0xE8, 0x6D, 0x2D, 0xFB, 0xFF, 0x56, 0xE8, 0xB7, 0xF8, 0xFF, 0xFF };
	unsigned char Bytes134[] = { 0x5C, 0x24, 0x18, 0x8B, 0x86, 0x11, 0x01, 0x00, 0x00, 0xA8, 0x40 };
	unsigned char Bytes135[] = { 0x27 };
	unsigned char Bytes136[] = { 0x24 };
	unsigned char Bytes137[] = { 0x0D };
	unsigned char Bytes138[] = { 0x75 };
	unsigned char Bytes139[] = { 0x04 };
	unsigned char Bytes140[] = { 0x70, 0xDB };
	unsigned char Bytes141[] = { 0x13 };
	unsigned char Bytes142[] = { 0x80, 0xD5 };
	unsigned char Bytes143[] = { 0x09 };
	unsigned char Bytes144[] = { 0x03 };
	unsigned char Bytes145[] = { 0xE9, 0xE3, 0xDE, 0x02, 0x00, 0x90, 0x90, 0x90 };
	unsigned char Bytes146[] = { 0x3B, 0xC3, 0x0F, 0x85, 0xF8, 0x21, 0xFD, 0xFF, 0xC7, 0x44, 0x24, 0x30, 0x31, 0x37 };
	unsigned char Bytes147[] = { 0xE9, 0x0D, 0x21, 0xFD, 0xFF };
	unsigned char Bytes148[] = { 0xD4 };
	unsigned char Bytes149[] = { 0x45 };
	unsigned char Bytes150[] = { 0x45, 0x4D, 0x55, 0x53, 0x49 };
	unsigned char Bytes151[] = { 0x45 };
	unsigned char Bytes152[] = { 0x02 };
	unsigned char Bytes153[] = { 0x02 };
	unsigned char Bytes154[] = { 0x45 };
	unsigned char Bytes155[] = { 0x54, 0x41, 0x45 };
	unsigned char Bytes156[] = { 0x53, 0x43 };
	unsigned char Bytes157[] = { 0x5C };
	unsigned char Bytes158[] = { 0x39, 0x2E, 0x33, 0x2E, 0x31 };
	unsigned char Bytes159[] = { 0x45 };
	unsigned char Bytes160[] = { 0x73, 0x45 };
	unsigned char Bytes161[] = { 0x45 };
	unsigned char Bytes162[] = { 0x77 };
	unsigned char Bytes163[] = { 0x45 };
	unsigned char Bytes164[] = { 0x77 };
	unsigned char Bytes165[] = { 0x45 };
	unsigned char Bytes166[] = { 0x45 };
	unsigned char Bytes167[] = { 0x45 };
	unsigned char Bytes168[] = { 0x45 };
	unsigned char Bytes169[] = { 0x45 };
	unsigned char Bytes170[] = { 0x45 };
	unsigned char Bytes171[] = { 0x45 };
	unsigned char Bytes172[] = { 0x61, 0x65, 0x73, 0x63, 0x2E, 0x69, 0x6E, 0x69, 0x00 };
	unsigned char Bytes173[] = { 0x54, 0x41, 0x20, 0x45, 0x73, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
	unsigned char Bytes174[] = { 0x54, 0x41, 0x20, 0x45, 0x73, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	for (int i = 0; i < 11; i++) { Patch5.push_back(Bytes5[i]); }
	for (int i = 0; i < 9; i++) { Patch6.push_back(Bytes6[i]); }
	for (int i = 0; i < 9; i++) { Patch7.push_back(Bytes7[i]); }
	for (int i = 0; i < 1; i++) { Patch8.push_back(Bytes8[i]); }
	for (int i = 0; i < 2; i++) { Patch9.push_back(Bytes9[i]); }
	for (int i = 0; i < 1; i++) { Patch10.push_back(Bytes10[i]); }
	for (int i = 0; i < 2; i++) { Patch11.push_back(Bytes11[i]); }
	for (int i = 0; i < 1; i++) { Patch12.push_back(Bytes12[i]); }
	for (int i = 0; i < 2; i++) { Patch13.push_back(Bytes13[i]); }
	for (int i = 0; i < 2; i++) { Patch14.push_back(Bytes14[i]); }
	for (int i = 0; i < 1; i++) { Patch15.push_back(Bytes15[i]); }
	for (int i = 0; i < 12; i++) { Patch16.push_back(Bytes16[i]); }
	for (int i = 0; i < 42; i++) { Patch17.push_back(Bytes17[i]); }
	for (int i = 0; i < 1; i++) { Patch18.push_back(Bytes18[i]); }
	for (int i = 0; i < 1; i++) { Patch19.push_back(Bytes19[i]); }
	for (int i = 0; i < 43; i++) { Patch20.push_back(Bytes20[i]); }
	for (int i = 0; i < 14; i++) { Patch21.push_back(Bytes21[i]); }
	for (int i = 0; i < 4; i++) { Patch22.push_back(Bytes22[i]); }
	for (int i = 0; i < 7; i++) { Patch23.push_back(Bytes23[i]); }
	for (int i = 0; i < 9; i++) { Patch24.push_back(Bytes24[i]); }
	for (int i = 0; i < 7; i++) { Patch25.push_back(Bytes25[i]); }
	for (int i = 0; i < 3; i++) { Patch26.push_back(Bytes26[i]); }
	for (int i = 0; i < 1; i++) { Patch27.push_back(Bytes27[i]); }
	for (int i = 0; i < 3; i++) { Patch28.push_back(Bytes28[i]); }
	for (int i = 0; i < 13; i++) { Patch29.push_back(Bytes29[i]); }
	for (int i = 0; i < 5; i++) { Patch30.push_back(Bytes30[i]); }
	for (int i = 0; i < 41; i++) { Patch31.push_back(Bytes31[i]); }
	for (int i = 0; i < 2; i++) { Patch32.push_back(Bytes32[i]); }
	for (int i = 0; i < 1; i++) { Patch33.push_back(Bytes33[i]); }
	for (int i = 0; i < 3; i++) { Patch34.push_back(Bytes34[i]); }
	for (int i = 0; i < 33; i++) { Patch35.push_back(Bytes35[i]); }
	for (int i = 0; i < 39; i++) { Patch36.push_back(Bytes36[i]); }
	for (int i = 0; i < 18; i++) { Patch37.push_back(Bytes37[i]); }
	for (int i = 0; i < 1; i++) { Patch38.push_back(Bytes38[i]); }
	for (int i = 0; i < 3; i++) { Patch39.push_back(Bytes39[i]); }
	for (int i = 0; i < 64; i++) { Patch40.push_back(Bytes40[i]); }
	for (int i = 0; i < 18; i++) { Patch41.push_back(Bytes41[i]); }
	for (int i = 0; i < 4; i++) { Patch42.push_back(Bytes42[i]); }
	for (int i = 0; i < 120; i++) { Patch43.push_back(Bytes43[i]); }
	for (int i = 0; i < 59; i++) { Patch44.push_back(Bytes44[i]); }
	for (int i = 0; i < 9; i++) { Patch45.push_back(Bytes45[i]); }
	for (int i = 0; i < 1; i++) { Patch46.push_back(Bytes46[i]); }
	for (int i = 0; i < 18; i++) { Patch47.push_back(Bytes47[i]); }
	for (int i = 0; i < 1; i++) { Patch48.push_back(Bytes48[i]); }
	for (int i = 0; i < 1; i++) { Patch49.push_back(Bytes49[i]); }
	for (int i = 0; i < 1; i++) { Patch50.push_back(Bytes50[i]); }
	for (int i = 0; i < 68; i++) { Patch51.push_back(Bytes51[i]); }
	for (int i = 0; i < 5; i++) { Patch52.push_back(Bytes52[i]); }
	for (int i = 0; i < 33; i++) { Patch53.push_back(Bytes53[i]); }
	for (int i = 0; i < 34; i++) { Patch54.push_back(Bytes54[i]); }
	for (int i = 0; i < 12; i++) { Patch55.push_back(Bytes55[i]); }
	for (int i = 0; i < 39; i++) { Patch56.push_back(Bytes56[i]); }
	for (int i = 0; i < 15; i++) { Patch57.push_back(Bytes57[i]); }
	for (int i = 0; i < 1; i++) { Patch58.push_back(Bytes58[i]); }
	for (int i = 0; i < 1; i++) { Patch59.push_back(Bytes59[i]); }
	for (int i = 0; i < 1; i++) { Patch60.push_back(Bytes60[i]); }
	for (int i = 0; i < 23; i++) { Patch61.push_back(Bytes61[i]); }
	for (int i = 0; i < 45; i++) { Patch62.push_back(Bytes62[i]); }
	for (int i = 0; i < 5; i++) { Patch63.push_back(Bytes63[i]); }
	for (int i = 0; i < 38; i++) { Patch64.push_back(Bytes64[i]); }
	for (int i = 0; i < 33; i++) { Patch65.push_back(Bytes65[i]); }
	for (int i = 0; i < 12; i++) { Patch66.push_back(Bytes66[i]); }
	for (int i = 0; i < 79; i++) { Patch67.push_back(Bytes67[i]); }
	for (int i = 0; i < 18; i++) { Patch68.push_back(Bytes68[i]); }
	for (int i = 0; i < 71; i++) { Patch69.push_back(Bytes69[i]); }
	for (int i = 0; i < 1; i++) { Patch70.push_back(Bytes70[i]); }
	for (int i = 0; i < 43; i++) { Patch71.push_back(Bytes71[i]); }
	for (int i = 0; i < 1; i++) { Patch72.push_back(Bytes72[i]); }
	for (int i = 0; i < 1; i++) { Patch73.push_back(Bytes73[i]); }
	for (int i = 0; i < 3; i++) { Patch74.push_back(Bytes74[i]); }
	for (int i = 0; i < 22; i++) { Patch75.push_back(Bytes75[i]); }
	for (int i = 0; i < 1; i++) { Patch76.push_back(Bytes76[i]); }
	for (int i = 0; i < 1; i++) { Patch77.push_back(Bytes77[i]); }
	for (int i = 0; i < 1; i++) { Patch78.push_back(Bytes78[i]); }
	for (int i = 0; i < 1; i++) { Patch79.push_back(Bytes79[i]); }
	for (int i = 0; i < 1; i++) { Patch80.push_back(Bytes80[i]); }
	for (int i = 0; i < 1; i++) { Patch81.push_back(Bytes81[i]); }
	for (int i = 0; i < 75; i++) { Patch82.push_back(Bytes82[i]); }
	for (int i = 0; i < 67; i++) { Patch83.push_back(Bytes83[i]); }
	for (int i = 0; i < 12; i++) { Patch84.push_back(Bytes84[i]); }
	for (int i = 0; i < 39; i++) { Patch85.push_back(Bytes85[i]); }
	for (int i = 0; i < 28; i++) { Patch86.push_back(Bytes86[i]); }
	for (int i = 0; i < 18; i++) { Patch87.push_back(Bytes87[i]); }
	for (int i = 0; i < 11; i++) { Patch88.push_back(Bytes88[i]); }
	for (int i = 0; i < 1; i++) { Patch89.push_back(Bytes89[i]); }
	for (int i = 0; i < 25; i++) { Patch90.push_back(Bytes90[i]); }
	for (int i = 0; i < 3; i++) { Patch91.push_back(Bytes91[i]); }
	for (int i = 0; i < 21; i++) { Patch92.push_back(Bytes92[i]); }
	for (int i = 0; i < 23; i++) { Patch93.push_back(Bytes93[i]); }
	for (int i = 0; i < 23; i++) { Patch94.push_back(Bytes94[i]); }
	for (int i = 0; i < 29; i++) { Patch95.push_back(Bytes95[i]); }
	for (int i = 0; i < 8; i++) { Patch96.push_back(Bytes96[i]); }
	for (int i = 0; i < 3; i++) { Patch97.push_back(Bytes97[i]); }
	for (int i = 0; i < 11; i++) { Patch98.push_back(Bytes98[i]); }
	for (int i = 0; i < 8; i++) { Patch99.push_back(Bytes99[i]); }
	for (int i = 0; i < 1; i++) { Patch100.push_back(Bytes100[i]); }
	for (int i = 0; i < 1; i++) { Patch101.push_back(Bytes101[i]); }
	for (int i = 0; i < 1; i++) { Patch102.push_back(Bytes102[i]); }
	for (int i = 0; i < 1; i++) { Patch103.push_back(Bytes103[i]); }
	for (int i = 0; i < 1; i++) { Patch104.push_back(Bytes104[i]); }
	for (int i = 0; i < 1; i++) { Patch105.push_back(Bytes105[i]); }
	for (int i = 0; i < 5; i++) { Patch106.push_back(Bytes106[i]); }
	for (int i = 0; i < 9; i++) { Patch107.push_back(Bytes107[i]); }
	for (int i = 0; i < 1; i++) { Patch108.push_back(Bytes108[i]); }
	for (int i = 0; i < 2; i++) { Patch109.push_back(Bytes109[i]); }
	for (int i = 0; i < 1; i++) { Patch110.push_back(Bytes110[i]); }
	for (int i = 0; i < 2; i++) { Patch111.push_back(Bytes111[i]); }
	for (int i = 0; i < 8; i++) { Patch112.push_back(Bytes112[i]); }
	for (int i = 0; i < 5; i++) { Patch113.push_back(Bytes113[i]); }
	for (int i = 0; i < 8; i++) { Patch114.push_back(Bytes114[i]); }
	for (int i = 0; i < 10; i++) { Patch115.push_back(Bytes115[i]); }
	for (int i = 0; i < 1; i++) { Patch116.push_back(Bytes116[i]); }
	for (int i = 0; i < 1; i++) { Patch117.push_back(Bytes117[i]); }
	for (int i = 0; i < 1; i++) { Patch118.push_back(Bytes118[i]); }
	for (int i = 0; i < 5; i++) { Patch119.push_back(Bytes119[i]); }
	for (int i = 0; i < 5; i++) { Patch120.push_back(Bytes120[i]); }
	for (int i = 0; i < 26; i++) { Patch121.push_back(Bytes121[i]); }
	for (int i = 0; i < 19; i++) { Patch122.push_back(Bytes122[i]); }
	for (int i = 0; i < 27; i++) { Patch123.push_back(Bytes123[i]); }
	for (int i = 0; i < 1; i++) { Patch124.push_back(Bytes124[i]); }
	for (int i = 0; i < 1; i++) { Patch125.push_back(Bytes125[i]); }
	for (int i = 0; i < 1; i++) { Patch126.push_back(Bytes126[i]); }
	for (int i = 0; i < 1; i++) { Patch127.push_back(Bytes127[i]); }
	for (int i = 0; i < 2; i++) { Patch128.push_back(Bytes128[i]); }
	for (int i = 0; i < 10; i++) { Patch129.push_back(Bytes129[i]); }
	for (int i = 0; i < 5; i++) { Patch130.push_back(Bytes130[i]); }
	for (int i = 0; i < 54; i++) { Patch131.push_back(Bytes131[i]); }
	for (int i = 0; i < 2; i++) { Patch132.push_back(Bytes132[i]); }
	for (int i = 0; i < 41; i++) { Patch133.push_back(Bytes133[i]); }
	for (int i = 0; i < 11; i++) { Patch134.push_back(Bytes134[i]); }
	for (int i = 0; i < 1; i++) { Patch135.push_back(Bytes135[i]); }
	for (int i = 0; i < 1; i++) { Patch136.push_back(Bytes136[i]); }
	for (int i = 0; i < 1; i++) { Patch137.push_back(Bytes137[i]); }
	for (int i = 0; i < 1; i++) { Patch138.push_back(Bytes138[i]); }
	for (int i = 0; i < 1; i++) { Patch139.push_back(Bytes139[i]); }
	for (int i = 0; i < 2; i++) { Patch140.push_back(Bytes140[i]); }
	for (int i = 0; i < 1; i++) { Patch141.push_back(Bytes141[i]); }
	for (int i = 0; i < 2; i++) { Patch142.push_back(Bytes142[i]); }
	for (int i = 0; i < 1; i++) { Patch143.push_back(Bytes143[i]); }
	for (int i = 0; i < 1; i++) { Patch144.push_back(Bytes144[i]); }
	for (int i = 0; i < 8; i++) { Patch145.push_back(Bytes145[i]); }
	for (int i = 0; i < 14; i++) { Patch146.push_back(Bytes146[i]); }
	for (int i = 0; i < 5; i++) { Patch147.push_back(Bytes147[i]); }
	for (int i = 0; i < 1; i++) { Patch148.push_back(Bytes148[i]); }
	for (int i = 0; i < 1; i++) { Patch149.push_back(Bytes149[i]); }
	for (int i = 0; i < 5; i++) { Patch150.push_back(Bytes150[i]); }
	for (int i = 0; i < 1; i++) { Patch151.push_back(Bytes151[i]); }
	for (int i = 0; i < 1; i++) { Patch152.push_back(Bytes152[i]); }
	for (int i = 0; i < 1; i++) { Patch153.push_back(Bytes153[i]); }
	for (int i = 0; i < 1; i++) { Patch154.push_back(Bytes154[i]); }
	for (int i = 0; i < 3; i++) { Patch155.push_back(Bytes155[i]); }
	for (int i = 0; i < 2; i++) { Patch156.push_back(Bytes156[i]); }
	for (int i = 0; i < 1; i++) { Patch157.push_back(Bytes157[i]); }
	for (int i = 0; i < 5; i++) { Patch158.push_back(Bytes158[i]); }
	for (int i = 0; i < 1; i++) { Patch159.push_back(Bytes159[i]); }
	for (int i = 0; i < 2; i++) { Patch160.push_back(Bytes160[i]); }
	for (int i = 0; i < 1; i++) { Patch161.push_back(Bytes161[i]); }
	for (int i = 0; i < 1; i++) { Patch162.push_back(Bytes162[i]); }
	for (int i = 0; i < 1; i++) { Patch163.push_back(Bytes163[i]); }
	for (int i = 0; i < 1; i++) { Patch164.push_back(Bytes164[i]); }
	for (int i = 0; i < 1; i++) { Patch165.push_back(Bytes165[i]); }
	for (int i = 0; i < 1; i++) { Patch166.push_back(Bytes166[i]); }
	for (int i = 0; i < 1; i++) { Patch167.push_back(Bytes167[i]); }
	for (int i = 0; i < 1; i++) { Patch168.push_back(Bytes168[i]); }
	for (int i = 0; i < 1; i++) { Patch169.push_back(Bytes169[i]); }
	for (int i = 0; i < 1; i++) { Patch170.push_back(Bytes170[i]); }
	for (int i = 0; i < 1; i++) { Patch171.push_back(Bytes171[i]); }
	for (int i = 0; i < 9; i++) { Patch172.push_back(Bytes172[i]); }
	for (int i = 0; i < 21; i++) { Patch173.push_back(Bytes173[i]); }
	for (int i = 0; i < 21; i++) { Patch174.push_back(Bytes174[i]); }

	Variables::Escalation[5] = Patching::Patch(0x00402608, Patch5, true);
	Variables::Escalation[6] = Patching::Patch(0x004035EE, Patch6, true);
	Variables::Escalation[7] = Patching::Patch(0x004037E0, Patch7, true);
	Variables::Escalation[8] = Patching::Patch(0x00403976, Patch8, true);
	Variables::Escalation[9] = Patching::Patch(0x00403D29, Patch9, true);
	Variables::Escalation[10] = Patching::Patch(0x004040B9, Patch10, true);
	Variables::Escalation[11] = Patching::Patch(0x0040440B, Patch11, true);
	Variables::Escalation[12] = Patching::Patch(0x004047CB, Patch12, true);
	Variables::Escalation[13] = Patching::Patch(0x0040554B, Patch13, true);
	Variables::Escalation[14] = Patching::Patch(0x00406FB4, Patch14, true);
	Variables::Escalation[15] = Patching::Patch(0x00408A28, Patch15, true);
	Variables::Escalation[16] = Patching::Patch(0x00408A2C, Patch16, true);
	Variables::Escalation[17] = Patching::Patch(0x00408A3A, Patch17, true);
	Variables::Escalation[18] = Patching::Patch(0x00408A69, Patch18, true);
	Variables::Escalation[19] = Patching::Patch(0x00408A6B, Patch19, true);
	Variables::Escalation[20] = Patching::Patch(0x00408A70, Patch20, true);
	Variables::Escalation[21] = Patching::Patch(0x00408A9C, Patch21, true);
	Variables::Escalation[22] = Patching::Patch(0x00408AAB, Patch22, true);
	Variables::Escalation[23] = Patching::Patch(0x00408AB1, Patch23, true);
	Variables::Escalation[24] = Patching::Patch(0x00408AB9, Patch24, true);
	Variables::Escalation[25] = Patching::Patch(0x00408AC4, Patch25, true);
	Variables::Escalation[26] = Patching::Patch(0x00408ACD, Patch26, true);
	Variables::Escalation[27] = Patching::Patch(0x00408BA2, Patch27, true);
	Variables::Escalation[28] = Patching::Patch(0x0040EAD6, Patch28, true);
	Variables::Escalation[29] = Patching::Patch(0x0040FD57, Patch29, true);
	Variables::Escalation[30] = Patching::Patch(0x0040FD65, Patch30, true);
	Variables::Escalation[31] = Patching::Patch(0x0040FD6B, Patch31, true);
	Variables::Escalation[32] = Patching::Patch(0x0040FD95, Patch32, true);
	Variables::Escalation[33] = Patching::Patch(0x00410419, Patch33, true);
	Variables::Escalation[34] = Patching::Patch(0x004104E7, Patch34, true);
	Variables::Escalation[35] = Patching::Patch(0x004104EC, Patch35, true);
	Variables::Escalation[36] = Patching::Patch(0x0041050E, Patch36, true);
	Variables::Escalation[37] = Patching::Patch(0x00410815, Patch37, true);
	Variables::Escalation[38] = Patching::Patch(0x00410889, Patch38, true);
	Variables::Escalation[39] = Patching::Patch(0x0041094A, Patch39, true);
	Variables::Escalation[40] = Patching::Patch(0x0041094F, Patch40, true);
	Variables::Escalation[41] = Patching::Patch(0x00410C52, Patch41, true);
	Variables::Escalation[42] = Patching::Patch(0x00410E9C, Patch42, true);
	Variables::Escalation[43] = Patching::Patch(0x00410EA2, Patch43, true);
	Variables::Escalation[44] = Patching::Patch(0x00410F1C, Patch44, true);
	Variables::Escalation[45] = Patching::Patch(0x00410F58, Patch45, true);
	Variables::Escalation[46] = Patching::Patch(0x00410F62, Patch46, true);
	Variables::Escalation[47] = Patching::Patch(0x0041118F, Patch47, true);
	Variables::Escalation[48] = Patching::Patch(0x00411C38, Patch48, true);
	Variables::Escalation[49] = Patching::Patch(0x00411D34, Patch49, true);
	Variables::Escalation[50] = Patching::Patch(0x00411DFF, Patch50, true);
	Variables::Escalation[51] = Patching::Patch(0x004125E3, Patch51, true);
	Variables::Escalation[52] = Patching::Patch(0x00412628, Patch52, true);
	Variables::Escalation[53] = Patching::Patch(0x0041262E, Patch53, true);
	Variables::Escalation[54] = Patching::Patch(0x00412650, Patch54, true);
	Variables::Escalation[55] = Patching::Patch(0x00412673, Patch55, true);
	Variables::Escalation[56] = Patching::Patch(0x00412680, Patch56, true);
	Variables::Escalation[57] = Patching::Patch(0x004126A8, Patch57, true);
	Variables::Escalation[58] = Patching::Patch(0x00412912, Patch58, true);
	Variables::Escalation[59] = Patching::Patch(0x00412B3B, Patch59, true);
	Variables::Escalation[60] = Patching::Patch(0x00412B5C, Patch60, true);
	Variables::Escalation[61] = Patching::Patch(0x00412B60, Patch61, true);
	Variables::Escalation[62] = Patching::Patch(0x00412B78, Patch62, true);
	Variables::Escalation[63] = Patching::Patch(0x00412BA6, Patch63, true);
	Variables::Escalation[64] = Patching::Patch(0x00412BAC, Patch64, true);
	Variables::Escalation[65] = Patching::Patch(0x00412BD3, Patch65, true);
	Variables::Escalation[66] = Patching::Patch(0x00412BF5, Patch66, true);
	Variables::Escalation[67] = Patching::Patch(0x00412C02, Patch67, true);
	Variables::Escalation[68] = Patching::Patch(0x00412C52, Patch68, true);
	Variables::Escalation[69] = Patching::Patch(0x00412C65, Patch69, true);
	Variables::Escalation[70] = Patching::Patch(0x00412CAD, Patch70, true);
	Variables::Escalation[71] = Patching::Patch(0x00412CAF, Patch71, true);
	Variables::Escalation[72] = Patching::Patch(0x00412CDB, Patch72, true);
	Variables::Escalation[73] = Patching::Patch(0x00412CDD, Patch73, true);
	Variables::Escalation[74] = Patching::Patch(0x00412CDF, Patch74, true);
	Variables::Escalation[75] = Patching::Patch(0x00412CE3, Patch75, true);
	Variables::Escalation[76] = Patching::Patch(0x00413A8B, Patch76, true);
	Variables::Escalation[77] = Patching::Patch(0x00413A92, Patch77, true);
	Variables::Escalation[78] = Patching::Patch(0x00413A98, Patch78, true);
	Variables::Escalation[79] = Patching::Patch(0x00413AA1, Patch79, true);
	Variables::Escalation[80] = Patching::Patch(0x00413AA4, Patch80, true);
	Variables::Escalation[81] = Patching::Patch(0x00413AA7, Patch81, true);
	Variables::Escalation[82] = Patching::Patch(0x00413AAB, Patch82, true);
	Variables::Escalation[83] = Patching::Patch(0x00413AF7, Patch83, true);
	Variables::Escalation[84] = Patching::Patch(0x00413B3B, Patch84, true);
	Variables::Escalation[85] = Patching::Patch(0x00413B48, Patch85, true);
	Variables::Escalation[86] = Patching::Patch(0x00413B70, Patch86, true);
	Variables::Escalation[87] = Patching::Patch(0x00413B8D, Patch87, true);
	Variables::Escalation[88] = Patching::Patch(0x00415125, Patch88, true);
	Variables::Escalation[89] = Patching::Patch(0x004152FF, Patch89, true);
	Variables::Escalation[90] = Patching::Patch(0x0041530B, Patch90, true);
	Variables::Escalation[91] = Patching::Patch(0x00415325, Patch91, true);
	Variables::Escalation[92] = Patching::Patch(0x0041532A, Patch92, true);
	Variables::Escalation[93] = Patching::Patch(0x00415341, Patch93, true);
	Variables::Escalation[94] = Patching::Patch(0x00415359, Patch94, true);
	Variables::Escalation[95] = Patching::Patch(0x00415371, Patch95, true);
	Variables::Escalation[96] = Patching::Patch(0x0041538F, Patch96, true);
	Variables::Escalation[97] = Patching::Patch(0x00415398, Patch97, true);
	Variables::Escalation[98] = Patching::Patch(0x0041539D, Patch98, true);
	Variables::Escalation[99] = Patching::Patch(0x004153AA, Patch99, true);
	Variables::Escalation[100] = Patching::Patch(0x004153B3, Patch100, true);
	Variables::Escalation[101] = Patching::Patch(0x0041BD90, Patch101, true);
	Variables::Escalation[102] = Patching::Patch(0x0041BD9A, Patch102, true);
	Variables::Escalation[103] = Patching::Patch(0x0041D6B0, Patch103, true);
	Variables::Escalation[104] = Patching::Patch(0x0041D6B3, Patch104, true);
	Variables::Escalation[105] = Patching::Patch(0x0041DD4B, Patch105, true);
	Variables::Escalation[106] = Patching::Patch(0x0041DD52, Patch106, true);
	Variables::Escalation[107] = Patching::Patch(0x0041DD58, Patch107, true);
	Variables::Escalation[108] = Patching::Patch(0x0043949F, Patch108, true);
	Variables::Escalation[109] = Patching::Patch(0x0043E786, Patch109, true);
	Variables::Escalation[110] = Patching::Patch(0x0043EA80, Patch110, true);
	Variables::Escalation[111] = Patching::Patch(0x0043EA84, Patch111, true);
	Variables::Escalation[112] = Patching::Patch(0x0043EA89, Patch112, true);
	Variables::Escalation[113] = Patching::Patch(0x0043EA93, Patch113, true);
	Variables::Escalation[114] = Patching::Patch(0x0043EA99, Patch114, true);
	Variables::Escalation[115] = Patching::Patch(0x0043EAA2, Patch115, true);
	Variables::Escalation[116] = Patching::Patch(0x0043F8DC, Patch116, true);
	Variables::Escalation[117] = Patching::Patch(0x0043F91B, Patch117, true);
	Variables::Escalation[118] = Patching::Patch(0x0043F927, Patch118, true);
	Variables::Escalation[119] = Patching::Patch(0x0043F93C, Patch119, true);
	Variables::Escalation[120] = Patching::Patch(0x0043F942, Patch120, true);
	Variables::Escalation[121] = Patching::Patch(0x0043F948, Patch121, true);
	Variables::Escalation[122] = Patching::Patch(0x0043F963, Patch122, true);
	Variables::Escalation[123] = Patching::Patch(0x0043F977, Patch123, true);
	Variables::Escalation[124] = Patching::Patch(0x0043F993, Patch124, true);
	Variables::Escalation[125] = Patching::Patch(0x00446E4D, Patch125, true);
	Variables::Escalation[126] = Patching::Patch(0x0048AEC0, Patch126, true);
	Variables::Escalation[127] = Patching::Patch(0x0048AECF, Patch127, true);
	Variables::Escalation[128] = Patching::Patch(0x0048AF3D, Patch128, true);
	Variables::Escalation[129] = Patching::Patch(0x0048AF44, Patch129, true);
	Variables::Escalation[130] = Patching::Patch(0x0048AF4F, Patch130, true);
	Variables::Escalation[131] = Patching::Patch(0x0048AF55, Patch131, true);
	Variables::Escalation[132] = Patching::Patch(0x0048AF8D, Patch132, true);
	Variables::Escalation[133] = Patching::Patch(0x0048AF90, Patch133, true);
	Variables::Escalation[134] = Patching::Patch(0x0048AFBA, Patch134, true);

	Variables::Escalation[135] = Patching::Patch(0x004966E7, Patch135, true);
	Variables::Escalation[136] = Patching::Patch(0x00496776, Patch136, true);
	Variables::Escalation[137] = Patching::Patch(0x00496779, Patch137, true);
	Variables::Escalation[138] = Patching::Patch(0x0049AA53, Patch138, true);
	Variables::Escalation[139] = Patching::Patch(0x0049E01E, Patch139, true);
	Variables::Escalation[140] = Patching::Patch(0x0049E027, Patch140, true);
	Variables::Escalation[141] = Patching::Patch(0x0049E032, Patch141, true);
	Variables::Escalation[142] = Patching::Patch(0x0049E03B, Patch142, true);
	Variables::Escalation[143] = Patching::Patch(0x0049E9C0, Patch143, true);
	Variables::Escalation[144] = Patching::Patch(0x0049E9C9, Patch144, true);
	//Variables::Escalation[145] = Patching::Patch(0x004CDA44, Patch145, true);
	//Variables::Escalation[146] = Patching::Patch(0x004FB92A, Patch146, true);
	//Variables::Escalation[147] = Patching::Patch(0x004FB93A, Patch147, true);


	Variables::Escalation[148] = Patching::Patch(0x004FCC7F, Patch148, true);
	//Variables::Escalation[149] = Patching::Patch(0x004FF618, Patch149, true);
	//Variables::Escalation[150] = Patching::Patch(0x004FF642, Patch150, true);
	//Variables::Escalation[151] = Patching::Patch(0x004FF9E4, Patch151, true);


	Variables::Escalation[152] = Patching::Patch(0x00501FD8, Patch152, true);
	Variables::Escalation[153] = Patching::Patch(0x00501FE4, Patch153, true);
	Variables::Escalation[154] = Patching::Patch(0x00502823, Patch154, true);
	Variables::Escalation[155] = Patching::Patch(0x005028CC, Patch155, true);
	Variables::Escalation[156] = Patching::Patch(0x005028D8, Patch156, true);
	Variables::Escalation[157] = Patching::Patch(0x00502916, Patch157, true);
	Variables::Escalation[158] = Patching::Patch(0x005031B4, Patch158, true);
	Variables::Escalation[159] = Patching::Patch(0x00503367, Patch159, true);
	Variables::Escalation[160] = Patching::Patch(0x00503738, Patch160, true);
	Variables::Escalation[161] = Patching::Patch(0x00503925, Patch161, true);
	Variables::Escalation[162] = Patching::Patch(0x0050392C, Patch162, true);
	Variables::Escalation[163] = Patching::Patch(0x00503932, Patch163, true);
	Variables::Escalation[164] = Patching::Patch(0x00503934, Patch164, true);
	Variables::Escalation[165] = Patching::Patch(0x0050393A, Patch165, true);
	Variables::Escalation[166] = Patching::Patch(0x00503F12, Patch166, true);
	Variables::Escalation[167] = Patching::Patch(0x0050475E, Patch167, true);
	Variables::Escalation[168] = Patching::Patch(0x00504B11, Patch168, true);
	Variables::Escalation[169] = Patching::Patch(0x00505FEB, Patch169, true);
	Variables::Escalation[170] = Patching::Patch(0x00507309, Patch170, true);
	Variables::Escalation[171] = Patching::Patch(0x005097D7, Patch171, true);
	Variables::Escalation[172] = Patching::Patch(0x005098A4, Patch172, true);
	Variables::Escalation[173] = Patching::Patch(0x00509EB8, Patch173, true);
	Variables::Escalation[174] = Patching::Patch(0x0050DDFD, Patch174, true);
}

#endif

#ifdef MAYHEM_MOD

void Valkyrie::Mods::Mayhem::HexEdits()
{
	std::vector<unsigned char> Patch1;
	std::vector<unsigned char> Patch2;
	std::vector<unsigned char> Patch3;
	std::vector<unsigned char> Patch4;
	std::vector<unsigned char> Patch5;
	std::vector<unsigned char> Patch6;
	std::vector<unsigned char> Patch7;
	std::vector<unsigned char> Patch8;
	std::vector<unsigned char> Patch9;
	std::vector<unsigned char> Patch10;
	std::vector<unsigned char> Patch11;
	std::vector<unsigned char> Patch12;
	std::vector<unsigned char> Patch13;
	std::vector<unsigned char> Patch14;
	std::vector<unsigned char> Patch15;
	std::vector<unsigned char> Patch16;
	std::vector<unsigned char> Patch17;
	std::vector<unsigned char> Patch18;
	std::vector<unsigned char> Patch19;
	std::vector<unsigned char> Patch20;
	std::vector<unsigned char> Patch21;
	std::vector<unsigned char> Patch22;
	std::vector<unsigned char> Patch23;
	std::vector<unsigned char> Patch24;
	std::vector<unsigned char> Patch25;
	std::vector<unsigned char> Patch26;
	std::vector<unsigned char> Patch27;
	std::vector<unsigned char> Patch28;
	std::vector<unsigned char> Patch29;
	std::vector<unsigned char> Patch30;
	std::vector<unsigned char> Patch31;
	std::vector<unsigned char> Patch32;
	std::vector<unsigned char> Patch33;
	std::vector<unsigned char> Patch34;
	std::vector<unsigned char> Patch35;
	std::vector<unsigned char> Patch36;
	std::vector<unsigned char> Patch37;
	std::vector<unsigned char> Patch38;
	std::vector<unsigned char> Patch39;
	std::vector<unsigned char> Patch40;
	std::vector<unsigned char> Patch41;
	std::vector<unsigned char> Patch42;
	std::vector<unsigned char> Patch43;
	std::vector<unsigned char> Patch44;
	std::vector<unsigned char> Patch45;
	std::vector<unsigned char> Patch46;
	std::vector<unsigned char> Patch47;
	std::vector<unsigned char> Patch48;
	std::vector<unsigned char> Patch49;
	std::vector<unsigned char> Patch50;
	std::vector<unsigned char> Patch51;
	std::vector<unsigned char> Patch52;
	std::vector<unsigned char> Patch53;
	std::vector<unsigned char> Patch54;
	std::vector<unsigned char> Patch55;
	std::vector<unsigned char> Patch56;
	std::vector<unsigned char> Patch57;
	std::vector<unsigned char> Patch58;
	std::vector<unsigned char> Patch59;
	std::vector<unsigned char> Patch60;
	std::vector<unsigned char> Patch61;
	std::vector<unsigned char> Patch62;
	std::vector<unsigned char> Patch63;
	std::vector<unsigned char> Patch64;
	std::vector<unsigned char> Patch65;
	std::vector<unsigned char> Patch66;
	std::vector<unsigned char> Patch67;
	std::vector<unsigned char> Patch68;
	std::vector<unsigned char> Patch69;
	std::vector<unsigned char> Patch70;
	std::vector<unsigned char> Patch71;
	std::vector<unsigned char> Patch72;
	std::vector<unsigned char> Patch73;
	std::vector<unsigned char> Patch74;
	std::vector<unsigned char> Patch75;
	std::vector<unsigned char> Patch76;
	std::vector<unsigned char> Patch77;
	std::vector<unsigned char> Patch78;
	std::vector<unsigned char> Patch79;
	std::vector<unsigned char> Patch80;
	std::vector<unsigned char> Patch81;
	std::vector<unsigned char> Patch82;
	std::vector<unsigned char> Patch83;
	std::vector<unsigned char> Patch84;
	std::vector<unsigned char> Patch85;
	std::vector<unsigned char> Patch86;
	std::vector<unsigned char> Patch87;
	std::vector<unsigned char> Patch88;
	std::vector<unsigned char> Patch89;
	std::vector<unsigned char> Patch90;
	std::vector<unsigned char> Patch91;
	std::vector<unsigned char> Patch92;
	std::vector<unsigned char> Patch93;
	std::vector<unsigned char> Patch94;
	std::vector<unsigned char> Patch95;
	std::vector<unsigned char> Patch96;
	std::vector<unsigned char> Patch97;
	std::vector<unsigned char> Patch98;
	std::vector<unsigned char> Patch99;
	std::vector<unsigned char> Patch100;
	std::vector<unsigned char> Patch101;
	std::vector<unsigned char> Patch102;
	std::vector<unsigned char> Patch103;
	std::vector<unsigned char> Patch104;
	std::vector<unsigned char> Patch105;
	std::vector<unsigned char> Patch106;
	std::vector<unsigned char> Patch107;
	std::vector<unsigned char> Patch108;
	std::vector<unsigned char> Patch109;
	std::vector<unsigned char> Patch110;
	std::vector<unsigned char> Patch111;
	std::vector<unsigned char> Patch112;
	std::vector<unsigned char> Patch113;
	std::vector<unsigned char> Patch114;
	std::vector<unsigned char> Patch115;
	std::vector<unsigned char> Patch116;
	std::vector<unsigned char> Patch117;
	std::vector<unsigned char> Patch118;
	std::vector<unsigned char> Patch119;
	std::vector<unsigned char> Patch120;
	std::vector<unsigned char> Patch121;
	std::vector<unsigned char> Patch122;
	std::vector<unsigned char> Patch123;
	std::vector<unsigned char> Patch124;
	std::vector<unsigned char> Patch125;

	std::vector<unsigned char> Patch134;
	std::vector<unsigned char> Patch135;
	std::vector<unsigned char> Patch136;
	std::vector<unsigned char> Patch137;
	std::vector<unsigned char> Patch138;
	std::vector<unsigned char> Patch139;
	std::vector<unsigned char> Patch140;
	std::vector<unsigned char> Patch141;
	std::vector<unsigned char> Patch142;
	std::vector<unsigned char> Patch143;
	std::vector<unsigned char> Patch144;
	std::vector<unsigned char> Patch145;
	std::vector<unsigned char> Patch146;
	std::vector<unsigned char> Patch147;
	std::vector<unsigned char> Patch148;
	std::vector<unsigned char> Patch149;
	std::vector<unsigned char> Patch150;
	std::vector<unsigned char> Patch151;
	std::vector<unsigned char> Patch152;
	std::vector<unsigned char> Patch153;
	std::vector<unsigned char> Patch154;

	unsigned char Bytes6[] = { 0x74 };
	unsigned char Bytes7[] = { 0x75 };
	unsigned char Bytes8[] = { 0x85 };
	unsigned char Bytes9[] = { 0x85 };
	unsigned char Bytes10[] = { 0x74 };
	unsigned char Bytes11[] = { 0x74 };
	unsigned char Bytes12[] = { 0x74 };
	unsigned char Bytes13[] = { 0xF6, 0xC4, 0x08, 0x74, 0x23 };
	unsigned char Bytes14[] = { 0xC4, 0x10, 0x75, 0x1E, 0x8B, 0x8E, 0x04, 0x01, 0x00, 0x00, 0x85, 0xC9, 0x75, 0x14, 0x8B, 0x0D, 0xE8, 0x1D, 0x51, 0x00, 0x8B, 0x96, 0xB0 };
	unsigned char Bytes15[] = { 0x00, 0x3B, 0x91, 0x47, 0x8A, 0x03, 0x00, 0x76, 0x02, 0xEB, 0x64, 0x8B, 0x96, 0x92, 0x00 };
	unsigned char Bytes16[] = { 0xA8, 0x0C, 0x76, 0x0B, 0xD9, 0x82, 0xDE, 0x01, 0x00, 0x00, 0xEB, 0x09, 0x90, 0x90, 0x90 };
	unsigned char Bytes17[] = { 0x82 };
	unsigned char Bytes18[] = { 0x83, 0xFD, 0x01, 0x7F, 0x04, 0x6A, 0x00, 0xEB, 0x02 };
	unsigned char Bytes19[] = { 0x83, 0xFD, 0x01, 0x7F, 0x04, 0x6A, 0x00, 0xEB, 0x02 };
	unsigned char Bytes20[] = { 0x02 };
	unsigned char Bytes21[] = { 0xD3, 0x5A };
	unsigned char Bytes22[] = { 0x43 };
	unsigned char Bytes23[] = { 0x31 };
	unsigned char Bytes24[] = { 0xEB, 0x2F, 0x90, 0x90, 0x90, 0x90, 0xC6, 0x47, 0x05, 0x04 };
	unsigned char Bytes25[] = { 0x65 };
	unsigned char Bytes26[] = { 0xB1, 0x42 };
	unsigned char Bytes27[] = { 0xEB, 0x40 };
	unsigned char Bytes28[] = { 0x73, 0x43, 0x8B, 0x41, 0x8D, 0x85, 0xC0, 0x74, 0x3C, 0x8A, 0x01, 0x3C, 0x01, 0x74, 0x08, 0x3C, 0x02, 0x74, 0x04 };
	unsigned char Bytes29[] = { 0x03, 0x75, 0x2E, 0x8A, 0x81, 0xD3, 0x00, 0x00, 0x00, 0x3C, 0x0A, 0x74, 0x24, 0x8B, 0x74, 0x24, 0x20, 0x25, 0xFF };
	unsigned char Bytes30[] = { 0x00, 0x8B, 0x36, 0x8A, 0x9C, 0x06, 0x08, 0x01, 0x00, 0x00, 0x84, 0xDB, 0x75, 0x0E, 0x8B, 0x79, 0xF4 };
	unsigned char Bytes31[] = { 0x41, 0xF8, 0x3B, 0xF8, 0x89, 0x44, 0x24, 0x24, 0x76, 0x09, 0xE9, 0xB0, 0x00 };
	unsigned char Bytes32[] = { 0x90, 0x90, 0x90, 0x90 };
	unsigned char Bytes33[] = { 0x87, 0x10, 0x01, 0x00, 0x00, 0xA9, 0x00, 0x00, 0x00, 0x10, 0x74, 0x25, 0x8B, 0x54, 0x24, 0x04, 0x80, 0x7A, 0x20, 0x07, 0x74, 0x09, 0x83, 0xBF, 0x0A, 0x01, 0x00, 0x00, 0x03, 0x74, 0x12, 0x66, 0x25, 0x0A, 0x80, 0x66, 0x85, 0xC0, 0x75, 0x09, 0xF6, 0x87, 0x0E, 0x01, 0x00, 0x00, 0x04, 0x74, 0x02, 0xEB };
	unsigned char Bytes34[] = { 0x58 };
	unsigned char Bytes35[] = { 0xEF };
	unsigned char Bytes36[] = { 0x0C };
	unsigned char Bytes37[] = { 0xF6, 0xC4, 0x40, 0x75, 0x12, 0x8B, 0x4E, 0x60, 0xC1, 0xE8, 0x0E, 0xF6, 0xC4, 0x80, 0x74, 0x07, 0xF6, 0xC4, 0x40, 0x74, 0x02, 0xE3, 0x08, 0xE9, 0xAE, 0x00, 0x00, 0x00, 0x90, 0x90, 0x90 };
	unsigned char Bytes38[] = { 0x12 };
	unsigned char Bytes39[] = { 0x66, 0x25, 0x20, 0x80, 0x66, 0x3D, 0x20, 0x80, 0x0F, 0x85, 0x6C, 0x01 };
	unsigned char Bytes40[] = { 0x33, 0xFF, 0x33, 0xDB, 0x89, 0x5C, 0x24, 0x14, 0xC7, 0x44, 0x24, 0x18, 0x03, 0x00, 0x00, 0x00, 0x8B, 0x75, 0x39, 0x8A, 0x4C, 0x33, 0x1F, 0x80, 0xE1, 0x12, 0x80, 0xF9, 0x12, 0x0F, 0x85, 0x32, 0x01, 0x00, 0x00, 0x8B, 0x54, 0x33, 0x10, 0x8B, 0x8A, 0x12 };
	unsigned char Bytes41[] = { 0x01 };
	unsigned char Bytes42[] = { 0x85 };
	unsigned char Bytes43[] = { 0xF6, 0x44, 0x24, 0x24, 0x01, 0x75, 0x0C, 0xC1, 0xE9, 0x03, 0xF6, 0xC5, 0x80, 0x0F, 0x85, 0x0C, 0x01, 0x00, 0x00, 0x57, 0x56, 0xE8, 0x06, 0x17, 0x08, 0x00, 0x85, 0xC0, 0x0F, 0x84, 0x9F, 0x00, 0x00, 0x00, 0x57, 0x50, 0x56, 0x8B, 0xF0, 0xE8, 0x14, 0x21, 0x09 };
	unsigned char Bytes44[] = { 0x85, 0xC0, 0x8B, 0xC6, 0x8B, 0x75, 0x39, 0x75, 0x07, 0x66, 0xC7, 0x44, 0x33, 0x04 };
	unsigned char Bytes45[] = { 0x00, 0x8B, 0x88, 0x96 };
	unsigned char Bytes46[] = { 0x00, 0x33, 0xD2, 0x8A, 0x91, 0x46, 0x01 };
	unsigned char Bytes47[] = { 0x00, 0x8B, 0x4D, 0x00, 0x80, 0xBC, 0x0A, 0x08, 0x01 };
	unsigned char Bytes48[] = { 0x00, 0x75, 0x5E, 0x66, 0x8B, 0x88, 0xA6 };
	unsigned char Bytes49[] = { 0x00, 0x8B, 0xD6 };
	unsigned char Bytes50[] = { 0xA4 };
	unsigned char Bytes51[] = { 0x5A, 0x04, 0x01 };
	unsigned char Bytes52[] = { 0x75, 0x37, 0xF6, 0xC2, 0x10, 0x74, 0x32, 0x66, 0x8B, 0x88, 0xA6, 0x00, 0x00 };
	unsigned char Bytes53[] = { 0x8B, 0xBE, 0x92, 0x00, 0x00 };
	unsigned char Bytes54[] = { 0xBD, 0x01, 0x00, 0x00, 0x00, 0x8B, 0xBF, 0x3D, 0x02, 0x00, 0x00, 0x8B, 0xD1, 0x83, 0xE1, 0x1F, 0xC1, 0xEA, 0x05, 0xD3, 0xE5, 0x85, 0x2C, 0x97, 0x75, 0x0B, 0x8B, 0x8E, 0x12, 0x01, 0x00, 0x00, 0xF6, 0xC1, 0x0C, 0x75, 0x07, 0xE9, 0xD3, 0x00, 0x00 };
	unsigned char Bytes55[] = { 0x90, 0x90 };
	unsigned char Bytes56[] = { 0xDC, 0x59 };
	unsigned char Bytes57[] = { 0xDB, 0x53 };
	unsigned char Bytes58[] = { 0xC6, 0x4F };
	unsigned char Bytes59[] = { 0x46 };
	unsigned char Bytes60[] = { 0x49 };
	unsigned char Bytes61[] = { 0xC1, 0xFA, 0x04, 0x8B, 0xC2, 0xC1, 0xE8, 0x1F, 0x03, 0xD0, 0x50 };
	unsigned char Bytes62[] = { 0xCB, 0x3F };
	unsigned char Bytes63[] = { 0x90, 0x90, 0x90, 0x90, 0x8D, 0x4C, 0x24, 0x10, 0x68, 0x0C, 0x27, 0x50, 0x00, 0x51, 0xE8, 0x9F, 0xAC, 0x0C, 0x00, 0x83, 0xC4, 0x08, 0xB1, 0x03, 0x85, 0xC0, 0x75, 0x18, 0x8D, 0x44, 0x24, 0x10, 0x68, 0x24, 0x53, 0x50 };
	unsigned char Bytes64[] = { 0x50, 0xE8, 0x87, 0xAC, 0x0C, 0x00, 0x83, 0xC4, 0x08, 0xB1, 0x0B, 0x85, 0xC0, 0x74, 0x39, 0xA1, 0xE8, 0x1D, 0x51 };
	unsigned char Bytes65[] = { 0x66, 0x83, 0xBD, 0x38, 0x01 };
	unsigned char Bytes66[] = { 0x00 };
	unsigned char Bytes67[] = { 0x75, 0x02, 0xB1, 0x01, 0x88, 0x88, 0xC3, 0x2C, 0x00 };
	unsigned char Bytes68[] = { 0x6A, 0x00, 0x68, 0x1C, 0x27, 0x50 };
	unsigned char Bytes69[] = { 0x7D };
	unsigned char Bytes70[] = { 0x74 };
	unsigned char Bytes71[] = { 0x2E };
	unsigned char Bytes72[] = { 0x15 };
	unsigned char Bytes73[] = { 0x75, 0x0D, 0xE9, 0x63, 0x01 };
	unsigned char Bytes74[] = { 0x00, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
	unsigned char Bytes75[] = { 0x74 };
	unsigned char Bytes76[] = { 0x74 };
	unsigned char Bytes77[] = { 0xB0, 0x01 };
	unsigned char Bytes78[] = { 0x86, 0x92, 0x00, 0x00, 0x00, 0x33, 0xDB, 0x8A, 0x98, 0x2C, 0x02 };
	unsigned char Bytes79[] = { 0x03, 0xDA, 0x3B, 0xD9, 0x7F, 0x05, 0xBF, 0x02, 0x00, 0x00, 0x00, 0x8B, 0xDA, 0x2B, 0xD9, 0x83, 0xFB, 0xFB, 0x7E };
	unsigned char Bytes80[] = { 0x01 };
	unsigned char Bytes81[] = { 0x00, 0x00 };
	unsigned char Bytes82[] = { 0x04, 0x00 };
	unsigned char Bytes83[] = { 0xFF };
	unsigned char Bytes84[] = { 0xE9, 0x20, 0x01, 0x00, 0x00, 0x90 };
	unsigned char Bytes85[] = { 0x0F, 0xBF, 0x81, 0x70, 0x01 };
	unsigned char Bytes86[] = { 0x00, 0x0F, 0xBF, 0x56, 0x70, 0x03, 0xC2, 0x8B, 0x15, 0xE8, 0x1D, 0x51 };
	unsigned char Bytes87[] = { 0x0F, 0xBF, 0x92, 0x7F, 0x42, 0x01 };
	unsigned char Bytes88[] = { 0x3B, 0xC2, 0x7D, 0x04, 0xB0, 0x03, 0xEB, 0x02, 0x32, 0xC0, 0x88, 0x86, 0x0A, 0x01, 0x00, 0x00, 0x8B, 0x86, 0x10, 0x01, 0x00, 0x00, 0x66, 0x89, 0x9E, 0xBA, 0x00, 0x00, 0x00, 0x66, 0x89, 0x9E, 0xB8, 0x00, 0x00, 0x00, 0x89, 0x9E, 0xF0, 0x00, 0x00, 0x00, 0xC6, 0x86, 0xF4, 0x00, 0x00, 0x00, 0x0A, 0x8B, 0x91, 0x41, 0x02, 0x00, 0x00, 0x25, 0xFF, 0xF7, 0xC3, 0xF3, 0x83, 0xE2, 0x0F, 0xC1 };
	unsigned char Bytes89[] = { 0x12, 0x0B, 0xC2, 0x8B, 0x91, 0x41, 0x02, 0x00, 0x00, 0x83, 0xE2, 0x10, 0xC1, 0xE2, 0x07, 0x0B, 0xC2 };
	unsigned char Bytes90[] = { 0xFF };
	unsigned char Bytes91[] = { 0x46 };
	unsigned char Bytes92[] = { 0x04 };
	unsigned char Bytes93[] = { 0xF9 };
	unsigned char Bytes94[] = { 0xEA };
	unsigned char Bytes95[] = { 0x0F, 0xBF };
	unsigned char Bytes96[] = { 0x85, 0xC0, 0x74, 0x53, 0x0F, 0xBF, 0x96, 0x08, 0x01, 0x00 };
	unsigned char Bytes97[] = { 0x3B, 0x91, 0xFA, 0x01, 0x00 };
	unsigned char Bytes98[] = { 0x73, 0x44, 0x8B, 0x8E, 0x04, 0x01, 0x00, 0x00, 0x85, 0xC9, 0x75, 0x3A, 0x8B, 0x0D, 0xE8, 0x1D, 0x51, 0x00, 0x84, 0x81, 0x47, 0x8A, 0x03, 0x00, 0x75, 0x2C, 0x90, 0xC1, 0xE0, 0x03, 0x8B, 0xC8, 0xB8, 0x89, 0x88, 0x88, 0x88, 0xF7, 0xE9, 0x03, 0xD1, 0x51, 0xC1, 0xFA, 0x02, 0x8B, 0xC2, 0xC1, 0xE8, 0x1F, 0x03, 0xD0, 0x89, 0x54 };
	unsigned char Bytes99[] = { 0xDB, 0x44 };
	unsigned char Bytes100[] = { 0x20, 0xD9, 0x1C, 0x24, 0x56, 0x56, 0xE8, 0x75, 0x0D, 0xF9, 0xFF, 0x56, 0xE8, 0x1F, 0x08, 0xFB, 0xFF, 0x56, 0xE8, 0x29, 0x0B, 0xFB, 0xFF, 0x8B, 0x0E, 0x85, 0xC9, 0x74, 0x0C, 0x56, 0xE8, 0x6D, 0x2D, 0xFB, 0xFF, 0x56, 0xE8, 0xB7, 0xF8, 0xFF, 0xFF };
	unsigned char Bytes101[] = { 0x5C, 0x24, 0x18, 0x8B, 0x86, 0x11, 0x01, 0x00, 0x00, 0xA8, 0x40 };
	unsigned char Bytes102[] = { 0x33, 0xDB, 0x0F, 0xBF, 0x88, 0xA6 };
	unsigned char Bytes103[] = { 0x00, 0x00, 0x43, 0x8B, 0xF1, 0xC1, 0xEE, 0x05, 0xD3, 0xE3, 0x8B, 0x4C, 0xB4, 0x0C, 0x8D, 0x74, 0xB4, 0x0C, 0x0B, 0xCB, 0x89, 0x0E, 0xEB, 0x09, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
	unsigned char Bytes104[] = { 0x33, 0xFF, 0x0F, 0xBF, 0x82, 0xA6 };
	unsigned char Bytes105[] = { 0x00, 0x00, 0x47, 0x8B, 0xC8, 0xD3, 0xE7, 0xC1, 0xE8, 0x05, 0x85, 0x7C, 0x84, 0x0C, 0x74, 0x13, 0xEB, 0x08, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
	unsigned char Bytes106[] = { 0xD1, 0x6A, 0x40, 0x52, 0xE8, 0xC0, 0x4E, 0x01, 0x00, 0xA1, 0xE8, 0x1D, 0x51, 0x00, 0x5E, 0x80, 0x88, 0x51, 0x8A, 0x03, 0x00, 0x01, 0x59, 0xC3, 0x90, 0x83, 0xEC, 0x34, 0x56, 0x8B, 0x74, 0x24, 0x3C, 0x68, 0x60, 0x55, 0x50, 0x00, 0x8B, 0x46, 0x18, 0x8B, 0x48, 0x04, 0x51, 0xE8, 0xB7, 0xCE, 0x00, 0x00, 0x85, 0xC0, 0x74, 0x2B, 0x50, 0xE8, 0xCD, 0x86, 0xFC, 0xFF, 0x50, 0x8D, 0x54, 0x24, 0x08, 0x68, 0x6C, 0x26, 0x50, 0x00, 0x52 };
	unsigned char Bytes107[] = { 0x4D, 0x0F, 0x05, 0x00, 0x83, 0xC4, 0x0C, 0x8D, 0x44, 0x24, 0x04, 0x6A, 0x00, 0x50, 0x68, 0xB0, 0x93, 0x50, 0x00, 0x56, 0xE8, 0x78, 0xD8, 0x00, 0x00, 0x5E, 0x83, 0xC4, 0x34, 0xC2, 0x08, 0x00, 0x90, 0x83, 0xEC, 0x34, 0x56, 0x8B, 0x74, 0x24, 0x3C, 0x68, 0x58, 0x55, 0x50, 0x00, 0x8B, 0x46, 0x18, 0x8B, 0x48, 0x04, 0x51, 0xE8, 0x67, 0xCE, 0x00, 0x00, 0x85, 0xC0, 0x74, 0x2B, 0x50, 0xE8, 0x7D, 0x86, 0xFC, 0xFF, 0x50, 0x8D, 0x54, 0x24, 0x08, 0x68, 0x6C, 0x26, 0x50, 0x00, 0x52 };
	unsigned char Bytes108[] = { 0xFD, 0x0E, 0x05, 0x00, 0x83, 0xC4, 0x0C, 0x8D, 0x44, 0x24, 0x04, 0x6A, 0x00, 0x50, 0x68, 0xB8, 0x93, 0x50, 0x00, 0x56, 0xE8, 0x28, 0xD8, 0x00, 0x00, 0x5E, 0x83, 0xC4, 0x34, 0xC2, 0x08, 0x00, 0x90, 0x83, 0xEC, 0x10, 0x8A, 0x44, 0x24, 0x14, 0x53, 0x56, 0x88, 0x44, 0x24, 0x08, 0x8D, 0x4C, 0x24, 0x08, 0x57, 0x33, 0xC0, 0x51, 0x89, 0x44, 0x24, 0x14, 0x89 };
	unsigned char Bytes109[] = { 0x18, 0x89, 0x44 };
	unsigned char Bytes110[] = { 0x1C, 0xE8, 0x2A, 0x96, 0xFF, 0xFF, 0x68, 0x60, 0x28, 0x50, 0x00, 0x33, 0xC0, 0x8A };
	unsigned char Bytes111[] = { 0x24, 0x8B, 0xC8, 0xC1, 0xE1, 0x05, 0x03, 0xC8, 0x8D, 0x14, 0x89 };
	unsigned char Bytes112[] = { 0x0D, 0xE8, 0x1D, 0x51, 0x00, 0x03, 0xC8, 0x8D, 0x9C, 0x51, 0x63, 0x1B, 0x00, 0x00, 0xE8, 0x31, 0x58, 0xFF, 0xFF, 0x8B, 0x74, 0x24, 0x10, 0x8B, 0xF8, 0x3B, 0x74, 0x24, 0x14, 0x74, 0x74, 0x8B, 0x54, 0x24, 0xF4, 0x8B, 0x44, 0x24, 0x04, 0x8A, 0x84, 0x02, 0x08, 0x01, 0x00, 0x00, 0x3C, 0x01 };
	unsigned char Bytes113[] = { 0x0F, 0x8B, 0x0D, 0xE8, 0x1D, 0x51, 0x00, 0xF6, 0x81, 0x2F, 0x7F, 0x03, 0x00, 0x02, 0x74, 0x52, 0x55 };
	unsigned char Bytes114[] = { 0x16, 0x33, 0xED, 0x39, 0xAA, 0x8A, 0x00, 0x00, 0x00, 0x74, 0x04, 0x39, 0x2A, 0x75, 0x31, 0x8B, 0x82, 0x92, 0x00, 0x00, 0x00, 0xF6, 0x80, 0x47, 0x02 };
	unsigned char Bytes115[] = { 0x00, 0x04, 0x75, 0x22, 0x33, 0xC0, 0x66, 0x8B, 0x82, 0xA6, 0x00, 0x00, 0x00, 0x45, 0x8B, 0xC8, 0x83, 0xE1, 0x1F, 0xD3, 0xE5, 0xC1, 0xE8, 0x05, 0x85, 0x2C, 0x87, 0x75, 0x09, 0x6A, 0x00, 0x53, 0x52, 0xE8, 0xE1, 0x50, 0xFF, 0xFF, 0x8B, 0x44, 0x24, 0x18, 0x83, 0xC6, 0x04, 0x3B, 0xF0, 0x75, 0xB4, 0x8B, 0x74, 0x24, 0x14, 0x5D, 0x56, 0xE8, 0x7B, 0x1A, 0x02, 0x00, 0x83, 0xC4, 0x04, 0x5F, 0x5E, 0x5B, 0x83, 0xC4, 0x10, 0xEB, 0x42 };
	unsigned char Bytes116[] = { 0x58 };
	unsigned char Bytes117[] = { 0x30 };
	unsigned char Bytes118[] = { 0x80 };
	unsigned char Bytes119[] = { 0x27 };
	unsigned char Bytes120[] = { 0x24 };
	unsigned char Bytes121[] = { 0x0D };
	unsigned char Bytes122[] = { 0x75 };
	unsigned char Bytes123[] = { 0x08 };
	unsigned char Bytes124[] = { 0xE9, 0xE3, 0xDE, 0x02, 0x00, 0x90, 0x90, 0x90 };
	unsigned char Bytes125[] = { 0xE9, 0xAA, 0x49, 0x01, 0x00 };

	unsigned char Bytes134[] = { 0xD0, 0x86 };
	unsigned char Bytes135[] = { 0xD4 };
	unsigned char Bytes136[] = { 0x99, 0x99, 0x99, 0x99, 0x99, 0x99, 0xF7 };
	unsigned char Bytes137[] = { 0x4D };
	unsigned char Bytes138[] = { 0x4D, 0x4D, 0x55, 0x53, 0x49 };
	unsigned char Bytes139[] = { 0x4D };
	unsigned char Bytes140[] = { 0x02 };
	unsigned char Bytes141[] = { 0x02 };
	unsigned char Bytes142[] = { 0x4D };
	unsigned char Bytes143[] = { 0x6D, 0x61, 0x79 };
	unsigned char Bytes144[] = { 0x68, 0x65, 0x6D };
	unsigned char Bytes145[] = { 0x5C };
	unsigned char Bytes146[] = { 0x38, 0x2E, 0x31, 0x2E, 0x38 };
	unsigned char Bytes147[] = { 0x73, 0x4D };
	unsigned char Bytes148[] = { 0x4D };
	unsigned char Bytes149[] = { 0x4D };
	unsigned char Bytes150[] = { 0x4D };
	unsigned char Bytes151[] = { 0x4D };
	unsigned char Bytes152[] = { 0x6D };
	unsigned char Bytes153[] = { 0x54, 0x6F, 0x74, 0x61, 0x6C, 0x4D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
	unsigned char Bytes154[] = { 0x54, 0x6F, 0x74, 0x61, 0x6C, 0x4D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	for (int i = 0; i < 1; i++) { Patch6.push_back(Bytes6[i]); }
	for (int i = 0; i < 1; i++) { Patch7.push_back(Bytes7[i]); }
	for (int i = 0; i < 1; i++) { Patch8.push_back(Bytes8[i]); }
	for (int i = 0; i < 1; i++) { Patch9.push_back(Bytes9[i]); }
	for (int i = 0; i < 1; i++) { Patch10.push_back(Bytes10[i]); }
	for (int i = 0; i < 1; i++) { Patch11.push_back(Bytes11[i]); }
	for (int i = 0; i < 1; i++) { Patch12.push_back(Bytes12[i]); }
	for (int i = 0; i < 5; i++) { Patch13.push_back(Bytes13[i]); }
	for (int i = 0; i < 23; i++) { Patch14.push_back(Bytes14[i]); }
	for (int i = 0; i < 15; i++) { Patch15.push_back(Bytes15[i]); }
	for (int i = 0; i < 15; i++) { Patch16.push_back(Bytes16[i]); }
	for (int i = 0; i < 1; i++) { Patch17.push_back(Bytes17[i]); }
	for (int i = 0; i < 9; i++) { Patch18.push_back(Bytes18[i]); }
	for (int i = 0; i < 9; i++) { Patch19.push_back(Bytes19[i]); }
	for (int i = 0; i < 1; i++) { Patch20.push_back(Bytes20[i]); }
	for (int i = 0; i < 2; i++) { Patch21.push_back(Bytes21[i]); }
	for (int i = 0; i < 1; i++) { Patch22.push_back(Bytes22[i]); }
	for (int i = 0; i < 1; i++) { Patch23.push_back(Bytes23[i]); }
	for (int i = 0; i < 10; i++) { Patch24.push_back(Bytes24[i]); }
	for (int i = 0; i < 1; i++) { Patch25.push_back(Bytes25[i]); }
	for (int i = 0; i < 2; i++) { Patch26.push_back(Bytes26[i]); }
	for (int i = 0; i < 2; i++) { Patch27.push_back(Bytes27[i]); }
	for (int i = 0; i < 19; i++) { Patch28.push_back(Bytes28[i]); }
	for (int i = 0; i < 19; i++) { Patch29.push_back(Bytes29[i]); }
	for (int i = 0; i < 17; i++) { Patch30.push_back(Bytes30[i]); }
	for (int i = 0; i < 13; i++) { Patch31.push_back(Bytes31[i]); }
	for (int i = 0; i < 4; i++) { Patch32.push_back(Bytes32[i]); }
	for (int i = 0; i < 50; i++) { Patch33.push_back(Bytes33[i]); }
	for (int i = 0; i < 1; i++) { Patch34.push_back(Bytes34[i]); }
	for (int i = 0; i < 1; i++) { Patch35.push_back(Bytes35[i]); }
	for (int i = 0; i < 1; i++) { Patch36.push_back(Bytes36[i]); }
	for (int i = 0; i < 31; i++) { Patch37.push_back(Bytes37[i]); }
	for (int i = 0; i < 1; i++) { Patch38.push_back(Bytes38[i]); }
	for (int i = 0; i < 12; i++) { Patch39.push_back(Bytes39[i]); }
	for (int i = 0; i < 42; i++) { Patch40.push_back(Bytes40[i]); }
	for (int i = 0; i < 1; i++) { Patch41.push_back(Bytes41[i]); }
	for (int i = 0; i < 1; i++) { Patch42.push_back(Bytes42[i]); }
	for (int i = 0; i < 43; i++) { Patch43.push_back(Bytes43[i]); }
	for (int i = 0; i < 14; i++) { Patch44.push_back(Bytes44[i]); }
	for (int i = 0; i < 4; i++) { Patch45.push_back(Bytes45[i]); }
	for (int i = 0; i < 7; i++) { Patch46.push_back(Bytes46[i]); }
	for (int i = 0; i < 9; i++) { Patch47.push_back(Bytes47[i]); }
	for (int i = 0; i < 7; i++) { Patch48.push_back(Bytes48[i]); }
	for (int i = 0; i < 3; i++) { Patch49.push_back(Bytes49[i]); }
	for (int i = 0; i < 1; i++) { Patch50.push_back(Bytes50[i]); }
	for (int i = 0; i < 3; i++) { Patch51.push_back(Bytes51[i]); }
	for (int i = 0; i < 13; i++) { Patch52.push_back(Bytes52[i]); }
	for (int i = 0; i < 5; i++) { Patch53.push_back(Bytes53[i]); }
	for (int i = 0; i < 41; i++) { Patch54.push_back(Bytes54[i]); }
	for (int i = 0; i < 2; i++) { Patch55.push_back(Bytes55[i]); }
	for (int i = 0; i < 2; i++) { Patch56.push_back(Bytes56[i]); }
	for (int i = 0; i < 2; i++) { Patch57.push_back(Bytes57[i]); }
	for (int i = 0; i < 2; i++) { Patch58.push_back(Bytes58[i]); }
	for (int i = 0; i < 1; i++) { Patch59.push_back(Bytes59[i]); }
	for (int i = 0; i < 1; i++) { Patch60.push_back(Bytes60[i]); }
	for (int i = 0; i < 11; i++) { Patch61.push_back(Bytes61[i]); }
	for (int i = 0; i < 2; i++) { Patch62.push_back(Bytes62[i]); }
	for (int i = 0; i < 36; i++) { Patch63.push_back(Bytes63[i]); }
	for (int i = 0; i < 19; i++) { Patch64.push_back(Bytes64[i]); }
	for (int i = 0; i < 5; i++) { Patch65.push_back(Bytes65[i]); }
	for (int i = 0; i < 1; i++) { Patch66.push_back(Bytes66[i]); }
	for (int i = 0; i < 9; i++) { Patch67.push_back(Bytes67[i]); }
	for (int i = 0; i < 6; i++) { Patch68.push_back(Bytes68[i]); }
	for (int i = 0; i < 1; i++) { Patch69.push_back(Bytes69[i]); }
	for (int i = 0; i < 1; i++) { Patch70.push_back(Bytes70[i]); }
	for (int i = 0; i < 1; i++) { Patch71.push_back(Bytes71[i]); }
	for (int i = 0; i < 1; i++) { Patch72.push_back(Bytes72[i]); }
	for (int i = 0; i < 5; i++) { Patch73.push_back(Bytes73[i]); }
	for (int i = 0; i < 9; i++) { Patch74.push_back(Bytes74[i]); }
	for (int i = 0; i < 1; i++) { Patch75.push_back(Bytes75[i]); }
	for (int i = 0; i < 1; i++) { Patch76.push_back(Bytes76[i]); }
	for (int i = 0; i < 2; i++) { Patch77.push_back(Bytes77[i]); }
	for (int i = 0; i < 11; i++) { Patch78.push_back(Bytes78[i]); }
	for (int i = 0; i < 19; i++) { Patch79.push_back(Bytes79[i]); }
	for (int i = 0; i < 1; i++) { Patch80.push_back(Bytes80[i]); }
	for (int i = 0; i < 2; i++) { Patch81.push_back(Bytes81[i]); }
	for (int i = 0; i < 2; i++) { Patch82.push_back(Bytes82[i]); }
	for (int i = 0; i < 1; i++) { Patch83.push_back(Bytes83[i]); }
	for (int i = 0; i < 6; i++) { Patch84.push_back(Bytes84[i]); }
	for (int i = 0; i < 5; i++) { Patch85.push_back(Bytes85[i]); }
	for (int i = 0; i < 12; i++) { Patch86.push_back(Bytes86[i]); }
	for (int i = 0; i < 6; i++) { Patch87.push_back(Bytes87[i]); }
	for (int i = 0; i < 64; i++) { Patch88.push_back(Bytes88[i]); }
	for (int i = 0; i < 17; i++) { Patch89.push_back(Bytes89[i]); }
	for (int i = 0; i < 1; i++) { Patch90.push_back(Bytes90[i]); }
	for (int i = 0; i < 1; i++) { Patch91.push_back(Bytes91[i]); }
	for (int i = 0; i < 1; i++) { Patch92.push_back(Bytes92[i]); }
	for (int i = 0; i < 1; i++) { Patch93.push_back(Bytes93[i]); }
	for (int i = 0; i < 1; i++) { Patch94.push_back(Bytes94[i]); }
	for (int i = 0; i < 2; i++) { Patch95.push_back(Bytes95[i]); }
	for (int i = 0; i < 10; i++) { Patch96.push_back(Bytes96[i]); }
	for (int i = 0; i < 5; i++) { Patch97.push_back(Bytes97[i]); }
	for (int i = 0; i < 54; i++) { Patch98.push_back(Bytes98[i]); }
	for (int i = 0; i < 2; i++) { Patch99.push_back(Bytes99[i]); }
	for (int i = 0; i < 41; i++) { Patch100.push_back(Bytes100[i]); }
	for (int i = 0; i < 11; i++) { Patch101.push_back(Bytes101[i]); }
	for (int i = 0; i < 6; i++) { Patch102.push_back(Bytes102[i]); }
	for (int i = 0; i < 33; i++) { Patch103.push_back(Bytes103[i]); }
	for (int i = 0; i < 6; i++) { Patch104.push_back(Bytes104[i]); }
	for (int i = 0; i < 26; i++) { Patch105.push_back(Bytes105[i]); }
	for (int i = 0; i < 71; i++) { Patch106.push_back(Bytes106[i]); }
	for (int i = 0; i < 79; i++) { Patch107.push_back(Bytes107[i]); }
	for (int i = 0; i < 59; i++) { Patch108.push_back(Bytes108[i]); }
	for (int i = 0; i < 3; i++) { Patch109.push_back(Bytes109[i]); }
	for (int i = 0; i < 14; i++) { Patch110.push_back(Bytes110[i]); }
	for (int i = 0; i < 11; i++) { Patch111.push_back(Bytes111[i]); }
	for (int i = 0; i < 48; i++) { Patch112.push_back(Bytes112[i]); }
	for (int i = 0; i < 17; i++) { Patch113.push_back(Bytes113[i]); }
	for (int i = 0; i < 25; i++) { Patch114.push_back(Bytes114[i]); }
	for (int i = 0; i < 71; i++) { Patch115.push_back(Bytes115[i]); }
	for (int i = 0; i < 1; i++) { Patch116.push_back(Bytes116[i]); }
	for (int i = 0; i < 1; i++) { Patch117.push_back(Bytes117[i]); }
	for (int i = 0; i < 1; i++) { Patch118.push_back(Bytes118[i]); }
	for (int i = 0; i < 1; i++) { Patch119.push_back(Bytes119[i]); }
	for (int i = 0; i < 1; i++) { Patch120.push_back(Bytes120[i]); }
	for (int i = 0; i < 1; i++) { Patch121.push_back(Bytes121[i]); }
	for (int i = 0; i < 1; i++) { Patch122.push_back(Bytes122[i]); }
	for (int i = 0; i < 1; i++) { Patch123.push_back(Bytes123[i]); }
	for (int i = 0; i < 8; i++) { Patch124.push_back(Bytes124[i]); }
	for (int i = 0; i < 5; i++) { Patch125.push_back(Bytes125[i]); }

	for (int i = 0; i < 2; i++) { Patch134.push_back(Bytes134[i]); }
	for (int i = 0; i < 1; i++) { Patch135.push_back(Bytes135[i]); }
	for (int i = 0; i < 7; i++) { Patch136.push_back(Bytes136[i]); }
	for (int i = 0; i < 1; i++) { Patch137.push_back(Bytes137[i]); }
	for (int i = 0; i < 5; i++) { Patch138.push_back(Bytes138[i]); }
	for (int i = 0; i < 1; i++) { Patch139.push_back(Bytes139[i]); }
	for (int i = 0; i < 1; i++) { Patch140.push_back(Bytes140[i]); }
	for (int i = 0; i < 1; i++) { Patch141.push_back(Bytes141[i]); }
	for (int i = 0; i < 1; i++) { Patch142.push_back(Bytes142[i]); }
	for (int i = 0; i < 3; i++) { Patch143.push_back(Bytes143[i]); }
	for (int i = 0; i < 3; i++) { Patch144.push_back(Bytes144[i]); }
	for (int i = 0; i < 1; i++) { Patch145.push_back(Bytes145[i]); }
	for (int i = 0; i < 5; i++) { Patch146.push_back(Bytes146[i]); }
	for (int i = 0; i < 2; i++) { Patch147.push_back(Bytes147[i]); }
	for (int i = 0; i < 1; i++) { Patch148.push_back(Bytes148[i]); }
	for (int i = 0; i < 1; i++) { Patch149.push_back(Bytes149[i]); }
	for (int i = 0; i < 1; i++) { Patch150.push_back(Bytes150[i]); }
	for (int i = 0; i < 1; i++) { Patch151.push_back(Bytes151[i]); }
	for (int i = 0; i < 1; i++) { Patch152.push_back(Bytes152[i]); }
	for (int i = 0; i < 21; i++) { Patch153.push_back(Bytes153[i]); }
	for (int i = 0; i < 21; i++) { Patch154.push_back(Bytes154[i]); }

	Variables::Mayhem[6] = Patching::Patch(0x0040144C, Patch6, true);
	Variables::Mayhem[7] = Patching::Patch(0x00401509, Patch7, true);
	Variables::Mayhem[8] = Patching::Patch(0x00401595, Patch8, true);
	Variables::Mayhem[9] = Patching::Patch(0x0040160D, Patch9, true);
	Variables::Mayhem[10] = Patching::Patch(0x00401693, Patch10, true);
	Variables::Mayhem[11] = Patching::Patch(0x00401709, Patch11, true);
	Variables::Mayhem[12] = Patching::Patch(0x00401769, Patch12, true);
	Variables::Mayhem[13] = Patching::Patch(0x004017DF, Patch13, true);
	Variables::Mayhem[14] = Patching::Patch(0x004017E5, Patch14, true);
	Variables::Mayhem[15] = Patching::Patch(0x004017FE, Patch15, true);
	Variables::Mayhem[16] = Patching::Patch(0x0040180F, Patch16, true);
	Variables::Mayhem[17] = Patching::Patch(0x0040181F, Patch17, true);
	Variables::Mayhem[18] = Patching::Patch(0x004035EE, Patch18, true);
	Variables::Mayhem[19] = Patching::Patch(0x004037E0, Patch19, true);
	Variables::Mayhem[20] = Patching::Patch(0x00403976, Patch20, true);
	Variables::Mayhem[21] = Patching::Patch(0x00403D29, Patch21, true);
	Variables::Mayhem[22] = Patching::Patch(0x004040B9, Patch22, true);
	Variables::Mayhem[23] = Patching::Patch(0x004047CB, Patch23, true);
	Variables::Mayhem[24] = Patching::Patch(0x00404C5F, Patch24, true);
	Variables::Mayhem[25] = Patching::Patch(0x00404D98, Patch25, true);
	Variables::Mayhem[26] = Patching::Patch(0x0040554B, Patch26, true);
	Variables::Mayhem[27] = Patching::Patch(0x00406FB4, Patch27, true);
	Variables::Mayhem[28] = Patching::Patch(0x00407223, Patch28, true);
	Variables::Mayhem[29] = Patching::Patch(0x00407237, Patch29, true);
	Variables::Mayhem[30] = Patching::Patch(0x0040724C, Patch30, true);
	Variables::Mayhem[31] = Patching::Patch(0x0040725E, Patch31, true);
	Variables::Mayhem[32] = Patching::Patch(0x0040726D, Patch32, true);
	Variables::Mayhem[33] = Patching::Patch(0x00407272, Patch33, true);
	Variables::Mayhem[34] = Patching::Patch(0x00407315, Patch34, true);
	Variables::Mayhem[35] = Patching::Patch(0x00407332, Patch35, true);
	Variables::Mayhem[36] = Patching::Patch(0x00408170, Patch36, true);
	Variables::Mayhem[37] = Patching::Patch(0x004086FF, Patch37, true);
	Variables::Mayhem[38] = Patching::Patch(0x00408A28, Patch38, true);
	Variables::Mayhem[39] = Patching::Patch(0x00408A2C, Patch39, true);
	Variables::Mayhem[40] = Patching::Patch(0x00408A3A, Patch40, true);
	Variables::Mayhem[41] = Patching::Patch(0x00408A69, Patch41, true);
	Variables::Mayhem[42] = Patching::Patch(0x00408A6B, Patch42, true);
	Variables::Mayhem[43] = Patching::Patch(0x00408A70, Patch43, true);
	Variables::Mayhem[44] = Patching::Patch(0x00408A9C, Patch44, true);
	Variables::Mayhem[45] = Patching::Patch(0x00408AAB, Patch45, true);
	Variables::Mayhem[46] = Patching::Patch(0x00408AB1, Patch46, true);
	Variables::Mayhem[47] = Patching::Patch(0x00408AB9, Patch47, true);
	Variables::Mayhem[48] = Patching::Patch(0x00408AC4, Patch48, true);
	Variables::Mayhem[49] = Patching::Patch(0x00408ACD, Patch49, true);
	Variables::Mayhem[50] = Patching::Patch(0x00408BA2, Patch50, true);
	Variables::Mayhem[51] = Patching::Patch(0x0040EAD6, Patch51, true);
	Variables::Mayhem[52] = Patching::Patch(0x0040FD57, Patch52, true);
	Variables::Mayhem[53] = Patching::Patch(0x0040FD65, Patch53, true);
	Variables::Mayhem[54] = Patching::Patch(0x0040FD6B, Patch54, true);
	Variables::Mayhem[55] = Patching::Patch(0x0040FD95, Patch55, true);
	Variables::Mayhem[56] = Patching::Patch(0x00413E20, Patch56, true);
	Variables::Mayhem[57] = Patching::Patch(0x00414421, Patch57, true);
	Variables::Mayhem[58] = Patching::Patch(0x00414836, Patch58, true);
	Variables::Mayhem[59] = Patching::Patch(0x00414DB6, Patch59, true);
	Variables::Mayhem[60] = Patching::Patch(0x00414FB3, Patch60, true);
	Variables::Mayhem[61] = Patching::Patch(0x00415125, Patch61, true);
	Variables::Mayhem[62] = Patching::Patch(0x00415831, Patch62, true);
	Variables::Mayhem[63] = Patching::Patch(0x00419CFE, Patch63, true);
	Variables::Mayhem[64] = Patching::Patch(0x00419D23, Patch64, true);
	Variables::Mayhem[65] = Patching::Patch(0x00419D37, Patch65, true);
	Variables::Mayhem[66] = Patching::Patch(0x00419D3D, Patch66, true);
	Variables::Mayhem[67] = Patching::Patch(0x00419D3F, Patch67, true);
	Variables::Mayhem[68] = Patching::Patch(0x00419D49, Patch68, true);
	Variables::Mayhem[69] = Patching::Patch(0x0041BD90, Patch69, true);
	Variables::Mayhem[70] = Patching::Patch(0x0041D6B0, Patch70, true);
	Variables::Mayhem[71] = Patching::Patch(0x0041D6B3, Patch71, true);
	Variables::Mayhem[72] = Patching::Patch(0x0041DD4B, Patch72, true);
	Variables::Mayhem[73] = Patching::Patch(0x0041DD52, Patch73, true);
	Variables::Mayhem[74] = Patching::Patch(0x0041DD58, Patch74, true);
	Variables::Mayhem[75] = Patching::Patch(0x004238D5, Patch75, true);
	Variables::Mayhem[76] = Patching::Patch(0x0042392F, Patch76, true);
	Variables::Mayhem[77] = Patching::Patch(0x004266A5, Patch77, true);
	Variables::Mayhem[78] = Patching::Patch(0x0043DB94, Patch78, true);
	Variables::Mayhem[79] = Patching::Patch(0x0043DBA1, Patch79, true);
	Variables::Mayhem[80] = Patching::Patch(0x0043DBB6, Patch80, true);
	Variables::Mayhem[81] = Patching::Patch(0x0043E786, Patch81, true);
	Variables::Mayhem[82] = Patching::Patch(0x0043F613, Patch82, true);
	Variables::Mayhem[83] = Patching::Patch(0x00446E4D, Patch83, true);
	Variables::Mayhem[84] = Patching::Patch(0x0044A806, Patch84, true);
	Variables::Mayhem[85] = Patching::Patch(0x00485C69, Patch85, true);
	Variables::Mayhem[86] = Patching::Patch(0x00485C6F, Patch86, true);
	Variables::Mayhem[87] = Patching::Patch(0x00485C7C, Patch87, true);
	Variables::Mayhem[88] = Patching::Patch(0x00485C83, Patch88, true);
	Variables::Mayhem[89] = Patching::Patch(0x00485CC4, Patch89, true);
	Variables::Mayhem[90] = Patching::Patch(0x0048871D, Patch90, true);
	Variables::Mayhem[91] = Patching::Patch(0x0048998B, Patch91, true);
	Variables::Mayhem[92] = Patching::Patch(0x00489991, Patch92, true);
	Variables::Mayhem[93] = Patching::Patch(0x0048AEC0, Patch93, true);
	Variables::Mayhem[94] = Patching::Patch(0x0048AECF, Patch94, true);
	Variables::Mayhem[95] = Patching::Patch(0x0048AF3D, Patch95, true);
	Variables::Mayhem[96] = Patching::Patch(0x0048AF44, Patch96, true);
	Variables::Mayhem[97] = Patching::Patch(0x0048AF4F, Patch97, true);
	Variables::Mayhem[98] = Patching::Patch(0x0048AF55, Patch98, true);
	Variables::Mayhem[99] = Patching::Patch(0x0048AF8D, Patch99, true);
	Variables::Mayhem[100] = Patching::Patch(0x0048AF90, Patch100, true);
	Variables::Mayhem[101] = Patching::Patch(0x0048AFBA, Patch101, true);

	Variables::Mayhem[102] = Patching::Patch(0x0048BE4F, Patch102, true);
	Variables::Mayhem[103] = Patching::Patch(0x0048BE56, Patch103, true);
	Variables::Mayhem[104] = Patching::Patch(0x0048BEC3, Patch104, true);
	Variables::Mayhem[105] = Patching::Patch(0x0048BECA, Patch105, true);
	Variables::Mayhem[106] = Patching::Patch(0x00493317, Patch106, true);
	Variables::Mayhem[107] = Patching::Patch(0x0049335F, Patch107, true);
	Variables::Mayhem[108] = Patching::Patch(0x004933AF, Patch108, true);
	Variables::Mayhem[109] = Patching::Patch(0x004933EC, Patch109, true);
	Variables::Mayhem[110] = Patching::Patch(0x004933F0, Patch110, true);
	Variables::Mayhem[111] = Patching::Patch(0x00493400, Patch111, true);
	Variables::Mayhem[112] = Patching::Patch(0x0049340C, Patch112, true);
	Variables::Mayhem[113] = Patching::Patch(0x0049343D, Patch113, true);
	Variables::Mayhem[114] = Patching::Patch(0x0049344F, Patch114, true);
	Variables::Mayhem[115] = Patching::Patch(0x00493469, Patch115, true);
	Variables::Mayhem[116] = Patching::Patch(0x00493674, Patch116, true);
	Variables::Mayhem[117] = Patching::Patch(0x004937DF, Patch117, true);
	Variables::Mayhem[118] = Patching::Patch(0x00493892, Patch118, true);
	Variables::Mayhem[119] = Patching::Patch(0x004966E7, Patch119, true);
	Variables::Mayhem[120] = Patching::Patch(0x00496776, Patch120, true);
	Variables::Mayhem[121] = Patching::Patch(0x00496779, Patch121, true);

	Variables::Mayhem[122] = Patching::Patch(0x0049AA53, Patch122, true);
	Variables::Mayhem[123] = Patching::Patch(0x0049E9C0, Patch123, true);
	//Variables::Mayhem[124] = Patching::Patch(0x004CDA44, Patch124, true);
	//Variables::Mayhem[125] = Patching::Patch(0x004E6FA0, Patch125, true);

	Variables::Mayhem[134] = Patching::Patch(0x004FC980, Patch134, true);
	Variables::Mayhem[135] = Patching::Patch(0x004FCC7F, Patch135, true);
	Variables::Mayhem[136] = Patching::Patch(0x004FD040, Patch136, true);
	//Variables::Mayhem[137] = Patching::Patch(0x004FF618, Patch137, true);
	//Variables::Mayhem[138] = Patching::Patch(0x004FF642, Patch138, true);
	//Variables::Mayhem[139] = Patching::Patch(0x004FF9E4, Patch139, true);

	Variables::Mayhem[140] = Patching::Patch(0x00501FD8, Patch140, true);
	Variables::Mayhem[141] = Patching::Patch(0x00501FE4, Patch141, true);
	Variables::Mayhem[142] = Patching::Patch(0x00502823, Patch142, true);
	Variables::Mayhem[143] = Patching::Patch(0x005028CC, Patch143, true);
	Variables::Mayhem[144] = Patching::Patch(0x005028D8, Patch144, true);
	Variables::Mayhem[145] = Patching::Patch(0x00502916, Patch145, true);
	Variables::Mayhem[146] = Patching::Patch(0x005031B4, Patch146, true);
	Variables::Mayhem[147] = Patching::Patch(0x00503738, Patch147, true);
	Variables::Mayhem[148] = Patching::Patch(0x00503925, Patch148, true);
	Variables::Mayhem[149] = Patching::Patch(0x00503932, Patch149, true);
	Variables::Mayhem[150] = Patching::Patch(0x0050393A, Patch150, true);
	Variables::Mayhem[151] = Patching::Patch(0x00505FEB, Patch151, true);
	Variables::Mayhem[152] = Patching::Patch(0x005098A8, Patch152, true);
	Variables::Mayhem[153] = Patching::Patch(0x00509EB8, Patch153, true);
	Variables::Mayhem[154] = Patching::Patch(0x0050DDFD, Patch154, true);
}

#endif

#ifdef OTA_MOD

void Valkyrie::Patches::NoCD()
{
	std::vector<unsigned char> Patch1;
	std::vector<unsigned char> Patch2;
	std::vector<unsigned char> Patch3;

	Patch1.push_back(0x74);
	Patch2.push_back(0x2E);
	Patch3.push_back(0x5C);

	Variables::NoCD[0] = Patching::Patch(0x0041D6B0, Patch1, true);
	Variables::NoCD[1] = Patching::Patch(0x0041D6B3, Patch2, true);
	Variables::NoCD[2] = Patching::Patch(0x00502916, Patch3, true);

}

#endif

void Valkyrie::Patches::COBExtensionsHandler()
{
	Variables::COBExtensionsHandler[0] = Patching::Hook(0x00480770, (unsigned int)COBExtensionHandlerGetterFunc, 0x00000000, true);
	Variables::COBExtensionsHandler[1] = Patching::Hook(0x00480B20, (unsigned int)COBExtensionHandlerSetterFunc, 0x00000000, true);
}

void Valkyrie::Patches::DataFile()
{
	Variables::DataFile = Patching::Hook(0x0041D4E0, (unsigned int)DataFilePatchFunc, 0x0041D4E5, true);
}

void Valkyrie::Patches::UnitLimit()
{
	std::vector<unsigned char> Patch;

	unsigned char Bytes[4];

	int UnitLimit = int(Config::MaxUnitLimit);

	Bytes[0] = UnitLimit & 0xFF;
	Bytes[1] = (UnitLimit >> 8) & 0xFF;
	Bytes[2] = (UnitLimit >> 16) & 0xFF;
	Bytes[3] = (UnitLimit >> 24) & 0xFF;

	for (int i = 0; i < 4; i++)
	{
		Patch.push_back(Bytes[i]);
	}

	Variables::UnitLimitHook = Patching::Hook(0x0049163A, (unsigned int)UnitLimitFunc, 0x00000000, true);
	Variables::UnitLimitPatch = Patching::Patch(0x0044CAFE, Patch, true);
}

void Valkyrie::Patches::Pathfinding()
{
	std::vector<unsigned char> Patch;

	unsigned char Bytes[4];

	Bytes[0] = Config::PathfindingCycles & 0xFF;
	Bytes[1] = (Config::PathfindingCycles >> 8) & 0xFF;
	Bytes[2] = (Config::PathfindingCycles >> 16) & 0xFF;
	Bytes[3] = (Config::PathfindingCycles >> 24) & 0xFF;

	for (int i = 0; i < 4; i++)
	{
		Patch.push_back(Bytes[i]);
	}

	Variables::Pathfinding = Patching::Patch(0x0040EAD6, Patch, true);
}

void Valkyrie::Patches::CompositeBuffer()
{
	std::vector<unsigned char> Patch1;
	std::vector<unsigned char> Patch2;

	unsigned char Bytes1[4];
	unsigned char Bytes2[4];

	Bytes1[0] = Config::CompositeX & 0xFF;
	Bytes1[1] = (Config::CompositeX >> 8) & 0xFF;
	Bytes1[2] = (Config::CompositeX >> 16) & 0xFF;
	Bytes1[3] = (Config::CompositeX >> 24) & 0xFF;

	Bytes2[0] = Config::CompositeY & 0xFF;
	Bytes2[1] = (Config::CompositeY >> 8) & 0xFF;
	Bytes2[2] = (Config::CompositeY >> 16) & 0xFF;
	Bytes2[3] = (Config::CompositeY >> 24) & 0xFF;

	for (int i = 0; i < 4; i++)
	{
		Patch1.push_back(Bytes1[i]);
	}

	for (int i = 0; i < 4; i++)
	{
		Patch2.push_back(Bytes2[i]);
	}

	Variables::CompositeBuffer[0] = Patching::Patch(0x00458196, Patch1, true);
	Variables::CompositeBuffer[1] = Patching::Patch(0x0045819B, Patch2, true);
}

void Valkyrie::Patches::SFXLimit()
{
	std::vector<unsigned char> Patch1;
	std::vector<unsigned char> Patch2;

	unsigned int VectorSize;
	unsigned char Bytes1[4];
	unsigned char Bytes2[4];

	VectorSize = Config::SFXLimit * 10;

	Bytes1[0] = Config::SFXLimit & 0xFF;
	Bytes1[1] = (Config::SFXLimit >> 8) & 0xFF;
	Bytes1[2] = (Config::SFXLimit >> 16) & 0xFF;
	Bytes1[3] = (Config::SFXLimit >> 24) & 0xFF;

	Bytes2[0] = VectorSize & 0xFF;
	Bytes2[1] = (VectorSize >> 8) & 0xFF;
	Bytes2[2] = (VectorSize >> 16) & 0xFF;
	Bytes2[3] = (VectorSize >> 24) & 0xFF;

	for (int i = 0; i < 4; i++)
	{
		Patch1.push_back(Bytes1[i]);
	}

	for (int i = 0; i < 4; i++)
	{
		Patch2.push_back(Bytes2[i]);
	}

	Variables::SFXLimit[0] = Patching::Patch(0x00471C83, Patch2, true);

	for (int i = 0; i < 20; i++)
	{
		Variables::SFXLimit[i + 1] = Patching::Patch(Variables::SFXAddressArray[i], Patch1, true);
	}
}

void Valkyrie::Patches::MixingBuffers()
{
	Variables::MixingBuffers = Patching::Hook(0x004CF210, (unsigned int)MixingBuffersFunc, 0x004CF217, true);
}

void Valkyrie::Patches::MainWndProc()
{
	Variables::MainWndProc = Patching::Hook(0x004B5CC0, (unsigned int)WndProcFunc, 0x004B5CC8, true);
}

void Valkyrie::Patches::DrawBuildRectLive()
{
	std::vector<unsigned char> Patch;

	unsigned char Byte = 0x90;

	Patch.push_back(Byte);

	Variables::DrawBuildRectLive[0] = Patching::Patch(0x00469EB6, Patch, false);
	Variables::DrawBuildRectLive[1] = Patching::Patch(0x00469EBB, Patch, false);
	Variables::DrawBuildRectLive[2] = Patching::Patch(0x00469EBC, Patch, false);
	Variables::DrawBuildRectLive[3] = Patching::Patch(0x00469EC5, Patch, false);
	Variables::DrawBuildRectLive[4] = Patching::Patch(0x00469EC6, Patch, false);
	Variables::DrawBuildRectLive[5] = Patching::Patch(0x00469EC7, Patch, false);
	Variables::DrawBuildRectLive[6] = Patching::Patch(0x00469EC8, Patch, false);
	Variables::DrawBuildRectLive[7] = Patching::Patch(0x00469EC9, Patch, false);
	Variables::DrawBuildRectLive[8] = Patching::Patch(0x00469F02, Patch, false);
	Variables::DrawBuildRectLive[9] = Patching::Patch(0x00469F07, Patch, false);
	Variables::DrawBuildRectLive[10] = Patching::Patch(0x00469F08, Patch, false);
	Variables::DrawBuildRectLive[11] = Patching::Patch(0x00469F1E, Patch, false);
	Variables::DrawBuildRectLive[12] = Patching::Patch(0x00469F1F, Patch, false);
	Variables::DrawBuildRectLive[13] = Patching::Patch(0x00469F20, Patch, false);
	Variables::DrawBuildRectLive[14] = Patching::Patch(0x00469F21, Patch, false);
	Variables::DrawBuildRectLive[15] = Patching::Patch(0x00469F22, Patch, false);
}

void Valkyrie::Patches::RenderForTAHook()
{
	Variables::RenderForTAHook = Patching::Hook(0x004C63A0, (unsigned int)FinalRenderFunc, 0x004C63A6, true);
}

void Valkyrie::Patches::HotKeys()
{
	std::vector<unsigned char> Patch1;
	std::vector<unsigned char> Patch2;

	Patch1.push_back(Config::CtrlShiftBuildQueueIncDecAmount);
	Patch2.push_back(-1 * Config::CtrlShiftBuildQueueIncDecAmount);

	HotKeys::IdleConstructionSemaphore = TotalA::TA_CreateSemaphoreA(NULL, 1, 1, NULL);
	HotKeys::IdleFactorySemaphore = TotalA::TA_CreateSemaphoreA(NULL, 1, 1, NULL);
	HotKeys::UnitWithWeaponsSemaphore = TotalA::TA_CreateSemaphoreA(NULL, 1, 1, NULL);

	Variables::CtrlShiftBuildQueueLive[0] = Patching::Patch(0x0041AC14, Patch1, false);
	Variables::CtrlShiftBuildQueueLive[1] = Patching::Patch(0x0041AC18, Patch2, false);
}

void Valkyrie::Patches::CrashDumps()
{
	Variables::CrashDumps1 = Patching::Hook(0x0049EDFC, (unsigned int)CrashDumpExceptionFunc1, 0x0049EE01, true);
	Variables::CrashDumps2 = Patching::Hook(0x004DA2A0, (unsigned int)CrashDumpExceptionFunc2, 0x004DA2A9, true);
	Variables::CrashDumps3 = Patching::Hook(0x004D9BFE, (unsigned int)CrashDumpExceptionFunc3, 0x004D9C03, true);
	Variables::CrashDumps4 = Patching::Hook(0x0049E6B7, (unsigned int)CrashDumpExceptionFunc4, 0x0049E6BE, true);
}

void Valkyrie::Patches::LineOfSight()
{
	std::vector<unsigned char> Patch1;

	for(int i = 0; i < 0x13; i++)
	{
		Patch1.push_back(0x90);
	}

	Variables::LOSHooks[0] = Patching::Hook(0x00416BBB, (unsigned int)LOSCommandViewFunc, 0x00000000, true);
	Variables::LOSHooks[1] = Patching::Hook(0x004674AB, (unsigned int)LOSRadarCanDirectlySeeUnit, 0x00000000, true);
	Variables::LOSHooks[2] = Patching::Hook(0x0046750E, (unsigned int)LOSRadarLoopStart, 0x00000000, true);
	Variables::LOSHooks[3] = Patching::Hook(0x0046782F, (unsigned int)LOSRadarLoopCondition, 0x00000000, true);
	Variables::LOSHooks[4] = Patching::Hook(0x00466E6F, (unsigned int)LOSMiniMapUnitsProjectilesIsOwner, 0x00000000, true);

	Variables::LOSPatches[0] = Patching::Patch(0x0048BC3D, Patch1, true);

	Variables::LOSHooks[5] = Patching::Hook(0x00465AD4, (unsigned int)LOSPlayerSeeUnitIsOwnerAllowedToSee, 0x00000000, true);

	Variables::LOSHooks[6] = Patching::Hook(0x0046AC85, (unsigned int)LOSGUITextUnitResources, 0x00000000, true);
	Variables::LOSHooks[7] = Patching::Hook(0x0046B013, (unsigned int)LOSGUITextSeeCommHealth, 0x00000000, true);
	Variables::LOSHooks[8] = Patching::Hook(0x0046B10E, (unsigned int)LOSGUITextUnitMisc, 0x00000000, true);

	Variables::LOSHooks[9] = Patching::Hook(0x00481D63, (unsigned int)LOSUpdate1Start, 0x00000000, true);
	Variables::LOSHooks[10] = Patching::Hook(0x00481FAF, (unsigned int)LOSUpdate1Retry, 0x00000000, true);
	Variables::LOSHooks[11] = Patching::Hook(0x0048207B, (unsigned int)LOSUpdate1Retry, 0x00000000, true);
	Variables::LOSHooks[12] = Patching::Hook(0x00482283, (unsigned int)LOSUpdate2Start, 0x00000000, true);
	Variables::LOSHooks[13] = Patching::Hook(0x004824CF, (unsigned int)LOSUpdate2Retry, 0x00000000, true);
	Variables::LOSHooks[14] = Patching::Hook(0x00482597, (unsigned int)LOSUpdate2Retry, 0x00000000, true);

	Variables::LOSHooks[15] = Patching::Hook(0x00452B5E, (unsigned int)LOSPlayerSetAlliedStateJumpHook, 0x00000000, true);
	Variables::LOSHooks[16] = Patching::Hook(0x00452B54, (unsigned int)LOSPlayerSetAlliedStateReturnHook, 0x00000000, true);
	Variables::LOSHooks[17] = Patching::Hook(0x0046555F, (unsigned int)LOSSignalAlliedStateChange, 0x00000000, true);
}

void Valkyrie::Patches::LoadMap()
{
	Variables::LoadMap = Patching::Hook(0x00483638, (unsigned int)LoadMapFunc, 0x00483641, true);
}

void Valkyrie::Patches::RenderHooks()
{
	//Variables::SkipGameScreenRender = Patching::Hook(0x00468D8A, (unsigned int)BypassGameScreenRender, 0x00469F36, false);
	//Variables::PostGameScreenRender = Patching::Hook(0x00469F30, (unsigned int)PostGameScreenRender, 0x00469F36, true);

	Variables::SkipGameScreenRender = Patching::Hook(0x00469624, (unsigned int)BypassGameScreenRender2, 0x00469F23, false);

}

#ifdef DEBUG_BUILD
void Valkyrie::Patches::DebuggingThreadHook()
{
	Variables::DebuggingThreadReporter = Patching::Hook(0x0049EC63, (unsigned int)ReportThreadDataFunc, 0x0049EC68, true);
}
#endif




int Valkyrie::TAHook::BuildLineAndBuildRingWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == WM_KEYUP)
	{
		if (wParam == 0x58) // X key
		{
			WriteLine = false;
			WriteRing = false;
			ToggleBuildRectangle(STATE::ON); // On
		}
	}
	else if (msg == WM_LBUTTONDOWN)
	{
		if (WriteRing)
		{
			WriteBuildLine();
			return true;
		}
		else if (WriteLine && (TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
		{
			FootPrintX = GetUnitFootPrintX();
			FootPrintY = GetUnitFootPrintY();

			if (FootPrintX == 0)
			{
				FootPrintX = 1;
			}

			if (FootPrintY == 0)
			{
				FootPrintY = 1;
			}

			MouseEndX = GetMouseMapPosX();
			MouseEndY = GetMouseMapPosY();

			WriteBuildLine();

			MouseStartX = GetMouseMapPosX();
			MouseStartY = GetMouseMapPosY();

			LineMatrixX[0] = -1;
			LineMatrixY[0] = -1;

			return true;
		}
		else if (GetBuildOrderType() == PlayerOrderType::BUILD && (TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) > 0 && LOWORD(lParam) > 127)
		{
			FootPrintX = GetUnitFootPrintX();
			FootPrintY = GetUnitFootPrintY();

			if (FootPrintX == 0)
			{
				FootPrintX = 1;
			}

			if (FootPrintY == 0)
			{
				FootPrintY = 1;
			}

			WriteLine = true;

			ToggleBuildRectangle(STATE::OFF);

			MouseEndX = GetMouseMapPosX();
			MouseEndY = GetMouseMapPosY();
			MouseStartX = GetMouseMapPosX();
			MouseStartY = GetMouseMapPosY();

			LineMatrixX[0] = -1;
			LineMatrixY[0] = -1;

			CalculateBuildLine();

			return true;
		}
	}
	else if (msg == WM_LBUTTONUP)
	{
		if (WriteRing)
		{
			return true;
		}

		if ((TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) == 0)
		{
			WriteLine = false;
			ToggleBuildRectangle(STATE::ON);
		}
	}
	else if (msg == WM_RBUTTONDOWN)
	{
		if ((TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
		{
			return true;
		}
	}
	else if (msg == WM_RBUTTONUP)
	{
		WriteRing = false;
	}
	else if(msg == WM_MOUSEMOVE)
	{
		if (WriteLine)
		{
			MouseEndX = GetMouseMapPosX();
			MouseEndY = GetMouseMapPosY();

			CalculateBuildLine();
		}
		else if (GetBuildOrderType() == PlayerOrderType::BUILD && (TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
		{
			MouseOverUnit = TotalA::TA_MouseUnit();

			if (MouseOverUnit)
			{
				CalculateBuildRing();

				WriteRing = true;
			}
			else
			{
				WriteRing = false;

				if (!WriteLine)
				{
					ToggleBuildRectangle(STATE::ON);
				}
			}
		}
		else
		{
			WriteRing = false;
		}

	}
	else if(msg == WM_MOUSEWHEEL)
	{
		if (HIWORD(wParam) > 120)
		{
			if ((TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
			{
				BuildSpacing--;

				if (BuildSpacing < 0)
				{
					BuildSpacing = 0;
				}

				UpdateBuildSpacing();

				return true;
			}

		}
		else if (HIWORD(wParam) <= 120)
		{
			if ((TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) > 0)
			{
				BuildSpacing++;

				if (BuildSpacing > Config::MaxBuildSpacing)
				{
					BuildSpacing = Config::MaxBuildSpacing;
				}

				UpdateBuildSpacing();

				return true;
			}
		}
	}

	return false;
}

void Valkyrie::TAHook::ToggleBuildRectangle(bool state)
{
	if (state == STATE::ON)
	{
		Variables::DrawBuildRectLive[0].Revert();

		Variables::DrawBuildRectLive[1].Revert();
		Variables::DrawBuildRectLive[2].Revert();

		Variables::DrawBuildRectLive[3].Revert();
		Variables::DrawBuildRectLive[4].Revert();
		Variables::DrawBuildRectLive[5].Revert();
		Variables::DrawBuildRectLive[6].Revert();
		
		Variables::DrawBuildRectLive[7].Revert();

		Variables::DrawBuildRectLive[8].Revert();

		Variables::DrawBuildRectLive[9].Revert();
		Variables::DrawBuildRectLive[10].Revert();

		Variables::DrawBuildRectLive[11].Revert();
		Variables::DrawBuildRectLive[12].Revert();
		Variables::DrawBuildRectLive[13].Revert();
		Variables::DrawBuildRectLive[14].Revert();

		Variables::DrawBuildRectLive[15].Revert();
	}
	else
	{
		Variables::DrawBuildRectLive[0].RePatch();

		Variables::DrawBuildRectLive[1].RePatch();
		Variables::DrawBuildRectLive[2].RePatch();
		
		Variables::DrawBuildRectLive[3].RePatch();
		Variables::DrawBuildRectLive[4].RePatch();
		Variables::DrawBuildRectLive[5].RePatch();
		Variables::DrawBuildRectLive[6].RePatch();

		Variables::DrawBuildRectLive[7].RePatch();

		Variables::DrawBuildRectLive[8].RePatch();

		Variables::DrawBuildRectLive[9].RePatch();
		Variables::DrawBuildRectLive[10].RePatch();

		Variables::DrawBuildRectLive[11].RePatch();
		Variables::DrawBuildRectLive[12].RePatch();
		Variables::DrawBuildRectLive[13].RePatch();
		Variables::DrawBuildRectLive[14].RePatch();
		Variables::DrawBuildRectLive[15].RePatch();
	}
}

short Valkyrie::TAHook::GetUnitFootPrintX()
{
	short UnitId;

	UnitId = GetBuildUnitId();

	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov esi, dword ptr ds:[esi + 0x1439b]
		mov eax, 0x249
		xor edx, edx
		mov dx, UnitId
		mul edx
		add esi, eax
		add esi, 0x14a
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

short Valkyrie::TAHook::GetUnitFootPrintY()
{
	short UnitId;

	UnitId = GetBuildUnitId();

	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov esi, dword ptr ds:[esi + 0x1439b]
		mov eax, 0x249
		xor edx, edx
		mov dx, UnitId
		mul edx
		add esi, eax
		add esi, 0x14c
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

short Valkyrie::TAHook::GetBuildUnitId()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr [esi + 0x2cc4]
	}
}

unsigned short Valkyrie::TAHook::GetMouseMapPosX()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 2
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

unsigned short Valkyrie::TAHook::GetMouseMapPosY()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 10
		xor eax, eax
		mov ax, word ptr [esi]
	}
}

void Valkyrie::TAHook::SetMouseMapPosX(short PosX)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 2
		xor eax, eax
		mov ax, PosX
		mov word ptr [esi], ax
	}
}

void Valkyrie::TAHook::SetMouseMapPosY(short PosY)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2caa]
		add esi, 10
		xor eax, eax
		mov ax, PosY
		mov word ptr [esi], ax
	}
}

unsigned char Valkyrie::TAHook::GetBuildOrderType()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		xor eax, eax
		mov al, byte ptr [esi + 0x2CC3]
	}
}

void Valkyrie::TAHook::WriteBuildLine()
{
	int Index = 0;

	while (LineMatrixX[Index] != -1 && LineMatrixY[Index] != -1)
	{
		PlaceNewPendingBuilding(LineMatrixX[Index], LineMatrixY[Index]);

		Index++;
	}
}

void Valkyrie::TAHook::PlaceNewPendingBuilding(int PosX, int PosY)
{
	int OriginalMouseX = GetMouseMapPosX();
	int OriginalMouseY = GetMouseMapPosY();

	BuildLineMessage BLM;
	BLM.Status = 5;

	SetMouseMapPosX(PosX);
	SetMouseMapPosY(PosY);

	TotalA::TA_TestBuildSpot();

	TotalA::TA_MapClick(&BLM);

	SetMouseMapPosX(OriginalMouseX);
	SetMouseMapPosY(OriginalMouseY);
}

void Valkyrie::TAHook::UpdateBuildSpacing()
{
	if (WriteLine)
	{
		CalculateBuildLine();
	}

	if (WriteRing)
	{
		CalculateBuildRing();
	}
}

void Valkyrie::TAHook::CalculateBuildLine()
{
	int DeltaX = (MouseEndX - MouseStartX) / 16;
	int DeltaY = (MouseEndY - MouseStartY) / 16;
	int IncrementX = 16;
	int IncrementY = 16;
	int X = MouseStartX;
	int Y = MouseStartY;
	int FootPrintX = BuildSpacing + TAHook::FootPrintX;
	int FootPrintY = BuildSpacing + TAHook::FootPrintY;
	int Error;
	int Index;

	if (DeltaX < 0)
	{
		IncrementX = IncrementX * -1;
		DeltaX = DeltaX * -1;
	}
	
	if (DeltaY < 0)
	{
		IncrementY = IncrementY * -1;
		DeltaY = DeltaY * -1;
	}

	if (DeltaX > DeltaY)
	{
		DeltaX = DeltaX / FootPrintX;
		IncrementX *= FootPrintX;

		if (DeltaX >= 1000)
		{
			return;
		}

		LineMatrixX[DeltaX + 1] = -1;
		LineMatrixY[DeltaX + 1] = -1;

		MatrixLength = DeltaX;
		Direction = 1;

		Error = (DeltaY + DeltaY) - DeltaX;

		for (Index = 0; Index <= DeltaX; Index++)
		{
			LineMatrixX[Index] = X;
			LineMatrixY[Index] = Y;

			while (Error >= 0 && DeltaX != 0)
			{
				Error -= (DeltaX + DeltaX);
				Y += IncrementY;
			}

			Error += (DeltaY + DeltaY);
			X += IncrementX;
		}
	}
	else
	{
		DeltaY = DeltaY / FootPrintY;
		IncrementY *= FootPrintY;

		if (DeltaY >= 1000)
		{
			return;
		}

		LineMatrixX[DeltaY + 1] = -1;
		LineMatrixY[DeltaY + 1] = -1;

		MatrixLength = DeltaY;
		Direction = 2;

		Error = (DeltaX + DeltaX) - DeltaY;

		for (Index = 0; Index <= DeltaY; Index++)
		{
			LineMatrixX[Index] = X;
			LineMatrixY[Index] = Y;

			while (Error >= 0 && DeltaY != 0)
			{
				Error -= (DeltaY + DeltaY);
				X += IncrementX;
			}

			Error += (DeltaX + DeltaX);
			Y += IncrementY;
		}
	}
}

void Valkyrie::TAHook::CalculateBuildRing()
{
	//void* TAInGameUnitsArrayPtr;
	short Temp1;
	short Temp2;
	short Temp3;
	short Temp4;
	int FootPrintX;
	int FootPrintY;
	int PositionX;
	int PositionY;
	int UnitArrayOffset;

	UnitArrayOffset = MouseOverUnit * 0x118;

	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x92
		mov eax, [eax]
		add eax, 0x14A
		mov dx, [eax] // FootprintX
		mov Temp1, dx

		mov eax, dword ptr ds : [0x511de8]
		mov eax, dword ptr ds : [eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x92
		mov eax, [eax]
		add eax, 0x14C
		mov dx, [eax] // FootprintY
		mov Temp2, dx

		mov eax, dword ptr ds : [0x511de8]
		mov eax, dword ptr ds : [eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x76 // GridPosX
		mov dx, [eax]
		mov Temp3, dx

		mov eax, dword ptr ds : [0x511de8]
		mov eax, dword ptr ds : [eax + 0x14357]
		add eax, UnitArrayOffset
		add eax, 0x78
		mov dx, [eax] // GridPosY
		mov Temp4, dx
	}

	FootPrintX = Temp1 + BuildSpacing * 2;
	FootPrintY = Temp2 + BuildSpacing * 2;
	PositionX = Temp3 * 16 - BuildSpacing * 16;
	PositionY = Temp4 * 16 - BuildSpacing * 16;

	CalculateBuildRing(PositionX, PositionY, FootPrintX, FootPrintY);
}

void Valkyrie::TAHook::CalculateBuildRing(int PositionX, int PositionY, int FootPrintX, int FootPrintY)
{
	int Position;
	int Addition;
	int LineLengthX;
	int LineLengthY;

	int UnitFootX;
	int UnitFootY;

	Position = 0;
	Addition = 0;

	UnitFootX = GetUnitFootPrintX();
	UnitFootY = GetUnitFootPrintY();

	Addition = (FootPrintX % UnitFootX && UnitFootX < 3 && UnitFootY < 3) ? 1 : 0;
	LineLengthX = (FootPrintX / UnitFootX) + Addition + 1;

	Addition = (FootPrintY % UnitFootY && UnitFootX < 3 && UnitFootY < 3) ? 1 : 0;
	LineLengthY = (FootPrintY / UnitFootY) + Addition + 1;

	for (int i = 0; i < LineLengthX; i++)
	{
		LineMatrixX[Position] = PositionX + (UnitFootX * 16) / 2 + i * UnitFootX * 16;
		LineMatrixY[Position] = PositionY - (UnitFootY * 16) / 2;
		Position++;
	}

	for (int i = 0; i < LineLengthY; i++)
	{
		LineMatrixX[Position] = PositionX + FootPrintX * 16 + (UnitFootX * 16) / 2;
		LineMatrixY[Position] = PositionY + (UnitFootY * 16) / 2 + i * UnitFootY * 16;
		Position++;
	}

	for (int i = 0; i < LineLengthX; i++)
	{
		LineMatrixX[Position] = PositionX + FootPrintX * 16 - (UnitFootX * 16) / 2 - UnitFootX * 16 * i;
		LineMatrixY[Position] = PositionY + FootPrintY * 16 + (UnitFootY * 16) / 2;
		Position++;
	}

	for (int i = 0; i < LineLengthY; i++)
	{
		LineMatrixX[Position] = PositionX - (UnitFootX * 16) / 2;
		LineMatrixY[Position] = PositionY + FootPrintY * 16 - (UnitFootY * 16) / 2 - UnitFootY * 16 * i;
		Position++;
	}

	LineMatrixX[Position] = -1;
	LineMatrixY[Position] = -1;
}

void Valkyrie::TAHook::RenderTAHook()
{
	if (WriteLine || WriteRing)
	{
		ToggleBuildRectangle(STATE::ON);
		ShowBuildLine();
		ToggleBuildRectangle(STATE::OFF);
	}
}

void Valkyrie::TAHook::ShowBuildLine()
{
	int Index = 0;
	int OriginalMouseX;
	int OriginalMouseY;
	int Color;

	while (LineMatrixX[Index] != -1 && LineMatrixY[Index] != -1)
	{
		OriginalMouseX = GetMouseMapPosX();
		OriginalMouseY = GetMouseMapPosY();

		SetMouseMapPosX(LineMatrixX[Index]);
		SetMouseMapPosY(LineMatrixY[Index]);

		SetBuildSpotState(70);

		TotalA::TA_TestBuildSpot();

		if (GetBuildSpotState() == 70)
		{
			Color = 234;
		}
		else
		{
			Color = 214;
		}

		DrawBuildRectangle(
			(GetCircleSelectPos1X() - GetEyeMapPosX()) + 128,
			(GetCircleSelectPos1Y() - GetEyeMapPosY()) + 32 - (GetCircleSelectPos1Z() / 2),
			GetUnitFootPrintX() * 16,
			GetUnitFootPrintY() * 16,
			Color
			);

		Index++;

		SetMouseMapPosX(OriginalMouseX);
		SetMouseMapPosY(OriginalMouseY);
	}
}

void Valkyrie::TAHook::DrawBuildRectangle(int PosX, int PosY, int SizeX, int SizeY, int Color)
{
	RECT Rectangle =
	{
		PosX,
		PosY,
		PosX + SizeX,
		PosY + SizeY
	};

	int ScreenWidth = GetScreenWidth();
	int ScreenHeight = GetScreenHeight();

	if (Rectangle.top < 32)
	{
		Rectangle.top = 32;
	}

	if (Rectangle.top > ScreenHeight - 33)
	{
		Rectangle.top = ScreenHeight - 33;
	}

	if (Rectangle.bottom < 32)
	{
		Rectangle.bottom = 32;
	}

	if (Rectangle.bottom > ScreenHeight - 33)
	{
		Rectangle.bottom = ScreenHeight - 33;
	}

	if (Rectangle.left < 128)
	{
		Rectangle.left = 128;
	}

	if (Rectangle.left > ScreenWidth)
	{
		Rectangle.left = ScreenWidth;
	}

	if (Rectangle.right < 128)
	{
		Rectangle.right = 128;
	}

	if (Rectangle.right > ScreenWidth)
	{
		Rectangle.right = ScreenWidth;
	}

	TotalA::TA_DrawRect(NULL, &Rectangle, Color);

	Rectangle.top++;
	Rectangle.bottom++;
	Rectangle.left++;
	Rectangle.right++;

	if (Rectangle.top < 32)
	{
		Rectangle.top = 32;
	}

	if (Rectangle.top > ScreenHeight - 33)
	{
		Rectangle.top = ScreenHeight - 33;
	}

	if (Rectangle.bottom < 32)
	{
		Rectangle.bottom = 32;
	}

	if (Rectangle.bottom > ScreenHeight - 33)
	{
		Rectangle.bottom = ScreenHeight - 33;
	}

	if (Rectangle.left < 128)
	{
		Rectangle.left = 128;
	}

	if (Rectangle.left > ScreenWidth)
	{
		Rectangle.left = ScreenWidth;
	}

	if (Rectangle.right < 128)
	{
		Rectangle.right = 128;
	}

	if (Rectangle.right > ScreenWidth)
	{
		Rectangle.right = ScreenWidth;
	}

	TotalA::TA_DrawRect(NULL, &Rectangle, Color);
}

void Valkyrie::TAHook::SetBuildSpotState(char state)
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2cc6]
		mov al, state
		mov byte ptr [esi], al
	}
}

char Valkyrie::TAHook::GetBuildSpotState()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		lea esi, dword ptr [esi + 0x2cc6]
		xor eax, eax
		mov al, byte ptr [esi]
	}
}

unsigned int Valkyrie::TAHook::GetCircleSelectPos1X()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x2c92]
	}
}

unsigned int Valkyrie::TAHook::GetCircleSelectPos1Y()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x2c9a]
	}
}

unsigned int Valkyrie::TAHook::GetCircleSelectPos1Z()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x2c96]
	}
}

int	Valkyrie::TAHook::GetEyeMapPosX()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x1431f]
	}
}

int	Valkyrie::TAHook::GetEyeMapPosY()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x14323]
	}
}

int Valkyrie::TAHook::GetScreenWidth()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x37e1f]
	}
}

int Valkyrie::TAHook::GetScreenHeight()
{
	__asm
	{
		mov esi, dword ptr ds:[0x511de8]
		mov eax, dword ptr ds:[esi + 0x37e23]
	}
}

int Valkyrie::HotKeys::HotKeysWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	//if ((TotalA::TA_GetAsyncKeyState(VK_SPACE) & 0x8000) > 0)
	//{
	//	AlliedResourceBars::DoRenderResourceBars = true;
	//}
	//else
	//{
	//	AlliedResourceBars::DoRenderResourceBars = false;
	//}

#ifdef DEBUG_BUILD
	if (msg == WM_KEYDOWN)
	{
		if (wParam == VK_F12)
		{
			Debugging::CreateMemoryDumpManual();
		}
	}
#endif

	// Double Click Unit
	if (msg == WM_LBUTTONDBLCLK || msg == WM_RBUTTONDBLCLK)
	{
		if ((TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) == 0)
		{
			if (LOWORD(lParam) > Valkyrie::Accessors::GetGameScreenRect().left && LOWORD(lParam) < Valkyrie::Accessors::GetGameScreenRect().right &&
				HIWORD(lParam) > Valkyrie::Accessors::GetGameScreenRect().top && HIWORD(lParam) < Valkyrie::Accessors::GetGameScreenRect().bottom)
			{
				if (Valkyrie::Accessors::GetMouseOverUnit() != 0)
				{
					if (Valkyrie::Accessors::GetLocalPlayerArrayIndex() == Valkyrie::Accessors::GetMouseOverUnitPlayerArrayIndex())
					{
						UnselectAllUnits();
						SelectAllOfDoubleClickedUnitOnScreen();
						SelectUnitEffect();
						ApplyUnitMenu();
						return true;
					}
				}
			}
		}

		//return true;
	}
	else if (msg == WM_KEYDOWN)
	{
		if (wParam == 0x37 && ((TotalA::TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && (TotalA::TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) > 0))
		{
			AlliedResourceBars::DoRenderResourceBars = !AlliedResourceBars::DoRenderResourceBars;
			return true;
		}


		if (wParam == 0x38 && ((TotalA::TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && (TotalA::TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) > 0))
		{
			ChatMacro::RunChatMacro();
			return true;
		}

		if (wParam == VK_CONTROL)
		{
			Variables::CtrlShiftBuildQueueLive[0].RePatch();
			Variables::CtrlShiftBuildQueueLive[1].RePatch();
			return true;
		}

		// Ctrl+B - No Shift
		if (wParam == 0x42 && (TotalA::TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && (TotalA::TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0)
		{
			UnselectAllUnits();
			FindIdleConstruction();
			SelectUnitEffect();
			ApplyUnitMenu();
			return true;
		}

		// Ctrl+F - No Shift
		if (wParam == 0x46 && (TotalA::TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && (TotalA::TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0)
		{
			UnselectAllUnits();
			FindIdleFactory();
			SelectUnitEffect();
			ApplyUnitMenu();
			return true;
		}

		// Ctrl+S - No Shift
		if (wParam == 0x53 && (TotalA::TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) > 0 && (TotalA::TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0)
		{
			UnselectAllUnits();
			SelectUnitWithWeaponsOnScreen();
			SelectUnitEffect();
			ApplyUnitMenu();
			return true;
		}

		//return true;
	}
	else if (msg == WM_KEYUP)
	{
		if (wParam == VK_CONTROL)
		{
			Variables::CtrlShiftBuildQueueLive[0].Revert();
			Variables::CtrlShiftBuildQueueLive[1].Revert();
			return true;
		}

		//return true;
	}

	return false;
}

void Valkyrie::HotKeys::UnselectAllUnits()
{
	void* TAMemPtr;
	void* TAMemPlayersPtr;
	void* StartLocalPlayerUnits;
	void* EndLocalPlayerUnits;
	void* CurrentPlayerUnit;
	short UnitId;
	unsigned int UnitSelected;
	unsigned int UnitNanoframing;
	unsigned __int8 LocalHumanId;

	__asm
	{
		mov eax, ds:[0x511de8]
		mov TAMemPtr, eax

		xor edx, edx
		mov dl, ds:[eax + 0x2a42]
		mov LocalHumanId, dl

		xor edx, edx
		lea edx, [eax + 0x1b63]
		mov TAMemPlayersPtr, edx

		// set StartLocalPlayerUnits
		xor eax, eax
		xor edx, edx
		mov al, LocalHumanId
		mov edx, 0x14b
		mul edx
		add eax, 0x67 // PlayerUnits
		mov ecx, TAMemPlayersPtr
		add eax, ecx
		mov edx, [eax]
		mov StartLocalPlayerUnits, edx

		// set EndLocalPlayerUnits
		xor eax, eax
		xor edx, edx
		mov al, LocalHumanId
		mov edx, 0x14b
		mul edx
		add eax, 0x6B // End PlayerUnits
		mov ecx, TAMemPlayersPtr
		add eax, ecx
		mov edx, [eax]
		mov EndLocalPlayerUnits, edx
	}

	CurrentPlayerUnit = StartLocalPlayerUnits;

	while (CurrentPlayerUnit <= EndLocalPlayerUnits)
	{
		__asm
		{
			xor edx, edx
			mov eax, CurrentPlayerUnit
			mov dx, ds:[eax + 0xa6]
			mov UnitId, dx
		}

		if (UnitId)
		{
			__asm
			{
				mov eax, CurrentPlayerUnit
				mov edx, ds:[eax + 0x110]
				mov UnitSelected, edx
			}

			if ((UnitSelected & 0x20) != 0)
			{
				__asm
				{
					mov eax, CurrentPlayerUnit
					mov edx, ds:[eax + 0x104]
					mov UnitNanoframing, edx
				}

				if (UnitNanoframing == 0)
				{
					__asm
					{
						mov eax, UnitSelected
						and eax, 0xffffffef
						mov edx, CurrentPlayerUnit
						mov [edx + 0x110], eax
					}
				}
			}
		}

		__asm
		{
			mov eax, CurrentPlayerUnit
			add eax, 0x118
			mov CurrentPlayerUnit, eax
		}
	}

	__asm
	{
		mov eax, [TAMemPtr]
		lea eax, [eax + 0x37e8c]
		mov word ptr[eax], 0
	}
}

void Valkyrie::HotKeys::FindIdleConstruction()
{
	void* TAMemPtr;
	void* TAMemPlayersPtr;
	void* TAUnitStructStart;
	void* TAUnitStart;

	char* UnitHealth;
	unsigned short UnitXPos;
	unsigned short UnitZPos;
	int* IsUnit;
	int* UnitSelected;
	int* UnitOrderPtr;


	__int16 MyMaxUnitIndex;
	char LocalHumanId;

	int IsUnitBuilder;
	char IsUnitMobile;

	char* UnitState;

	static int LastConIndexTemp; // LastNum
	int ConIndexTemp; // i

	DWORD WaitSemaphore;

	WaitSemaphore = TotalA::TA_WaitForSingleObject(IdleConstructionSemaphore, INFINITE);

	if (WaitSemaphore == WAIT_FAILED)
	{
		return;
	}

	if (WaitSemaphore == WAIT_TIMEOUT)
	{
		ReleaseSemaphore(IdleConstructionSemaphore, 1, NULL);
		return;
	}

	__asm
	{
		mov eax, ds: [0x511de8]
		mov TAMemPtr, eax

		xor edx, edx
		mov dl, ds : [eax + 0x2a42]
		mov LocalHumanId, dl

		xor edx, edx
		lea edx, [eax + 0x1b63]
		mov TAMemPlayersPtr, edx

		//lea eax, [eax + 0x1b63]
		xor eax, eax
		xor edx, edx
		mov al, LocalHumanId
		mov edx, 0x14b
		mul edx
		add eax, 0x144
		mov ecx, TAMemPlayersPtr
		add eax, ecx
		xor edx, edx
		mov dx, [eax]
		mov MyMaxUnitIndex, dx
	}

	if (MyMaxUnitIndex < LastConIndexTemp) // MyMaxUnit < LastNum
	{
		LastConIndexTemp = 0; // LastNum = 0
	}

	ConIndexTemp = LastConIndexTemp; // i = LastNum

	while (ConIndexTemp <= MyMaxUnitIndex)
	{
		__asm
		{
			// Get Start
			mov eax, TAMemPtr
			lea eax, [eax + 0x1b63] // Player Array
			mov eax, [eax + 0x67] // Units Array
			mov TAUnitStructStart, eax

			mov ecx, ConIndexTemp
			mov eax, 0x118 // 0x14b
			mul ecx
			mov edx, TAUnitStructStart
			add edx, eax
			mov TAUnitStart, edx

			// Get UnitHealth
			mov eax, TAUnitStart
			lea eax, [eax + 0xf7]
			mov UnitHealth, eax

			// Get UnitXPos
			mov eax, TAUnitStart
			mov ax, [eax + 0x6a + 0x2]
			mov UnitXPos, ax

			// Get UnitZPos
			mov eax, TAUnitStart
			mov ax, [eax + 0x6a + 0xa]
			mov UnitZPos, ax

			// Get IsUnit
			mov eax, TAUnitStart
			mov IsUnit, eax

			// Get UnitSelected
			mov eax, TAUnitStart
			lea eax, [eax + 0x110]
			mov UnitSelected, eax

			// Get UnitOrderPtr
			mov eax, TAUnitStart
			mov eax, [eax + 0x5c]
			mov UnitOrderPtr, eax


			//mov eax, [eax]
			//add eax, 4
			//mov eax, TAUnitStart
			//lea eax, [eax + 0x60]
			//mov dl, [eax]

			// Get UnitState
			add eax, 4
			mov UnitState, eax
		}

		if (*UnitHealth != 0 && *UnitHealth != 1 && *IsUnit)
		{
			__asm
			{
				mov eax, TAUnitStart
				mov eax, [eax + 0x92]
				mov edx, eax
				mov eax, [eax + 0x241]
				and eax, 0x40 // is builder
				mov IsUnitBuilder, eax

				xor ecx, ecx
				mov eax, edx
				mov cl, [eax + 0x22f] // building or mobile
				mov IsUnitMobile, cl
			}

			if (IsUnitBuilder != 0 && IsUnitMobile != 0)
			{
				if (*UnitOrderPtr == NULL || *UnitState == 0x29 || *UnitState == 0x40)
				{
					if (LastConIndexTemp < ConIndexTemp) // LastNum < i
					{
						LastConIndexTemp = ConIndexTemp; // LastNum = i

						*UnitSelected |= 0x10;

						ScrollToCenter(UnitXPos, UnitZPos);
						ReleaseSemaphore(IdleConstructionSemaphore, 1, NULL);
						return;
					}
				}
			}
		}

		ConIndexTemp++; // i++

		if (MyMaxUnitIndex < ConIndexTemp) // MyMaxUnit < i
		{
			if (LastConIndexTemp == 0) // LastNum == 0
			{
				ReleaseSemaphore(IdleConstructionSemaphore, 1, NULL);
				return;
			}

			break;
		}
	}

	LastConIndexTemp = 0; // LastNum

	ReleaseSemaphore(IdleConstructionSemaphore, 1, NULL);
	FindIdleConstruction();
	return;

	//FindIdleConstruction();
}

void Valkyrie::HotKeys::FindIdleFactory()
{
	void* TAMemPtr;
	void* TAMemPlayersPtr;
	void* TAUnitStructStart;
	void* TAUnitStart;

	char* UnitHealth;
	unsigned short UnitXPos;
	unsigned short UnitZPos;
	int* IsUnit;
	unsigned int* UnitSelected;
	unsigned int* UnitOrderPtr;

	__int16 MyMaxUnitIndex;
	char LocalHumanId;

	int IsUnitBuilder;
	char IsUnitMobile;

	//char UnitState;

	float* NanoFrame;

	void* PlayerPtr1;

	unsigned char UnitOrderCobActionIndex;

	bool SecondTry;

	static int LastFactoryIndexTemp; // LastNum
	int FactoryIndexTemp; // i

	DWORD WaitSemaphore;

	WaitSemaphore = TotalA::TA_WaitForSingleObject(IdleFactorySemaphore, INFINITE);



	if (WaitSemaphore == WAIT_FAILED)
	{
		return;
	}

	if (WaitSemaphore == WAIT_TIMEOUT)
	{
		ReleaseSemaphore(IdleFactorySemaphore, 1, NULL);
		return;
	}

	SecondTry = true;

	while (SecondTry)
	{
		//SecondTry:
		SecondTry = false;

		__asm
		{
			mov eax, ds: [0x511DE8]
			mov TAMemPtr, eax

			xor edx, edx
			mov dl, ds : [eax + 0x2A42]
			mov LocalHumanId, dl

			xor edx, edx
			lea edx, [eax + 0x1B63]
			mov TAMemPlayersPtr, edx

			//lea eax, [eax + 0x1b63]
			xor eax, eax
			xor edx, edx
			mov al, LocalHumanId
			mov edx, 0x14b
			mul edx
			add eax, 0x144
			mov ecx, TAMemPlayersPtr
			add eax, ecx
			xor edx, edx
			mov dx, [eax]
			mov MyMaxUnitIndex, dx
		}

		if (MyMaxUnitIndex < LastFactoryIndexTemp) // MyMaxUnit < LastNum
		{
			LastFactoryIndexTemp = 0; // LastNum = 0
		}

		FactoryIndexTemp = LastFactoryIndexTemp; // i = LastNum

		while (FactoryIndexTemp <= MyMaxUnitIndex)
		{
			__asm
			{
				// Get Start
				mov eax, TAMemPtr
				lea eax, [eax + 0x1B63] // Player Array
				mov eax, [eax + 0x67] // Units Array
				mov TAUnitStructStart, eax

				mov ecx, FactoryIndexTemp
				mov eax, 0x118 // 0x14b
				mul ecx
				mov edx, TAUnitStructStart
				add edx, eax
				mov TAUnitStart, edx

				// Get UnitHealth
				mov eax, TAUnitStart
				lea eax, [eax + 0xF7]
				mov UnitHealth, eax

				// Get UnitXPos
				mov eax, TAUnitStart
				mov ax, [eax + 0x6A + 0x2]
				mov UnitXPos, ax

				// Get UnitZPos
				mov eax, TAUnitStart
				mov ax, [eax + 0x6A + 0xA]
				mov UnitZPos, ax

				// Get IsUnit
				mov eax, TAUnitStart
				mov IsUnit, eax

				// Get UnitSelected
				mov eax, TAUnitStart
				lea eax, [eax + 0x110]
				mov UnitSelected, eax

				mov eax, TAUnitStart
				lea eax, [eax + 0x104]
				mov NanoFrame, eax

				mov eax, TAUnitStart
				mov eax, [eax + 0xEC]
				mov PlayerPtr1, eax

				// Get UnitOrderPtr
				mov eax, TAUnitStart
				mov eax, [eax + 0x5C]
				mov UnitOrderPtr, eax
			}

			if ((*UnitSelected & 0x20) != 0)
			{
				if (*NanoFrame == 0.0F)
				{
					if (PlayerPtr1 != NULL)
					{
						__asm
						{
							mov eax, TAUnitStart
							mov eax, [eax + 0x92]
							mov edx, eax
							mov eax, [eax + 0x241]
							and eax, 0x40 // is builder
							mov IsUnitBuilder, eax

							xor ecx, ecx
							mov eax, edx
							mov cl, [eax + 0x22F] // building or mobile
							mov IsUnitMobile, cl
						}


						if (IsUnitBuilder != 0 && IsUnitMobile == 0)
						{

							if (UnitOrderPtr != NULL /*|| UnitState == 0x29 || || */)
							{
								__asm
								{
									mov eax, UnitOrderPtr
									mov al, [eax + 0x04]
									mov UnitOrderCobActionIndex, al
								}

								if (UnitOrderCobActionIndex == 0xC)
								{
									FactoryIndexTemp++;
									continue;
								}
							}

							if (LastFactoryIndexTemp < FactoryIndexTemp)
							{
								LastFactoryIndexTemp = FactoryIndexTemp;
								break;
							}
						}
					}
				}
			}

			FactoryIndexTemp++; // i++

		}

		if (FactoryIndexTemp <= MyMaxUnitIndex)
		{
			*UnitSelected |= 0x10;
			ScrollToCenter(UnitXPos, UnitZPos);
		}
		else
		{
			if (LastFactoryIndexTemp != 0)
			{
				LastFactoryIndexTemp = 0;

				SecondTry = 1;
				//goto SecondTry;
			}
		}

		// check second try
	}

	ReleaseSemaphore(IdleFactorySemaphore, 1, NULL);
	return;
}


void Valkyrie::HotKeys::SelectUnitWithWeaponsOnScreen()
{
	TotalA::TA_WaitForSingleObject(UnitWithWeaponsSemaphore, INFINITE);

	int NumberHotUnits;
	void* UnitsArrayStart;
	short* HotUnitArrayPtr;
	void* CurrentUnitPtr;
	int Counter;

	unsigned int* UnitSelected;
	float* NanoFrame;
	void* PlayerPtr1;

	char LocalPlayerId;
	char PlayerArrayIndex;

	unsigned int UnitTypeMask0;
	unsigned int UnitTypeMask1;

	char* YardMap;

	void* NoWeaponPtr;

	void* Weapon1;
	void* Weapon2;
	void* Weapon3;

	unsigned int Weapon1Mask;
	unsigned int Weapon2Mask;
	unsigned int Weapon3Mask;

	Counter = 0;

	__asm
	{
		mov eax, dword ptr ds : [0x511DE8]
		mov eax, [eax + 0x1439B]
		mov NoWeaponPtr, eax
	}

	__asm
	{
		mov eax, dword ptr ds : [0x511DE8]
		mov eax, [eax + 0x14367]
		mov NumberHotUnits, eax
	}

	while (Counter < NumberHotUnits)
	{
		__asm
		{
			mov eax, dword ptr ds:[0x511DE8]
			mov eax, [eax + 0x14357]
			mov UnitsArrayStart, eax

			mov eax, dword ptr ds:[0x511DE8]
			mov eax, [eax + 0x1435F]
			mov HotUnitArrayPtr, eax

			// Set Current
			mov eax, Counter
			mov edx, 2
			mul edx

			mov ecx, HotUnitArrayPtr
			add ecx, eax
			xor eax, eax
			mov ax, [ecx]


			// EDX = Index
			mov edx, 0x118
			mul edx
			mov edx, UnitsArrayStart
			add eax, edx
			// EAX = UnitPtr
			mov CurrentUnitPtr, eax

			// Now we can start the normal checks

			mov eax, CurrentUnitPtr
			lea eax, [eax + 0x110]
			mov UnitSelected, eax

			mov eax, CurrentUnitPtr
			lea eax, [eax + 0x104]
			mov NanoFrame, eax

			mov eax, CurrentUnitPtr
			mov eax, [eax + 0xEC]
			mov PlayerPtr1, eax
		}

		if ((*UnitSelected & 0x20) != 0)
		{
			if (*NanoFrame == 0.0F)
			{
				if (PlayerPtr1 != NULL)
				{
					__asm
					{
						mov eax, dword ptr ds : [0x511DE8]
						mov al, [eax + 0x2A42]
						mov LocalPlayerId, al

						mov eax, CurrentUnitPtr
						mov eax, [eax + 0xEC]
						mov al, [eax + 0x146]
						mov PlayerArrayIndex, al
					}

					if (LocalPlayerId == PlayerArrayIndex)
					{
						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0x92]
							mov eax, [eax + 0x241]
							mov UnitTypeMask0, eax
						}

						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0x92]
							mov eax, [eax + 0x245]
							mov UnitTypeMask1, eax
						}

						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0x92]
							mov eax, [eax + 0x14E]
							mov YardMap, eax
						}

						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0x92]
							mov eax, [eax + 0x1EE]
							mov Weapon1, eax
							mov eax, [eax + 0x111]
							mov Weapon1Mask, eax
						}

						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0x92]
							mov eax, [eax + 0x1F2]
							mov Weapon2, eax
							mov eax, [eax + 0x111]
							mov Weapon2Mask, eax
						}

						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0x92]
							mov eax, [eax + 0x1F6]
							mov Weapon3, eax
							mov eax, [eax + 0x111]
							mov Weapon3Mask, eax
						}

						if ((NoWeaponPtr != Weapon1 && Weapon1 != NULL && (Weapon1Mask & 0x1000000) == 0) ||
							(NoWeaponPtr != Weapon2 && Weapon2 != NULL && (Weapon2Mask & 0x1000000) == 0) ||
							(NoWeaponPtr != Weapon3 && Weapon3 != NULL && (Weapon3Mask & 0x1000000) == 0))
						{
							if (((UnitTypeMask1 & 0x20000) == 0) || ((UnitTypeMask0 & 0x4000) == 0))
							{
								if ((UnitTypeMask0 & 0x40) == 0)
								{
									if (YardMap == NULL)
									{
										if ((UnitTypeMask0 & 0x800) != 0x800)
										{
											*UnitSelected |= 0x10;
										}
									}
								}
							}
						}
					}
				}
			}
		}

		Counter++;
	}

	ReleaseSemaphore(UnitWithWeaponsSemaphore, 1, NULL);
}


void Valkyrie::HotKeys::SelectAllOfDoubleClickedUnitOnScreen()
{
	void* UnitsArrayStart;
	void* UnitsArrayEnd;
	void* PlayerUnitsArrayStart;
	void* PlayerUnitsArrayEnd;
	void* PlayersArray;
	void* CurrentUnitPtr;
	int NumberHotUnits;
	char LocalHumanPlayerIndex;
	char LocalHumanPlayerId;
	short* HotUnitsPtr;
	int Counter;
	int MouseOverUnit;
	short UnitInfoId;
	unsigned int* UnitSelected;
	float* NanoFrame;
	void* PlayerPtr1;
	short CurrentUnitInfoId;
	char CurrentUnitPlayerArrayIndex;

	TotalA::TA_WaitForSingleObject(SameUnitTypeSemaphore, INFINITE);

	Counter = 0;

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x14357]
		mov UnitsArrayStart, eax

		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x1435B]
		mov UnitsArrayEnd, eax

		mov eax, dword ptr ds:[0x511DE8]
		add eax, 0x1B63
		mov PlayersArray, eax
	}

	LocalHumanPlayerIndex = Accessors::GetLocalPlayerArrayIndex();

	__asm
	{
		xor eax, eax
		mov al, LocalHumanPlayerId
		mov edx, 0x14B
		mul edx
		mov edx, PlayersArray
		add eax, edx
		add eax, 0x67 // Player Units Array
		mov PlayerUnitsArrayStart, eax
		add eax, 4
		mov PlayerUnitsArrayEnd, eax
	}

	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x14367]
		mov NumberHotUnits, eax
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, [eax + 0x1435F]
		mov HotUnitsPtr, eax
	}

	MouseOverUnit = Accessors::GetMouseOverUnit();

	__asm
	{
		mov eax, MouseOverUnit
		mov edx, 0x118
		mul edx
		add eax, UnitsArrayStart
		mov ax, [eax + 0xA6]
		mov UnitInfoId, ax		
	}

	while (Counter < NumberHotUnits)
	{
		__asm
		{
			mov eax, 2
			mov edx, Counter
			mul edx
			add eax, HotUnitsPtr
			xor edx, edx
			mov dx, [eax] // EDX = Unit Index
			mov eax, 0x118
			mul edx // EAX = Offset From Beginning
			add eax, UnitsArrayStart
			mov CurrentUnitPtr, eax
		}

		__asm
		{
			mov eax, CurrentUnitPtr
			lea eax, [eax + 0x110]
			mov UnitSelected, eax

			mov eax, CurrentUnitPtr
			lea eax, [eax + 0x104]
			mov NanoFrame, eax

			mov eax, CurrentUnitPtr
			mov eax, [eax + 0xEC]
			mov PlayerPtr1, eax

			mov eax, CurrentUnitPtr
			mov ax, [eax + 0xA6]
			mov CurrentUnitInfoId, ax
		}

		if ((*UnitSelected & 0x20) != 0)
		{
			if (*NanoFrame == 0.0F)
			{
				if (CurrentUnitInfoId == UnitInfoId)
				{
					if(PlayerPtr1 != NULL)
					{
						__asm
						{
							mov eax, dword ptr ds:[0x511DE8]
							mov al, [eax + 0x2A42]
							mov LocalHumanPlayerId, al
						}

						__asm
						{
							mov eax, CurrentUnitPtr
							mov eax, [eax + 0xEC]
							mov al, [eax + 0x146]
							mov CurrentUnitPlayerArrayIndex, al
						}

						if (LocalHumanPlayerId == CurrentUnitPlayerArrayIndex)
						{
							*UnitSelected |= 0x10;
						}
					}
				}
			}
		}

		Counter++;
	}

	ReleaseSemaphore(SameUnitTypeSemaphore, 1, NULL);
}

void Valkyrie::HotKeys::SelectUnitEffect()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511de8]
		mov dl, [eax + 0x37ebe]
		or dl, 0x10
		mov byte ptr [eax + 0x37ebe], dl
		mov word ptr [eax + 0x37e9c], 0
	}
}

void Valkyrie::HotKeys::ApplyUnitMenu()
{
	char OriginalOrderType;

	__asm
	{
		mov eax, ds: [0x511de8]
		mov dl, [eax + 0x2cc3]
		mov OriginalOrderType, dl

		mov eax, 0x495860
		call eax

		mov eax, ds: [0x511de8]
		lea eax, [eax + 0x2cc3]
		mov dl, OriginalOrderType
		mov[eax], dl
	}
}

void Valkyrie::HotKeys::ScrollToCenter(short xPos, short zPos)
{
	int* TAMemPtr;
	int ScreenWidth;
	int ScreenHeight;
	int MaxScrollX;
	int MaxScrollZ;
	int* xPtr;
	int* zPtr;

	__asm
	{
		mov eax, ds: [0x511de8]
		mov TAMemPtr, eax

		lea eax, [eax + 0x14327]
		mov xPtr, eax

		mov eax, ds: [0x511de8]
		lea eax, [eax + 0x1432b]
		mov zPtr, eax

		mov edx, ds : [0x51fbd0]
		mov eax, [edx + 0xd4]
		mov ScreenWidth, eax
		mov eax, [edx + 0xd8]
		mov ScreenHeight, eax
	}

	xPos -= (ScreenWidth - 128) / 2;
	zPos -= (ScreenHeight - 64) / 2;

	if (xPos < 0)
	{
		xPos = 0;
	}

	if (zPos < 0)
	{
		zPos = 0;
	}

	MaxScrollX = Valkyrie::HotKeys::GetMaxScrollX();
	MaxScrollZ = Valkyrie::HotKeys::GetMaxScrollZ();

	if (xPos > MaxScrollX)
	{
		xPos = MaxScrollX;
	}

	if (zPos > MaxScrollZ)
	{
		zPos = MaxScrollZ;
	}

	*xPtr = xPos;
	*zPtr = zPos;
}

short Valkyrie::HotKeys::GetMaxScrollX()
{
	int* TAMemPtr;
	int ScreenWidth;
	int* MapSizeX;

	__asm
	{
		mov eax, ds: [0x511de8]
		mov TAMemPtr, eax

		mov eax, ds : [0x51fbd0]
		mov eax, [eax + 0xD4]
		mov ScreenWidth, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422b]
		mov MapSizeX, eax
	}

	return *MapSizeX - (ScreenWidth - 128);
}

short Valkyrie::HotKeys::GetMaxScrollZ()
{
	int* TAMemPtr;
	int ScreenHeight;
	int* MapSizeZ;

	__asm
	{
		mov eax, ds: [0x511de8]
		mov TAMemPtr, eax

		mov eax, ds : [0x51fbd0]
		mov eax, [eax + 0xD8]
		mov ScreenHeight, eax

		mov eax, TAMemPtr
		lea eax, [eax + 0x1422f]
		mov MapSizeZ, eax
	}

	return *MapSizeZ - (ScreenHeight - 64);
}

void Valkyrie::AlliedResourceBars::RenderResBars()
{
	int Width = 250;
	int Height = 50;
	int BarWidth = 120;
	int XBarOffset = 0;
	
	int CurrentAllyIndex = 0;
	//int TargetAllyIndexToCheck = 0;

	//XPos = ((Accessors::GetGameScreenRect().left + Accessors::GetGameScreenRect().right) / 2) - ((XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 32) / 2);
	XPos = Accessors::GetGameScreenRect().right - (XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 32) - 192;
	YPos = Accessors::GetGameScreenRect().top + 24;

	if (Valkyrie::Accessors::GetIsLocalPlayerWatcher())
	{
		for (int i = 0; i < 10; i++)
		{
			if (Valkyrie::Accessors::GetIsPlayerIndexExists(i))
			{
				//if (Accessors::GetAlliedState(Accessors::GetPlayerPtrFromIndex(Accessors::GetLocalPlayerArrayIndex()), i) == true)
				//{
				//if (Accessors::GetAlliedState(Accessors::GetPlayerPtrFromIndex(i), Accessors::GetLocalPlayerArrayIndex()) == true)
				//{
				RenderPlayerName(i, XPos, i * Height + YPos);
				RenderStorageOutline(i, XPos + XBarOffset, i * Height + YPos + 12, BarWidth, 12, 0x00);
				RenderStorageOutline(i, XPos + XBarOffset + BarWidth + 1 + 12 + 64, i * Height + YPos + 12, BarWidth, 12, 0x00);
				RenderStorageBar(i, RES_TYPE::METAL, XPos + XBarOffset + 1, i * Height + YPos + 13, BarWidth - 2, 10);
				RenderStorageBar(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, i * Height + YPos + 13, BarWidth - 2, 10);
				RenderCurrentStorage(i, RES_TYPE::METAL, XPos, i * Height + YPos + 17 + 14);
				RenderCurrentStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, i * Height + YPos + 17 + 14);
				RenderMaxStorage(i, RES_TYPE::METAL, XPos + 64, i * Height + YPos + 17 + 14);
				RenderMaxStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 56 + 16 + 64, i * Height + YPos + 17 + 14);
				RenderCurrentIncome(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, i * Height + YPos + 12);
				RenderCurrentIncome(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, i * Height + YPos + 12);
				RenderCurrentExpense(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, i * Height + YPos + 28);
				RenderCurrentExpense(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, i * Height + YPos + 28);

				//CurrentAllyIndex++;
			//}
			//}
			}
		}
	}
	else
	{
		for (int i = 0; i < 10; i++)
		{
			//if (Accessors::GetAlliedState(Accessors::GetPlayerPtrFromIndex(Accessors::GetLocalPlayerArrayIndex()), i) == true)
			//{
			if (Valkyrie::Accessors::GetIsPlayerIndexExists(i))
			{
				if (Accessors::GetAlliedState(Accessors::GetPlayerPtrFromIndex(i), Accessors::GetLocalPlayerArrayIndex()) == true)
				{
					RenderPlayerName(i, XPos, CurrentAllyIndex * Height + YPos);
					RenderStorageOutline(i, XPos + XBarOffset, CurrentAllyIndex * Height + YPos + 12, BarWidth, 12, 0x00);
					RenderStorageOutline(i, XPos + XBarOffset + BarWidth + 1 + 12 + 64, CurrentAllyIndex * Height + YPos + 12, BarWidth, 12, 0x00);
					RenderStorageBar(i, RES_TYPE::METAL, XPos + XBarOffset + 1, CurrentAllyIndex * Height + YPos + 13, BarWidth - 2, 10);
					RenderStorageBar(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, CurrentAllyIndex * Height + YPos + 13, BarWidth - 2, 10);
					RenderCurrentStorage(i, RES_TYPE::METAL, XPos, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderCurrentStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + 64, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderMaxStorage(i, RES_TYPE::METAL, XPos + 64, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderMaxStorage(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 56 + 16 + 64, CurrentAllyIndex * Height + YPos + 17 + 14);
					RenderCurrentIncome(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, CurrentAllyIndex * Height + YPos + 12);
					RenderCurrentIncome(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, CurrentAllyIndex * Height + YPos + 12);
					RenderCurrentExpense(i, RES_TYPE::METAL, XPos + XBarOffset + 1 + BarWidth + 1 + 12, CurrentAllyIndex * Height + YPos + 28);
					RenderCurrentExpense(i, RES_TYPE::ENERGY, XPos + XBarOffset + 1 + BarWidth + 1 + 12 + BarWidth + 56 + 24, CurrentAllyIndex * Height + YPos + 28);

					CurrentAllyIndex++;
				}
			}
			//}
		}
	}
}

void Valkyrie::AlliedResourceBars::RenderBackground(int Index, int X, int Y, int Width, int Height)
{
	Rendering::DrawRectangleFillColor(X, Y, Width, Height, 0xFF);
}

void Valkyrie::AlliedResourceBars::RenderPlayerName(int Index, int X, int Y)
{
	char* PlayerName = Valkyrie::Accessors::GetPlayerName(Index);

	RenderText(X, Y, 8, 8, Rendering::CustomFont, std::string(PlayerName), 0x92);
}

void Valkyrie::AlliedResourceBars::RenderCurrentStorage(int Index, int Type, int X, int Y)
{
	std::string Text;

	CurrentPlayerDraw = Accessors::GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		Text += std::to_string(int(CurrentPlayerDraw.CurrentMetal));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0x82);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		Text += std::to_string(int(CurrentPlayerDraw.CurrentEnergy));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0xD0);
	}
}

void Valkyrie::AlliedResourceBars::RenderMaxStorage(int Index, int Type, int X, int Y)
{
	std::string Text;

	CurrentPlayerDraw = Accessors::GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		Text += std::to_string(int(CurrentPlayerDraw.MetalStorageMax));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0x82);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		Text += std::to_string(int(CurrentPlayerDraw.EnergyStorageMax));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0xD0);
	}
}

void Valkyrie::AlliedResourceBars::RenderCurrentIncome(int Index, int Type, int X, int Y)
{
	std::string Text = "+";

	CurrentPlayerDraw = Accessors::GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		Text += std::to_string(int(CurrentPlayerDraw.MetalProduction));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0xE9);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		Text += std::to_string(int(CurrentPlayerDraw.EnergyProduction));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0xE9);
	}
}

void Valkyrie::AlliedResourceBars::RenderCurrentExpense(int Index, int Type, int X, int Y)
{
	std::string Text = "-";

	CurrentPlayerDraw = Accessors::GetPlayerResourcesStruct(Index);

	if (Type == RES_TYPE::METAL)
	{
		Text += std::to_string(int(CurrentPlayerDraw.MetalExpense));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0xF9);
	}

	if (Type == RES_TYPE::ENERGY)
	{
		Text += std::to_string(int(CurrentPlayerDraw.EnergyExpense));
		RenderText(X, Y, 8, 8, Rendering::CustomFont, Text, 0xF9);
	}
}

void Valkyrie::AlliedResourceBars::RenderStorageOutline(int Index, int X, int Y, int Width, int Height, unsigned char Color)
{
	Rendering::DrawRectangleFillColor(X, Y, Width, Height, Color);
}

void Valkyrie::AlliedResourceBars::RenderStorageBar(int Index, int Type, int X, int Y, int Width, int Height)
{
	int CurrentWidth;

	CurrentPlayerDraw = Accessors::GetPlayerResourcesStruct(Index);

	// Background
	//Rendering::DrawRectangleFillColor(X, Y, Width, Height, 0x00);

	if (Type == RES_TYPE::METAL)
	{
		CurrentWidth = int((CurrentPlayerDraw.CurrentMetal / CurrentPlayerDraw.MetalStorageMax) * Width);
		Rendering::DrawRectangleFillColor(X, Y, CurrentWidth, Height, 0x82); // Actual Resources (Metal/Energy)
	}
	else if (Type == RES_TYPE::ENERGY)
	{
		CurrentWidth = int((CurrentPlayerDraw.CurrentEnergy / CurrentPlayerDraw.EnergyStorageMax) * Width);
		Rendering::DrawRectangleFillColor(X, Y, CurrentWidth, Height, 0xD0); // Actual Resources (Metal/Energy)
	}
}

void Valkyrie::AlliedResourceBars::RenderText(int DestX, int DestY, int Width, int Height, unsigned char* Font, std::string Text, unsigned char Color)
{
	unsigned char* DestSurface = (unsigned char*)Rendering::GetBackBuffer();
	unsigned char* SrcSurface = Font;
	unsigned char* CharacterToDraw = Rendering::CharacterBuffer8x8;

	int CharacterIndex;
	int ImageOffset;

	for (size_t i = 0; i < Text.size(); i++)
	{
		Text[i] = std::toupper(Text[i]);
	}

	for (size_t i = 0; i < Text.size(); i++)
	{
		if (Text[i] >= '0' && Text[i] <= '9')
		{
			CharacterIndex = Text[i] - 48;
		}

		else if (Text[i] >= 'A' && Text[i] <= 'Z')
		{
			CharacterIndex = 10 + Text[i] - 65;
		}

		else if (Text[i] == '+')
		{
			CharacterIndex = 36;
		}

		else if (Text[i] == '-')
		{
			CharacterIndex = 37;
		}

		else if (Text[i] == '_')
		{
			CharacterIndex = 38;
		}

		else if (Text[i] == ' ')
		{
			CharacterIndex = 40;
		}

		else
		{
			CharacterIndex = 39;
		}

		ImageOffset = CharacterIndex * Width * Height;

		for (int y = 0; y < Height; y++)
		{
			for (int x = 0; x < Width; x++)
			{
				if (SrcSurface[ImageOffset + y * Width + x] == 0xFF)
				{
					CharacterToDraw[y * Width + x] = Color;
				}
				else
				{
					CharacterToDraw[y * Width + x] = 0x00;
				}

				//memcpy(CharacterToDraw, (void*)ImageOffset, Width * Height);
			}
		}

		Rendering::DrawRectanglePixelData(DestX, DestY, Width, Height, CharacterToDraw);

		DestX += Width;
	}
}

int Valkyrie::Rendering::GetScreenWidth()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, dword ptr ds:[eax + 0x37E1F]
	}
}

int Valkyrie::Rendering::GetScreenHeight()
{
	__asm
	{
		mov eax, dword ptr ds:[0x511DE8]
		mov eax, dword ptr ds:[eax + 0x37E23]
	}
}

void* Valkyrie::Rendering::GetBackBuffer()
{
	__asm
	{
		mov eax, dword ptr ds:[0x51FBD0]
		mov eax, dword ptr ds:[eax + 0xBC]
		add eax, 48
	}
}

void Valkyrie::Rendering::DrawRectangleFillColor(int DestX, int DestY, int Width, int Height, unsigned char Color)
{
	unsigned char* DestSurface = (unsigned char*)GetBackBuffer();

	int CurrentSrcX = DestX;
	int CurrentSrcY = DestY;
	int EndSrcX = DestX + Width;
	int EndSrcY = DestY + Height;
	int ResultSrcWidth = Width;
	int ResultSrcHeight = Height;
	int SubWidth = 0;
	int SubHeight = 0;

	ScreenWidth = GetScreenWidth();
	ScreenHeight = GetScreenHeight();

	if (!(DestX + Width < 0 || DestX > ScreenWidth ||
		DestY + Height < 0 || DestY > ScreenHeight))
	{
		if (DestX < 0)
		{
			SubWidth = -DestX;
			CurrentSrcX = 0;
			ResultSrcWidth = Width - SubWidth;
		}

		if (DestY < 0)
		{
			SubHeight = -DestY;
			CurrentSrcY = 0;
			ResultSrcHeight = Height - SubHeight;
		}

		if (DestX + Width > ScreenWidth)
		{
			ResultSrcWidth = ScreenWidth - DestX;
			EndSrcX = ScreenWidth;
		}

		if (DestY + Height > ScreenHeight)
		{
			ResultSrcHeight = ScreenHeight - DestY;
			EndSrcY = ScreenHeight;
		}

		DestSurface += CurrentSrcY * ScreenWidth + CurrentSrcX;

		for (int y = CurrentSrcY; y < EndSrcY; y++)
		{
			memset(DestSurface, Color, ResultSrcWidth);

			DestSurface += ScreenWidth;
		}
	}
}

void Valkyrie::Rendering::DrawRectanglePixelData(int DestX, int DestY, int Width, int Height, void* PixelData)
{
	unsigned char* DestSurface = (unsigned char*)GetBackBuffer();
	unsigned char* SrcSurface = (unsigned char*)PixelData;

	int CurrentSrcImageX = 0;
	int CurrentSrcImageY = 0;
	int CurrentSrcX = DestX;
	int CurrentSrcY = DestY;
	int EndSrcX = DestX + Width;
	int EndSrcY = DestY + Height;
	int ResultSrcWidth = Width;
	int ResultSrcHeight = Height;
	int SubWidth = 0;
	int SubHeight = 0;

	ScreenWidth = GetScreenWidth();
	ScreenHeight = GetScreenHeight();

	if (!(DestX + Width < 0 || DestX > ScreenWidth ||
		DestY + Height < 0 || DestY > ScreenHeight))
	{
		if (DestX < 0)
		{
			SubWidth = -DestX;
			CurrentSrcX = 0;
			ResultSrcWidth = Width - SubWidth;
			CurrentSrcImageX = SubWidth;
		}

		if (DestY < 0)
		{
			SubHeight = -DestY;
			CurrentSrcY = 0;
			ResultSrcHeight = Height - SubHeight;
			CurrentSrcImageY = SubHeight;
		}

		if (DestX + Width > ScreenWidth)
		{
			ResultSrcWidth = ScreenWidth - DestX;
			EndSrcX = ScreenWidth;
		}

		if (DestY + Height > ScreenHeight)
		{
			ResultSrcHeight = ScreenHeight - DestY;
			EndSrcY = ScreenHeight;
		}

		DestSurface += CurrentSrcY * ScreenWidth + CurrentSrcX;
		SrcSurface += CurrentSrcImageY * Width + CurrentSrcImageX;

		for (int y = CurrentSrcY; y < EndSrcY; y++)
		{
			memcpy(DestSurface, SrcSurface, ResultSrcWidth);

			DestSurface += ScreenWidth;
			SrcSurface += Width;
		}
	}
}

void Valkyrie::Rendering::RenderInGame()
{
	if (Accessors::GetGameState() == GAME_STATE::IN_GAME)
	{
		TAHook::RenderTAHook();

		if (Valkyrie::AlliedResourceBars::DoRenderResourceBars == true)
		{
			AlliedResourceBars::RenderResBars();
		}
	}
}

void Valkyrie::MegaMap::LoadMegaMap(TNTMapHeader* TNT)
{
	int MapDataPitch;
	int MapDataWidth;
	int MapDataHeight;
	float XInterval;
	float YInterval;
	float MegaMapScale;

	int MegaMapImageYStart;
	int MegaMapTileIndexYOffset;
	int MegaMapTileYOffset;

	int TileIndex;
	int MegaMapByte;
	LPBYTE TileImageStart;

	GameScreenWidth = Accessors::GetGameScreenWidth();
	GameScreenHeight = Accessors::GetGameScreenHeight();

	MegaMapImage = (LPBYTE)malloc(GameScreenWidth * GameScreenHeight);
	MapWidth = GameScreenWidth;
	MapHeight = GameScreenHeight;

	memset(&TNTMap, 0, sizeof(TNTMapHeader));

	// Parse Map Header

	memcpy(&TNTMap, TNT, sizeof(TNTMapHeader));

	TNTMap.Width /= 2;
	TNTMap.Height /= 2;
	TNTMap.MapDataPtr = (WORD*)((int)(TNTMap.MapDataPtr) + (int)TNT);
	TNTMap.MapAttrPtr = (WORD*)((int)(TNTMap.MapAttrPtr) + (int)TNT);
	TNTMap.TileGFXPtr = (LPBYTE)((int)(TNTMap.TileGFXPtr) + (int)TNT);
	TNTMap.TileAnimPtr = ((int)(TNTMap.TileAnimPtr) + (int)TNT);
	TNTMap.MiniMapPtr = (LPBYTE)((int)(TNTMap.MiniMapPtr) + (int)TNT);

	// Parse Map

	MapDataPitch = TNTMap.Width;
	MapDataWidth = MapDataPitch - 1;
	MapDataHeight = TNTMap.Height - 4;
	MegaMapScale = float(MapWidth) / float(MapHeight);

	if ((MapDataHeight * MegaMapScale) < MapDataWidth)
	{
		MapHeight = int(float(MapWidth) / float(MapDataWidth) * float(MapDataHeight));
	}
	else if(MapDataHeight * MegaMapScale > MapDataWidth)
	{
		MapWidth = int(float(MapHeight) / float(MapDataHeight) * float(MapDataWidth));
	}
	else
	{
		if (MapWidth < MapHeight)
		{
			MapHeight = MapWidth;
		}
		else
		{
			MapWidth = MapHeight;
		}
	}

	XInterval = (float(MapDataWidth) * 32.0f) / MapWidth;
	YInterval = (float(MapDataHeight) * 32.0f) / MapHeight;

	if (XInterval < 1)
	{
		XInterval = 1;
	}

	if (YInterval < 1)
	{
		YInterval = 1;
	}

	if (MapWidth * MapHeight < GameScreenWidth * GameScreenHeight)
	{
		free(MegaMapImage);
		MegaMapImage = (LPBYTE)malloc(MapWidth * MapHeight);
	}

	for (int YPos = 0, Y2 = 0; YPos < MapHeight; YPos++, Y2 = int(YPos * YInterval))
	{
		MegaMapImageYStart = YPos * MapWidth;
		MegaMapTileIndexYOffset = (Y2 / 32) * MapDataPitch;
		MegaMapTileYOffset = (Y2 % 32) * 32;

		for (int XPos = 0, X2 = 0; XPos < MapWidth; XPos++, X2 = int(XPos * XInterval))
		{
			TileIndex = TNTMap.MapDataPtr[MegaMapTileIndexYOffset + X2 / 32];

			if (TileIndex < 0)
			{
				TileIndex = 0;
			}

			TileImageStart = &(TNTMap.TileGFXPtr[TileIndex * 32 * 32]);

			MegaMapByte = TileImageStart[MegaMapTileYOffset + (X2 % 32)];

			MegaMapImage[MegaMapImageYStart + XPos] = MegaMapByte;
		}
	}

	//MegaMapRect = Accessors::GetGameScreenRect(); // should work? Nope!

	MegaMapPosition.left = Accessors::GetGameScreenRect().left;
	MegaMapPosition.top = Accessors::GetGameScreenRect().top;
	MegaMapPosition.right = MegaMapPosition.left + GameScreenWidth;
	MegaMapPosition.bottom = MegaMapPosition.top + GameScreenHeight;

	MegaMapRect.left = 0;
	MegaMapRect.top = 0;
	MegaMapRect.right = MegaMapPosition.right - MegaMapPosition.left;
	MegaMapRect.bottom = MegaMapPosition.bottom - MegaMapPosition.top;

	if (MapWidth < MegaMapRect.right && MegaMapRect.right - MapWidth > 2)
	{
		MegaMapRect.left = (MegaMapRect.right - MapWidth) / 2;
		MegaMapRect.right = (MegaMapRect.left + MapWidth);

		EmptyRect1.top = MegaMapPosition.top;
		EmptyRect1.bottom = MegaMapPosition.bottom;
		EmptyRect1.left = MegaMapPosition.left;
		EmptyRect1.right = MegaMapPosition.right - (MegaMapRect.right - MapWidth) / 2;

		EmptyRect2.top = MegaMapPosition.top;
		EmptyRect2.bottom = MegaMapPosition.bottom;
		EmptyRect2.left = MegaMapPosition.left + (MegaMapRect.left + MapWidth);
		EmptyRect2.right = MegaMapPosition.right;
	}

	if (MapHeight < MegaMapRect.bottom && MegaMapRect.bottom - MapHeight > 2)
	{
		MegaMapRect.top = (MegaMapRect.bottom - MapHeight) / 2;
		MegaMapRect.bottom = (MegaMapRect.top + MapHeight);

		EmptyRect1.top = MegaMapPosition.top;
		EmptyRect1.bottom = MegaMapPosition.top + (MegaMapPosition.bottom - MapHeight) / 2;
		EmptyRect1.left = MegaMapPosition.left;
		EmptyRect1.right = MegaMapPosition.right;

		EmptyRect2.top = MegaMapPosition.bottom - (MegaMapPosition.top + MapHeight);
		EmptyRect2.bottom = MegaMapPosition.bottom;
		EmptyRect2.left = MegaMapPosition.left;
		EmptyRect2.right = MegaMapPosition.right;
	}

	MegaMapPosition.top += MegaMapRect.top;
	MegaMapPosition.bottom = MegaMapPosition.top + MapHeight;
	MegaMapPosition.left += MegaMapRect.left;
	MegaMapPosition.right = MegaMapPosition.left + MapWidth;

	TAMapTAPos.left = 0;
	TAMapTAPos.top = 0;
	TAMapTAPos.right = (TNT->Width - 1) * 16;
	TAMapTAPos.bottom = (TNT->Height - 4) * 16;

	// LOS Map

	LOSMap = (LPBYTE)malloc(MapWidth * MapHeight/* + 1*/);

	// Units Map

	MegaWeaponColor1 = Accessors::GetDesktopGUIRadarObjectColorByIndex(6);
	MegaWeaponColor2 = 1;
	MegaWeaponColor3 = 1;
	MegaRadarColor = Accessors::GetDesktopGUIRadarObjectColorByIndex(10);
	MegaSonarColor = Accessors::GetDesktopGUIRadarObjectColorByIndex(10);
	MegaRadarJamColor = Accessors::GetDesktopGUIRadarObjectColorByIndex(12);
	MegaSonarJamColor = Accessors::GetDesktopGUIRadarObjectColorByIndex(12);
	MegaAntiNukeColor = Accessors::GetDesktopGUIRadarObjectColorByIndex(15);

	// Unit Colors Here

	// 

	//

	// Rest of Init is simple / not doing at the moment




	// Done!
}

void Valkyrie::MegaMap::RenderMap()
{
	//LPBYTE LocalMegaMapSurface;
	DWORD TickCount;

	if (Accessors::GetGameState() == GAME_STATE::IN_GAME)
	{
		if (RenderMegaMap == true)
		{
			//LocalMegaMapSurface = MegaMapImage;
			TickCount = TotalA::TA_GetTickCount();

			if (TickCount >= NextTickCount)
			{
				if (MegaMapSurface == 0)
				{
					MegaMapSurface = (LPBYTE)malloc(MapWidth * MapHeight);
				}

				// Clear MegaMapSurface
				//memset(MegaMapSurface, 0, MapWidth * MapHeight);

				memcpy(MegaMapSurface, MegaMapImage, MapWidth * MapHeight);

				// LOS Map
				DrawLOSOnMegaMapSurface();

				// Units Map
				DrawUnitsOnMegaMapSurface();

				// Projectiles Map
				DrawProjectilesOnMegaMapSurface(); // To Do


				LastMegaMapSurface = MegaMapSurface;

				// Make into Config
				NextTickCount = TickCount + int(1000.0f / 30);
			}

			Rendering::DrawRectangleFillColor(EmptyRect1.left, EmptyRect1.top, EmptyRect1.right - EmptyRect1.left, EmptyRect1.bottom - EmptyRect1.top, 0x00);
			Rendering::DrawRectangleFillColor(EmptyRect2.left, EmptyRect2.top, EmptyRect2.right - EmptyRect2.left, EmptyRect2.bottom - EmptyRect2.top, 0x00);

			Rendering::DrawRectanglePixelData(MegaMapPosition.left, MegaMapPosition.top, MapWidth, MapHeight, LastMegaMapSurface);
		}
	}
}

void Valkyrie::MegaMap::DrawLOSOnMegaMapSurface(/*LPBYTE MapSurface*/)
{
	//int Line;
	//int SrcLine;

	char PlayerId;
	int MapX;
	int MapY;
	float XScale;
	float YScale;
	float MappedMemoryWidth;
	float MappedMemoryHeight;
	int i, j;
	int YOff;
	int LOSBitYOff;
	int PlayerMapX;
	int PlayerMapY;
	char SeaLevel;
	float LOSWidth;
	float LOSHeight;
	void* PlayerPtr;
	LPBYTE PlayerLOSMap;
	LPWORD LOSMemory;
	BYTE GrayTable[256];
	void* GrayTablePtr;

	//if (LOSMap)
	//{
	//	for (int j = 0; j < MapHeight; j++)
	//	{
	//		Line = MapWidth * j;
	//		SrcLine = MapWidth * j;

	//		for (int i = 0; i < MapWidth; i++)
	//		{
	//			//LOSMap[Line + i] = MegaMapSurface[SrcLine + i];
	//		}
	//	}
	//}

	//LOSMap = MegaMapSurface;

	// No Mapping
	if ((Accessors::GetLOSType() & 1) == 1)
	{
		// Not Permanent
		if ((Accessors::GetLOSType() & 2) != 2)
		{
			__asm
			{
				mov esi, dword ptr ds : [0x511DE8]
				xor eax, eax
				mov al, [esi + 0x2A43]
				mov PlayerId, al

				add esi, 0x1B63
				xor eax, eax
				mov al, PlayerId
				mov edx, 0x14B
				mul edx
				add esi, eax
				mov PlayerPtr, esi

				mov esi, dword ptr ds : [0x511DE8]
				mov eax, [esi + 0x14233]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapX, eax

				mov eax, [esi + 0x14237]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapY, eax

				mov eax, [esi + 0x14273]
				mov LOSMemory, eax
			}

			XScale = float(MapX) / float(MapWidth);
			YScale = float(MapY) / float(MapHeight);

			for (i = 0, MappedMemoryHeight = 0.0f; i < MapHeight; i++, MappedMemoryHeight += YScale)
			{
				YOff = i * MapWidth;
				LOSBitYOff = int(MappedMemoryHeight) * MapX;

				if ((((LOSMemory[LOSBitYOff + int(MappedMemoryWidth)]) & (1 << PlayerId)) >> PlayerId) == 0)
				{
					MegaMapSurface[YOff + j] = 0;
				}
			}
		}
		else
		{
			__asm
			{
				mov esi, dword ptr ds : [0x511DE8]
				xor eax, eax
				mov al, [esi + 0x2A43]
				mov PlayerId, al

				add esi, 0x1B63
				xor eax, eax
				mov al, PlayerId
				mov edx, 0x14B
				mul edx
				add esi, eax
				mov PlayerPtr, esi

				mov esi, dword ptr ds:[0x511DE8]
				mov eax, [esi + 0x14233]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapX, eax

				mov eax, [esi + 0x14237]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapY, eax

				mov eax, [esi + 0x14273]
				mov LOSMemory, eax
			}

			XScale = float(MapX) / float(MapWidth);
			YScale = float(MapY) / float(MapHeight);

			__asm
			{
				mov esi, dword ptr ds:[0x51FBD0]
				mov eax, [esi + 0xCC]
				mov GrayTablePtr, eax
			}

			memcpy(GrayTable, GrayTablePtr, 256);

			__asm
			{
				mov esi, PlayerPtr
				add esi, 0x80
				mov eax, [esi]
				mov PlayerMapX, eax

				add esi, 4
				mov eax, [esi]
				mov PlayerMapY, eax

				sub esi, 8
				mov eax, [esi]
				mov PlayerLOSMap, eax
			}

			// Sea Level
			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				add esi, 0x141FB
				add esi, 0x84
				xor eax, eax
				mov al, [esi]
				mov SeaLevel, al
			}

			for (i = 0, MappedMemoryHeight = float(0 - SeaLevel / 20); i < MapHeight; i++, MappedMemoryHeight += YScale)
			{
				YOff = i * MapWidth;
				LOSBitYOff = int(MappedMemoryHeight < 0 ? 0 : MappedMemoryHeight) * MapX;

				for (j = 0, MappedMemoryWidth = 0.0f; j < MapWidth; j++, MappedMemoryWidth += XScale)
				{
					if ((((LOSMemory[LOSBitYOff + int(MappedMemoryWidth)]) & (1 << PlayerId)) >> PlayerId) == 0)
					{
						MegaMapSurface[YOff + j] = 0;
					}
					else
					{
						if (PlayerLOSMap[LOSBitYOff + int(MappedMemoryWidth)] == 0)
						{
							MegaMapSurface[YOff + j] = GrayTable[MegaMapSurface[YOff + j]];
						}
					}
				}
			}
		}
	}
	else
	{
		if ((Accessors::GetLOSType() & 2) != 2)
		{
			// Full View ??????? Seems backwards
		}
		else
		{
			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				xor eax, eax
				mov al, [esi + 0x2A43]
				mov PlayerId, al

				add esi, 0x1B63
				xor eax, eax
				mov al, PlayerId
				mov edx, 0x14B
				mul edx
				add esi, eax
				mov PlayerPtr, esi

				mov esi, dword ptr ds : [0x511DE8]
				mov eax, [esi + 0x14233]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapX, eax

				mov eax, [esi + 0x14237]
				xor edx, edx
				mov ecx, 2
				div ecx
				mov MapY, eax

				mov eax, [esi + 0x14273]
				mov LOSMemory, eax
			}

			XScale = float(MapX) / float(MapWidth);
			YScale = float(MapY) / float(MapHeight);

			__asm
			{
				mov esi, dword ptr ds:[0x51FBD0]
				mov eax, [esi + 0xCC]
				mov GrayTablePtr, eax
			}

			memcpy(GrayTable, GrayTablePtr, 256);

			__asm
			{
				mov esi, PlayerPtr
				add esi, 0x80
				mov eax, [esi]
				mov PlayerMapX, eax

				add esi, 4
				mov eax, [esi]
				mov PlayerMapY, eax

				sub esi, 8
				mov eax, [esi]
				mov PlayerLOSMap, eax
			}

			// Sea Level
			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				add esi, 0x141FB
				add esi, 0x84
				xor eax, eax
				mov al, [esi]
				mov SeaLevel, al
			}

			for (i = 0, LOSHeight = float(0 - SeaLevel / 20); i < MapHeight; i++, LOSHeight += YScale)
			{
				YOff = i * MapWidth;
				LOSBitYOff = int(LOSHeight < 0 ? 0 : LOSHeight) * MapX;

				for (j = 0, LOSWidth = 0.0f; j < MapWidth; j++, LOSWidth += XScale)
				{
					if (PlayerLOSMap[LOSBitYOff + int(LOSWidth)] == 0)
					{
						MegaMapSurface[YOff + j] = GrayTable[MegaMapSurface[YOff + j]];
					}
				}
			}
		}
	}

	//MegaMapSurface = LOSMap;
}

void Valkyrie::MegaMap::DrawUnitsOnMegaMapSurface()
{
	void* BeginUnitsArrayPtr;
	void* CurrentUnitPtr;
	short CurrentUnitId;
	int HotRadarUnitsCount;
	void* HotRadarUnitsPtr;

	//int PlayerId;
	int TAX;
	int TAY;

	int XPos;
	int YPos;
	int ZPos;

	int DestWidth;
	int DestHeight;

	int DestPixelYStart;
	int SrcPixelYStart;

	char UnitOwnerIndex;
	//void* UnitOwnerPtr;

	unsigned char PlayerColor;

	WORD FootPrintX;
	WORD FootPrintY;

	RECT DestPosSize;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov eax, [esi + 0x14357]
		mov BeginUnitsArrayPtr, eax

		mov eax, [esi + 0x1436B] // Hot Radar Units
		mov HotRadarUnitsCount, eax

		mov eax, [esi + 0x14363]
		mov HotRadarUnitsPtr, eax
	}

	for (int i = 0; i < HotRadarUnitsCount; i++)
	{
		__asm
		{
			mov esi, HotRadarUnitsPtr
			mov eax, 10
			mov edx, i
			mul edx
			add esi, eax
			xor eax, eax
			mov ax, [esi] // ID
			mov CurrentUnitId, ax
			mov edx, 0x118
			mul edx
			mov esi, BeginUnitsArrayPtr
			add esi, eax
			mov CurrentUnitPtr, esi
		}

		if (CurrentUnitId != 0)
		{
			// Draw Unit Icon

			__asm
			{
				// TAX - First
				mov esi, CurrentUnitPtr
				add esi, 0x6A
				xor eax, eax
				mov ax, [esi + 2]
				mov XPos, eax

				// TAY - First
				mov esi, CurrentUnitPtr
				add esi, 0x6A
				xor eax, eax
				mov ax, [esi + 10]
				mov YPos, eax

				mov esi, CurrentUnitPtr
				add esi, 0x6A
				xor eax, eax
				mov ax, [esi + 6]
				mov ZPos, eax

				mov esi, CurrentUnitPtr
				mov esi, [esi + 0x92]
				xor eax, eax
				mov ax, [esi + 0x14A]
				mov FootPrintX, ax

				mov esi, CurrentUnitPtr
				mov esi, [esi + 0x92]
				xor eax, eax
				mov ax, [esi + 0x14C]
				mov FootPrintY, ax

				mov esi, CurrentUnitPtr
				mov al, [esi + 0xFF]
				mov UnitOwnerIndex, al
			}

			TAX = XPos - FootPrintX / 2;
			TAY = YPos - ZPos / 2 - FootPrintY / 2;

			DestPosSize.left = int(float(TAX) * (float(MapWidth) / float(TAMapTAPos.right))) - IconWidth / 2;
			DestPosSize.right = DestPosSize.left + IconWidth;
			DestPosSize.top = int(float(TAY) * (float(MapHeight) / float(TAMapTAPos.bottom))) - IconHeight / 2;
			DestPosSize.bottom = DestPosSize.top + IconHeight;

			if (DestPosSize.left < 0)
			{
				DestPosSize.left = 0;
			}

			if (DestPosSize.right > MapWidth - IconWidth)
			{
				DestPosSize.right = MapWidth - IconWidth;
			}

			if (DestPosSize.top < 0)
			{
				DestPosSize.top = 0;
			}

			if (DestPosSize.bottom > MapHeight - IconHeight)
			{
				DestPosSize.bottom = MapHeight - IconHeight;
			}

			DestWidth = DestPosSize.bottom - DestPosSize.top;
			DestHeight = DestPosSize.right - DestPosSize.left;

			//Rendering::DrawRectangleFillColor(DestPosSize.left, DestPosSize.top, DestWidth, DestHeight, Color);
			// Lol! Can't have MegaMap drawing on top of this line
			// That is what was happening :p

			__asm
			{
				mov esi, dword ptr ds:[0x511DE8]
				add esi, 0x1B63
				mov eax, 0x14B
				xor edx, edx
				mov dl, UnitOwnerIndex
				mul edx
				add esi, eax
				mov esi, [esi + 0x27]
				xor eax, eax
				mov al, [esi + 0x96] // Player Color
				mov PlayerColor, al
			}

			// OTA
			OriginalIconColors[0] = 227;
			OriginalIconColors[1] = 212;
			OriginalIconColors[2] = 80;
			OriginalIconColors[3] = 235;
			OriginalIconColors[4] = 108;
			OriginalIconColors[5] = 219;
			OriginalIconColors[6] = 208;
			OriginalIconColors[7] = 93;
			OriginalIconColors[8] = 130;
			OriginalIconColors[9] = 67;

			// Total Mayhem
			PlayerIconColors[0] = 227;
			PlayerIconColors[1] = 201;
			PlayerIconColors[2] = 193;
			PlayerIconColors[3] = 165;
			PlayerIconColors[4] = 32;
			PlayerIconColors[5] = 148;
			PlayerIconColors[6] = 80;
			PlayerIconColors[7] = 242;
			PlayerIconColors[8] = 115;
			PlayerIconColors[9] = 67;

			//for (int i = 0; i < 10; i++)
			//{
				//if (PlayerColor == OriginalIconColors[i])
				//{
					PlayerColor = PlayerIconColors[PlayerColor];
					//i = 10;
				//}
			//}

			for (int YPos = 0; YPos < DestHeight; YPos++)
			{
				DestPixelYStart = (YPos + DestPosSize.top) * MapWidth;
				SrcPixelYStart = YPos * IconWidth;

				for (int XPos = 0; XPos < DestWidth; XPos++)
				{
					MegaMapSurface[DestPixelYStart + (XPos + DestPosSize.left)] = PlayerColor;
				}
			}
		}
	}
}

void Valkyrie::MegaMap::DrawProjectilesOnMegaMapSurface()
{

}

void Valkyrie::MegaMap::MoveToMouseMapPositionOnMegaMap(int xPos, int yPos)
{
	int TAPosX;
	int TAPosY;
	int TAPosZ;

	int MoveTAX;
	int MoveTAY;
	int MoveTAZ;

	int TAXNew;
	int TAYNew;
	//int TAZNew;

	int NewXPos;
	int NewYPos;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		mov dword ptr [esi + 0x142F3], 0
	}

	NewXPos = xPos;
	NewYPos = yPos;

	if (NewXPos > MegaMapPosition.right)
	{
		NewXPos = MegaMapPosition.right;
	}

	if (NewXPos < MegaMapPosition.left)
	{
		NewXPos = MegaMapPosition.left;
	}

	if (NewYPos > MegaMapPosition.bottom)
	{
		NewYPos = MegaMapPosition.bottom;
	}

	if (NewYPos < MegaMapPosition.top)
	{
		NewYPos = MegaMapPosition.top;
	}

	// These are needed!
	NewXPos -= MegaMapPosition.left;
	NewYPos -= MegaMapPosition.top;

	// Get TA Position
	TAPosX = int(float(NewXPos) / float(float(MapWidth) / float(TAMapTAPos.right - TAMapTAPos.left)));
	TAPosY = int(float(NewYPos) / float(float(MapHeight) / float(TAMapTAPos.bottom - TAMapTAPos.top)));

	TAPosZ = Accessors::GetMapSeaLevel();

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x2CAA
		mov eax, TAPosX
		mov [esi], eax
		mov eax, TAPosY
		mov [esi + 4], eax
		mov eax, TAPosZ
		mov [esi + 8], eax
	}

	MoveTAX = TAPosX + (MapWidth / 2 - NewXPos);
	MoveTAY = TAPosY + (MapHeight / 2 - NewYPos);
	MoveTAZ = TAPosZ;

	TAXNew = MoveTAX - ((Accessors::GetScreenWidth() - Accessors::GetGameScreenRect().left) / 2);
	TAYNew = MoveTAY - ((Accessors::GetScreenHeight() - Accessors::GetGameScreenRect().top) / 2);

	if (TAXNew < 0)
	{
		TAXNew = 0;
	}

	if (TAYNew < 0)
	{
		TAYNew = 0;
	}

	if (TAXNew > Accessors::GetMaxScrollX())
	{
		TAXNew = Accessors::GetMaxScrollX();
	}

	if (TAYNew > Accessors::GetMaxScrollZ())
	{
		TAYNew = Accessors::GetMaxScrollZ();
	}

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1431F
		mov eax, TAXNew
		mov [esi], eax
		mov eax, TAYNew
		mov [esi + 4], eax
		mov eax, TAXNew
		mov [esi + 8], eax
		mov eax, TAYNew
		mov [esi + 12], eax
	}

	TotalA::TA_UpdateLOSState(0);
}

int Valkyrie::MegaMap::MegaMapWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == WM_MOUSEWHEEL)
	{
		if (((TotalA::TA_GetAsyncKeyState(0x58) & 0x8000) == 0) && ((TotalA::TA_GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0) && ((TotalA::TA_GetAsyncKeyState(VK_CONTROL) & 0x8000) == 0))
		{
			if (HIWORD(wParam) > 120)
			{
				if (RenderMegaMap == false)
				{
					Variables::SkipGameScreenRender.RePatch();
					RenderMegaMap = true;
				}

				return true;
			}
			else if (HIWORD(wParam) <= 120)
			{
				if (RenderMegaMap == true)
				{
					// Move To Mouse Position On Map
					MegaMap::MoveToMouseMapPositionOnMegaMap(LOWORD(lParam), HIWORD(lParam));

					// Disable MegaMap Render
					Variables::SkipGameScreenRender.Revert();
					RenderMegaMap = false;
				}

				return true;
			}
		}
	}

	return false;
}

void Valkyrie::ChatMacro::RunChatMacro()
{
	void* PlayerStruct;

	LPSTR ChatLine = (LPSTR)malloc(46);
	//unsigned char* ChatBuffer[32];
	std::string ChatBuffer[32];

	std::string ChatLineKey;

	__asm
	{
		mov esi, dword ptr ds:[0x511DE8]
		add esi, 0x1B63
		mov PlayerStruct, esi
	}

	for (int i = 0; i < Config::MAX_MACRO_CHAT_LINES; i++)
	{
		ChatLineKey = "ChatLine" + std::to_string(i);

		GetPrivateProfileStringA("ChatMacro", ChatLineKey.c_str(), "", ChatLine, 46, Config::ConfigFileNameFullPath2);

		ChatBuffer[i] = "";

		for (int j = 0; j < 46; j++)
		{
			if (ChatLine[j] == 0 || ChatLine[j] == 13)
			{
				ChatBuffer[i] += '\0';
				j = 46;
			}
			else
			{
				ChatBuffer[i] += ChatLine[j];
			}
		}
	}

	free(ChatLine);

	for (int i = 0; i < Config::MAX_MACRO_CHAT_LINES; i++)
	{
		if (ChatBuffer[i].size() > 0 && ChatBuffer[i][0] != '\0')
		{
			TotalA::TA_ShowText(PlayerStruct, (char*)ChatBuffer[i].c_str(), 4, 0);

			if (ChatBuffer[i][0] == '+')
			{
				TotalA::TA_InterpretCommand((char*)ChatBuffer[i].c_str() + 1, 1);
			}
		}
	}

	
}

HRESULT Valkyrie::Recorder::DPLAYX_Send(DWORD idFrom, DWORD idTo, DWORD dwFlags, LPVOID lpData, DWORD dwDataSize)
{
	std::string s;
	DWORD newIdTo;
	unsigned int till;
	int a;
	
	if (RecorderOff)
	{
		// call DPlayX original bytes and return its HRESULT
	}
	
	try
	{
		s = Recorder::PtrToStr(lpData, dwDataSize);
		till = idTo;
		s = PacketHandler(s, idFrom, till);

		if(dtfound)
		{
			dwFlags = dwFlags | DPSEND_GUARANTEED;
		}

		if (DataChanged)
		{
			DataChanged = false;
			if (s.length() > 0)
			{
				if ((ResSent && !ChatSent) || FakeWatch)
				{
					//return REAL_DPLAYX_Send(idFrom, till, dwFlags, s.data(), s.length());
				}
				else
				{
					//return REAL_DPLAYX_Send(idFrom, idTo, dwFlags, s.data(), s.length());
				}
			}
			else
			{
				if ((ResSent && !ChatSent) || FakeWatch)
				{
					//return REAL_DPLAYX_Send(idFrom, till, dwFlags, s.data(), dwDataSize);
				}
				else
				{
					//return REAL_DPLAYX_Send(idFrom, idTo, dwFlags, s.data(), dwDataSize);
				}
			}
		}



	}
	catch (std::exception &e)
	{
		// sendchat exception info

		// if crash then raise exception

		// but for now do nothing
	}
}

HRESULT Valkyrie::Recorder::DPLAYX_Receive(LPDWORD idFrom, LPDWORD idTo, DWORD dwFlags, LPVOID lpData, LPDWORD dwDataSize)
{
	Packet p;
	int a, b, c;
	char* point;
	std::string s;
	LPDWORD wp;
	WORD w;
	unsigned int ip;
	std::string holdstring;
	int bufsize;
	unsigned int bogustill;
	HRESULT Result;

	if (RecorderOff)
	{
		//return REAL_DPLAYX_Receive(idFrom, idTo, dwFlags, lpData, dwDataSize);
	}

	bufsize = *dwDataSize;

	//if(stringbuf.) // take
	// overflow corrections

	try
	{
		if (stringbuf.size() != 0)
		{
			*idFrom = playerid[GetGoodSource()];
		}
		else
		{
			// take code
		}

		if (stringbuf.size() != 0)
		{
			holdstring = stringbuf.at(0);

			if (holdstring.length() + 10 > * dwDataSize)
			{
				*dwDataSize = holdstring.length() + 10;
				return DPERR_BUFFERTOOSMALL;
			}

			stringbuf.erase(stringbuf.begin());

			p = Packet();
			p.SJCreateNew(holdstring);

			holdstring = p.GetTAData();

			// p = null

			*idTo = playerid[0];
			*dwDataSize = holdstring.length();
			point = (char*)lpData;
			a = 0;
			while (a < *dwDataSize)
			{
				point[a] = holdstring[a];
				a++;

				// Log.Add ("final : ", point, dwDataSize);

				return DP_OK;
			}
		}

		// now the real stuff
		//Result = REAL_DPLAYX_Receive(idFrom, idTo, dwFlags, lpData, dwDataSize);
		if (Result == DP_OK)
		{
			if (*idFrom == 0)
			{
				if ((DWORD(lpData) == DPSYS_DESTROYPLAYERORGROUP && tastatus == 0))
				{
					point = (char*)lpData;
					b = ((TDPMsg_DestroyPlayerGroup*)(lpData))->TDPID;
					a = ConvertId(b);
					// Player (a) left

					if (a < numplayers)
					{
						for (b = a; b < numplayers; b++)
						{
							playerid[b] = playerid[b + 1];
							playername[b] = playername[b + 1];
							playerside[b] = playerside[b + 1];
							playercolor[b] = playercolor[b + 1];
							laststatmess[b] = laststatmess[b + 1];
							playerip[b] = playerip[b + 1];

							cantake[b] = cantake[b + 1];
							// chatview - allies
							lastmsg[b] = lastmsg[b + 1];
							lastpacket[b] = lastpacket[b + 1];
							votedgo[b] = votedgo[b + 1];
							clickedin[b] = clickedin[b + 1];
							enemychat[b] = enemychat[b + 1];
							recConnect[b] = recConnect[b + 1];
							internver[b] = internver[b + 1];
							haswarned[b] = haswarned[b + 1];
							// chatview 0 to 19 inclusive 
							// playernames
						}
					}

					numplayers--;
					// end processing sys
				}
			}
			else
			{
				s = Recorder::PtrToStr(lpData, *dwDataSize);
				s = PacketHandler(s, *idFrom, bogustill);

				if (DataChanged)
				{
					DataChanged = false;

					if (s.length() > bufsize)
					{
						// overflow correction chat

						*dwDataSize = s.length() + 10;

						Result = DPERR_BUFFERTOOSMALL;

						p = Packet();
						p.Create(s, s.length());

						SendLocal(p.GetRawData2(), 0, true, false);
						// p.free();
					}
				}
			}
		}
	}
	catch (std::exception &e)
	{
		// sendchat exception info

		// if crash then raise exception

		// but for now do nothing
	}
}

HRESULT Valkyrie::Recorder::DPLAYX_Open(void* lpsd, DWORD dwFlags)
{
	//HRESULT Result = REAL_DPLAYX_Open(lpsd, dwFlags);
	
	ResetRecorder();

	if (dwFlags == 2)
	{
		imserver = true;
	}
}

std::string Valkyrie::Recorder::PacketHandler(std::string packetData, DWORD idFrom, DWORD idTo)
{
	std::string Result;
	int a, b;
	std::string s, tmp, s2;
	Packet p;
	void* point;
	std::string c;
	WORD w, w2, w3, dtfix;
	LPWORD pw;
	float* pf;
	float f, f2, f3, f4;
	int* ip;
	unsigned int* currnr;
	BYTE* ally;
	std::vector<void*> playerlist;
	char forchar;
	std::string tmps;



	lastmsg[ConvertId(idFrom)] = TotalA::TA_GetTickCount();
	Result = packetData;

	p = Packet();
	p.Create(packetData, packetData.length());

	if (logpl && tastatus == 2)
	{
		PacketLossHandler(p.GetSerial(), ConvertId(idFrom));
	}

	c = p.GetRawData2();
	Result = '\3' + '\0' + '\0';
	Result += p.fdata.substr(3, 4);

	DataChanged = false;

	if (tastatus == 0)
	{
		do
		{
			s = p.Split2(c, false);
			tmp = s;

			if (s[0] == 0x5)
			{
				HandleChatMessage(s, idFrom);

				if (DataChanged)
				{
					tmp = "";
				}
			}

			if (s[0] == 0x1A)
			{
				HandleUnitData(s, idFrom, idTo);

				currnr = (unsigned int*)&s[6];
				if (*currnr = SY_UNIT)
				{
					currnr = (unsigned int*)&tmp[10];
					if (s[1] == 2)
					{
						*currnr = rand() % 400000000;
						DataChanged = true;
					}
				}
			}

			if (s[0] == 2)
			{
				ip = (int*)&s[5];
				a = *ip;

				if (a != 0)
				{
					ip = (int*)&s[1];
					a = *ip;

					if ((a > 0) && (a < 101))
					{
						sentpings[a] = TotalA::TA_GetTickCount();
					}
				}
			}

			if (s[0] == 0x18)
			{
				servernumber = ConvertId(idFrom);
			}

			if ((s[0] == 0x20) && s.length() > 170)
			{
				p = Packet();
				p.SJCreateNew(s);
				laststatmess[ConvertId(idFrom)] = p.GetTAData();

				if ((BYTE(s[156]) & 0x40) == 0x40)
				{
					playerside[ConvertId(idFrom)] = 2;
				}
				else
				{
					playerside[ConvertId(idFrom)] = BYTE(s[150]);
				}

				if (IsServer(idFrom))
				{
					mapname = s.substr(1, s.find('\0') - 2).c_str();

					maxunits = WORD(BYTE(s[166])) + WORD(BYTE(s[167])) * 256;
				}

				if (isSelf == true)
				{
					if ((BYTE(tmp[156] & 0x20) != 0) && (clickedin[0] == false))
					{
						clickedin[0] = true;
					}
				}

				if (isSelf == true)
				{
					tmp[181] = char(INTERNALVER);
				}
			}



			//}

		} while (c != "");
		c = '\6';
	}












}

void Valkyrie::Recorder::HandleUnitData(std::string s, DWORD idFrom, DWORD idTo)
{

}

void Valkyrie::Recorder::ResetRecorder()
{

}

std::string Valkyrie::Recorder::PtrToStr(void* pointer, int length)
{

}

int Valkyrie::Recorder::GetGoodSource()
{
	int max = 0;
	int cur = 1;

	for (int i = 1; i < numplayers; i++)
	{
		if (lastmsg[i] > max)
		{
			max = lastmsg[i];
			cur = i;
		}
	}

	return cur;
}

void Valkyrie::Recorder::Packet::SJCreateNew(std::string data)
{
	const char header[] = { 3, 0, 0, 255, 255, 255, 255 };

	fdata = "";
	fdata.append(header, 7);
	fdata += data;
}

std::string Valkyrie::Recorder::Packet::GetTAData()
{
	std::string s;
	s = fdata;
	s = Compress(s);
	s = Encrypt(s);
	return s;
}

std::string Valkyrie::Recorder::Packet::Compress(std::string s)
{

}

std::string Valkyrie::Recorder::Packet::Encrypt(std::string s)
{

}

std::string Valkyrie::Recorder::Packet::Decompress(std::string s)
{

}

std::string Valkyrie::Recorder::Packet::Decrypt(std::string s)
{

}

void Valkyrie::Recorder::Packet::Create(std::string s, int length)
{

}

std::string Valkyrie::Recorder::Packet::GetRawData()
{
	return fdata.substr(3);
}

std::string Valkyrie::Recorder::Packet::GetRawData2()
{
	return fdata.substr(7);
}

unsigned char Valkyrie::Recorder::ConvertId(DWORD id)
{
	unsigned char Result;
	int a;

	for (a = 0; a < numplayers; a++)
	{
		if (playerid[a] == id)
		{
			Result = a;
		}
	}

	return Result;
}

void Valkyrie::Recorder::PacketLossHandler(DWORD i, DWORD idFrom)
{

}



unsigned int Valkyrie::Recorder::Packet::GetSerial()
{

}

void Valkyrie::Recorder::Packet::SetSerial(unsigned int serial)
{

}

std::string Valkyrie::Recorder::Packet::Split2(std::string s, bool smartpak)
{
	std::string Result;
	int len;
	std::string tmp;

	if (s == "")
	{
		Result = "";
		return Result;
	}

	tmp = s;

	len = 0;

	switch ((BYTE)tmp[0])
	{
	case 2: len = 13; break;
	case 6: len = 1; break;
	case 7: len = 1; break;
	case 0x20: len = 192; break;
	case 0x1A: len = 14; break;
	case 0x17: len = 2; break;
	case 0x18: len = 2; break;
	case 0x15: len = 1; break;
	case 8: len = 1; break;
	case 5: len = 65; break;
	case ((BYTE)'&'): len = 41; break;
	case ((BYTE)'\"'): len = 6; break;
	case ((BYTE)'*'): len = 2; break;
	case 0x1E: len = 2; break;
	case ((BYTE)','): len = int(BYTE(tmp[1])) + int(BYTE(tmp[2]) * 256); break;
	case 9: len = 23; break;
	case 0x11: len = 4; break;
	case 0x10: len = 22; break;
	case 0x12: len = 5; break;
	case 0x0A: len = 7; break;
	case 0x28: len = 58; break;
	case 0x19: len = 3; break;
	case 0x0D: len = 36; break;
	case 0x0B: len = 9; break;
	case 0x0F: len = 6; break;
	case 0x0C: len = 11; break;
	case 0x1F: len = 5; break;
	case 0x23: len = 14; break;
	case 0x16: len = 17; break;
	case 0x1B: len = 6; break;
	case 0x29: len = 3; break;
	case 0x14: len = 24; break;
	case 0x21: len = 10; break;
	case 0x03: len = 7; break;
	case 0x0E: len = 14; break;
	case 0xFF: len = 1; break;
	case 0xFE: len = 5; break;
	case 0xFD: len = int(BYTE(tmp[1]) + int(BYTE(tmp[2]) * 256)) - 4; break;
	case 0xF9: len = 73; break;
	case 0xFB: len = int(tmp[1]) + 3; break;
	case 0xFC: len = 5; break;
	case 0xFA: len = 1; break;
	case 0xF6: len = 1; break;
	}

	if (((s[0] == 0xFF) || (tmp[0] == 0xFE) || tmp[0] == 0xFD) && smartpak == false)
	{
		// logging stuff
	}

	if (tmp.length() < len)
	{
		// logging stuff
		len = 0;
	}

	if (len == 0)
	{
		// even more logging stuff

		s = "";
		Result = tmp;
	}
	else
	{
		s = tmp.substr(len + 1);
		Result = tmp;
	}

	return Result;
}

bool Valkyrie::Recorder::IsServer(DWORD id)
{
	bool Result = false;

	if (id = playerid[servernumber])
	{
		Result = true;
	}

	if (servernumber == 10)
	{
		if (((id == playerid[0]) && imserver) || ((id == playerid[1]) && (imserver == false)))
		{
			Result = true;
		}
	}

	return Result;
}

#endif
