#include "bookmarks.h"

CBookmarks::CBookmarks()
{

}

CBookmarks::~CBookmarks()
{

}

bool CBookmarks::Message(HWND WinProcWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	return false;
}

void CBookmarks::Blit(LPDIRECTDRAWSURFACE DestSurf)
{

}
