#ifndef ringsH
#define ringsH

#include <windows.h>

extern int Length[7];

extern POINTS Rings[7][20];

#endif
