//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ddraw.rc
//
#define VERSIONINFO_1                   1
#define BGBITMAP                        2
#define HATFONT12UC                     3
#define TACURSOR                        4
#define OKBUTTON                        5
#define TTTSTAGEDBUTTON                 6
#define HATFONT12LC                     7
#define HATFONT11UC                     8
#define HATFONT11LC                     9
#define CHECKBOXBITMAP                  10
#define STAGEDBUTTN1                    11
#define STANDARBUTTON                   12
#define INPUTBOX                        13
#define SMALLCIRCLE                     14
#define GREENRECT                       50
#define IDC_GROUPBOX1                   101
#define IDC_RADIOBUTTON1                102
#define IDC_RADIOBUTTON2                103
#define IDC_RADIOBUTTON3                104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
