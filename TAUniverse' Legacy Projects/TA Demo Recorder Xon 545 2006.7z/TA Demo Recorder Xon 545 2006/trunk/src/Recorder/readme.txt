This is a beta version of TA demo recorder v0.99b3, not intended as the final release.

This version will create log files with the name format: "TA Demo recorder log <time & data>.txt"

Please send any of these log files from a game were something when wrong with the recorder.

For a list of commands, look at addcommands.inc